# API 文档

## 基础信息
- 基础路径: `/api`
- 认证方式: Session Cookie

## 文章接口
### GET /api/articles
获取文章列表
- 参数: page, per_page, sentiment, category, keyword
- 返回: 文章列表及分页信息

### GET /api/articles/:id
获取文章详情

## 预警接口
### GET /api/alerts
获取预警列表

### POST /api/alerts/:id/handle
处理预警

## 关键词接口
### GET /api/keywords
获取关键词列表

### POST /api/keywords
添加关键词

### DELETE /api/keywords/:id
删除关键词

## 统计接口
### GET /api/statistics/overview
获取概览统计

### GET /api/statistics/trend
获取趋势数据
