# -*- coding: utf-8 -*-
"""
AI服务模块 - 用于调用大模型进行舆情分析
"""
import requests
import json
from typing import Dict, Any, Optional


class AIService:
    """AI服务类，用于调用配置的大模型API"""
    
    def __init__(self):
        self._engine = None
        self._engine_cache_time = None
    
    def _get_default_engine(self) -> Optional[Dict]:
        """获取默认AI引擎配置"""
        from datetime import datetime, timedelta
        
        # 缓存5分钟
        if self._engine and self._engine_cache_time:
            if datetime.now() - self._engine_cache_time < timedelta(minutes=5):
                return self._engine
        
        try:
            from app.models import AIEngine
            
            # 优先获取默认引擎
            engine = AIEngine.query.filter_by(is_default=True, is_active=True).first()
            
            # 如果没有默认引擎，获取任意一个启用的引擎
            if not engine:
                engine = AIEngine.query.filter_by(is_active=True).order_by(AIEngine.priority.desc()).first()
            
            if engine:
                self._engine = engine.to_dict(hide_key=False)
                self._engine_cache_time = datetime.now()
                return self._engine
            
            return None
        except Exception as e:
            print(f"获取AI引擎失败: {e}")
            return None
    
    def chat(self, messages: list, engine: Dict = None, max_tokens: int = None, temperature: float = None) -> Dict[str, Any]:
        """
        调用大模型进行对话
        
        Args:
            messages: 消息列表，格式为 [{"role": "user/assistant/system", "content": "..."}]
            engine: 指定引擎配置，为空则使用默认引擎
            max_tokens: 最大token数，为空则使用引擎默认值
            temperature: 温度参数，为空则使用引擎默认值
            
        Returns:
            包含回复内容的字典
        """
        if not engine:
            engine = self._get_default_engine()
        
        if not engine:
            return {
                'success': False,
                'content': '',
                'error': '未配置AI引擎，请先在后台添加AI引擎'
            }
        
        try:
            # 构建请求
            api_url = engine['api_base'].rstrip('/')
            if not api_url.endswith('/chat/completions'):
                api_url += '/chat/completions'
            
            headers = {
                'Authorization': f"Bearer {engine.get('api_key_full') or engine.get('api_key')}",
                'Content-Type': 'application/json'
            }
            
            payload = {
                'model': engine['model_name'],
                'messages': messages,
                'max_tokens': max_tokens or engine.get('max_tokens', 4096),
                'temperature': temperature if temperature is not None else engine.get('temperature', 0.7)
            }
            
            response = requests.post(api_url, headers=headers, json=payload, timeout=60)
            
            if response.status_code == 200:
                result = response.json()
                content = result.get('choices', [{}])[0].get('message', {}).get('content', '')
                return {
                    'success': True,
                    'content': content,
                    'model': result.get('model', engine['model_name']),
                    'usage': result.get('usage', {})
                }
            else:
                return {
                    'success': False,
                    'content': '',
                    'error': f"API返回错误: {response.status_code} - {response.text[:200]}"
                }
                
        except requests.Timeout:
            return {
                'success': False,
                'content': '',
                'error': '请求超时，请稍后重试'
            }
        except Exception as e:
            return {
                'success': False,
                'content': '',
                'error': f"调用失败: {str(e)}"
            }
    
    def analyze_sentiment(self, title: str, content: str) -> Dict[str, Any]:
        """
        情感分析
        
        Args:
            title: 文章标题
            content: 文章内容
            
        Returns:
            分析结果
        """
        text = content[:2000] if content else title  # 限制长度
        
        prompt = f"""请对以下新闻进行情感分析，判断其情感倾向。

标题：{title}
内容：{text}

请按以下JSON格式返回分析结果（只返回JSON，不要其他内容）：
{{
    "sentiment": "positive/negative/neutral",
    "confidence": 0.0-1.0之间的置信度,
    "reason": "简短说明判断理由"
}}"""
        
        result = self.chat([
            {"role": "system", "content": "你是一个专业的舆情分析师，擅长分析新闻的情感倾向。请严格按照要求的JSON格式返回结果。"},
            {"role": "user", "content": prompt}
        ], temperature=0.3)
        
        if result['success']:
            try:
                # 尝试解析JSON
                content = result['content'].strip()
                # 处理可能的markdown代码块
                if content.startswith('```'):
                    content = content.split('```')[1]
                    if content.startswith('json'):
                        content = content[4:]
                
                analysis = json.loads(content.strip())
                return {
                    'success': True,
                    'sentiment': analysis.get('sentiment', 'neutral'),
                    'confidence': analysis.get('confidence', 0.5),
                    'reason': analysis.get('reason', ''),
                    'raw': result['content']
                }
            except json.JSONDecodeError:
                # 尝试从文本中提取情感
                content_lower = result['content'].lower()
                if 'positive' in content_lower or '正面' in result['content']:
                    sentiment = 'positive'
                elif 'negative' in content_lower or '负面' in result['content']:
                    sentiment = 'negative'
                else:
                    sentiment = 'neutral'
                
                return {
                    'success': True,
                    'sentiment': sentiment,
                    'confidence': 0.6,
                    'reason': result['content'][:200],
                    'raw': result['content']
                }
        else:
            return {
                'success': False,
                'error': result.get('error', '分析失败')
            }
    
    def generate_summary(self, title: str, content: str) -> Dict[str, Any]:
        """
        生成摘要
        
        Args:
            title: 文章标题
            content: 文章内容
            
        Returns:
            摘要结果
        """
        text = content[:3000] if content else title
        
        prompt = f"""请为以下新闻生成一段简洁的摘要，不超过150字。

标题：{title}
内容：{text}

请直接返回摘要内容，不要添加任何前缀或说明。"""
        
        result = self.chat([
            {"role": "system", "content": "你是一个专业的新闻编辑，擅长提炼新闻要点并生成简洁的摘要。"},
            {"role": "user", "content": prompt}
        ], max_tokens=300, temperature=0.5)
        
        if result['success']:
            return {
                'success': True,
                'summary': result['content'].strip()
            }
        else:
            return {
                'success': False,
                'error': result.get('error', '生成摘要失败')
            }
    
    def extract_keywords(self, title: str, content: str) -> Dict[str, Any]:
        """
        提取关键词
        
        Args:
            title: 文章标题
            content: 文章内容
            
        Returns:
            关键词列表
        """
        text = content[:2000] if content else title
        
        prompt = f"""请从以下新闻中提取5-8个关键词。

标题：{title}
内容：{text}

请按以下JSON格式返回（只返回JSON，不要其他内容）：
{{
    "keywords": ["关键词1", "关键词2", "关键词3", ...]
}}"""
        
        result = self.chat([
            {"role": "system", "content": "你是一个专业的文本分析师，擅长提取文章的核心关键词。请严格按照要求的JSON格式返回结果。"},
            {"role": "user", "content": prompt}
        ], temperature=0.3)
        
        if result['success']:
            try:
                content = result['content'].strip()
                if content.startswith('```'):
                    content = content.split('```')[1]
                    if content.startswith('json'):
                        content = content[4:]
                
                data = json.loads(content.strip())
                return {
                    'success': True,
                    'keywords': data.get('keywords', [])
                }
            except:
                # 尝试从文本中提取
                keywords = [k.strip() for k in result['content'].replace('，', ',').split(',') if k.strip()]
                return {
                    'success': True,
                    'keywords': keywords[:8]
                }
        else:
            return {
                'success': False,
                'error': result.get('error', '提取关键词失败')
            }
    
    def classify_category(self, title: str, content: str) -> Dict[str, Any]:
        """
        自动分类
        
        Args:
            title: 文章标题
            content: 文章内容
            
        Returns:
            分类结果
        """
        text = content[:1500] if content else title
        
        categories = ["政治", "经济", "社会", "科技", "文化", "体育", "娱乐", "教育", "健康", "环境", "国际", "其他"]
        
        prompt = f"""请对以下新闻进行分类，从给定的类别中选择最合适的一个。

可选类别：{', '.join(categories)}

标题：{title}
内容：{text}

请按以下JSON格式返回（只返回JSON，不要其他内容）：
{{
    "category": "选择的类别",
    "reason": "简短说明分类理由"
}}"""
        
        result = self.chat([
            {"role": "system", "content": "你是一个专业的新闻分类专家。请严格按照要求的JSON格式返回结果。"},
            {"role": "user", "content": prompt}
        ], temperature=0.3)
        
        if result['success']:
            try:
                content = result['content'].strip()
                if content.startswith('```'):
                    content = content.split('```')[1]
                    if content.startswith('json'):
                        content = content[4:]
                
                data = json.loads(content.strip())
                category = data.get('category', '其他')
                # 验证类别是否在列表中
                if category not in categories:
                    category = '其他'
                
                return {
                    'success': True,
                    'category': category,
                    'reason': data.get('reason', '')
                }
            except:
                # 尝试从文本中提取
                for cat in categories:
                    if cat in result['content']:
                        return {
                            'success': True,
                            'category': cat,
                            'reason': ''
                        }
                return {
                    'success': True,
                    'category': '其他',
                    'reason': ''
                }
        else:
            return {
                'success': False,
                'error': result.get('error', '分类失败')
            }
    
    def full_analysis(self, title: str, content: str) -> Dict[str, Any]:
        """
        综合分析（情感+摘要+关键词+分类）
        
        Args:
            title: 文章标题
            content: 文章内容
            
        Returns:
            综合分析结果
        """
        text = content[:2500] if content else title
        
        prompt = f"""请对以下新闻进行综合分析，包括情感分析、生成摘要、提取关键词和分类。

标题：{title}
内容：{text}

请按以下JSON格式返回分析结果（只返回JSON，不要其他内容）：
{{
    "sentiment": {{
        "type": "positive/negative/neutral",
        "confidence": 0.0-1.0之间的置信度,
        "reason": "情感判断理由"
    }},
    "summary": "不超过150字的新闻摘要",
    "keywords": ["关键词1", "关键词2", "关键词3", "关键词4", "关键词5"],
    "category": "政治/经济/社会/科技/文化/体育/娱乐/教育/健康/环境/国际/其他"
}}"""
        
        result = self.chat([
            {"role": "system", "content": "你是一个专业的舆情分析师，擅长对新闻进行多维度分析。请严格按照要求的JSON格式返回结果。"},
            {"role": "user", "content": prompt}
        ], max_tokens=1000, temperature=0.4)
        
        if result['success']:
            try:
                content = result['content'].strip()
                if content.startswith('```'):
                    content = content.split('```')[1]
                    if content.startswith('json'):
                        content = content[4:]
                
                data = json.loads(content.strip())
                
                sentiment_data = data.get('sentiment', {})
                
                return {
                    'success': True,
                    'sentiment': sentiment_data.get('type', 'neutral'),
                    'sentiment_confidence': sentiment_data.get('confidence', 0.5),
                    'sentiment_reason': sentiment_data.get('reason', ''),
                    'summary': data.get('summary', ''),
                    'keywords': data.get('keywords', []),
                    'category': data.get('category', '其他'),
                    'raw': result['content']
                }
            except json.JSONDecodeError as e:
                return {
                    'success': False,
                    'error': f'解析AI返回结果失败: {str(e)}',
                    'raw': result['content']
                }
        else:
            return {
                'success': False,
                'error': result.get('error', '综合分析失败')
            }


# 全局AI服务实例
ai_service = AIService()
