#!/usr/bin/env python
"""
舆情数据采集模块
用于从百度新闻接口采集舆情数据
"""
import re
import time
import random
import requests
from urllib.parse import quote, urlencode
from bs4 import BeautifulSoup
from dataclasses import dataclass, asdict, field
from typing import List, Optional, Dict, Any
from datetime import datetime


@dataclass
class NewsItem:
    """新闻数据项"""
    title: str           # 标题
    summary: str         # 概要
    cover: str           # 封面图片URL
    url: str             # 原始URL
    source: str          # 来源
    publish_time: str = ""   # 发布时间
    keyword: str = ""        # 采集关键词
    crawl_time: str = field(default_factory=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class BaiduNewsCrawler:
    """百度新闻采集器"""
    
    BASE_URL = "https://www.baidu.com/s"
    
    # 完整的请求头配置
    HEADERS = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Sec-Ch-Ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.5845.97 Safari/537.36 Core/1.116.586.400 QQBrowser/19.8.6883.400'
    }
    
    # 完整Cookie配置
    COOKIE_STRING = "BIDUPSID=D48AC21A701043225723F7B0416A45A5; PSTM=1749868400; BD_UPN=1a314753; BAIDUID=D48AC21A70104322974B66FAE2F73383:SL=0:NR=10:FG=1; MAWEBCUID=web_YJdcNWbgVAvBDdOlAjnOFGURksbLStlKretXHCZPDmkKBoCWao; MCITY=-75%3A; newlogin=1; BDUSS=Bsb0RmVWp3c0NmMHNwOVpnVTZpSUU1Rn5IU1c1S29EVVJQYVI0ZWFnWEhDazVwSVFBQUFBJCQAAAAAAAAAAAEAAACr7QECeWFuZ2FodWkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMd9JmnHfSZpNX; BDUSS_BFESS=Bsb0RmVWp3c0NmMHNwOVpnVTZpSUU1Rn5IU1c1S29EVVJQYVI0ZWFnWEhDazVwSVFBQUFBJCQAAAAAAAAAAAEAAACr7QECeWFuZ2FodWkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMd9JmnHfSZpNX; BAIDUID_BFESS=D48AC21A70104322974B66FAE2F73383:SL=0:NR=10:FG=1; H_WISE_SIDS_BFESS=60272_63144_66104_66109_66213_66232_66288_66271_66393_66510_66516_66529_66552_66589_66591_66601_66606_66652_66671_66669_66694_66685_66599_66720_66744_66623; __bid_n=19ad5be04673728d3e48c8; PAD_BROWSER=1; ZFY=:BbjM:A1IBjzvZvV4stKekEFIixozKxmgJlX2ZrIwt9J0:C; Hm_lvt_aec699bb6442ba076c8981c6dc490771=1764321838,1764467635,1764522517,1764723037; COOKIE_SESSION=61096_0_9_9_12_35_1_3_9_8_0_1_61094_0_4_0_1764723038_0_1764723034%7C9%2325100_26_1764063190%7C9; sug=3; sugstore=0; ORIGIN=0; bdime=0; H_PS_PSSID=60272_63144_66104_66109_66213_66232_66288_66271_66393_66510_66516_66529_66552_66589_66591_66601_66606_66652_66671_66669_66694_66685_66720_66744_66623_66772_66787_66792_66747_66806_66799_66599"
    
    def __init__(self, timeout: int = 15, max_retries: int = 3):
        """
        初始化采集器
        
        Args:
            timeout: 请求超时时间（秒）
            max_retries: 最大重试次数
        """
        self.session = requests.Session()
        self.session.headers.update(self.HEADERS)
        self.session.headers['Cookie'] = self.COOKIE_STRING
        self.timeout = timeout
        self.max_retries = max_retries
    
    def search(self, keyword: str, page: int = 1) -> List[NewsItem]:
        """
        搜索新闻
        
        Args:
            keyword: 搜索关键词
            page: 页码（从1开始）
            
        Returns:
            新闻列表
        """
        params = {
            'rtt': '1',
            'bsst': '1',
            'cl': '2',
            'tn': 'news',
            'rsv_dl': 'ns_pc',
            'word': keyword,
            'pn': (page - 1) * 10
        }
        
        for attempt in range(self.max_retries):
            try:
                # 添加随机延迟
                time.sleep(random.uniform(1.0, 3.0))
                
                response = self.session.get(
                    self.BASE_URL,
                    params=params,
                    timeout=self.timeout,
                    allow_redirects=True
                )
                response.raise_for_status()
                response.encoding = 'utf-8'
                
                news_list = self._parse_response(response.text, keyword)
                if news_list:
                    return news_list
                    
            except requests.RequestException as e:
                print(f"请求失败 (尝试 {attempt + 1}/{self.max_retries}): {e}")
                if attempt < self.max_retries - 1:
                    time.sleep(random.uniform(2.0, 5.0))
                continue
        
        return []
    
    def _parse_response(self, html: str, keyword: str) -> List[NewsItem]:
        """解析响应HTML"""
        news_list = []
        soup = BeautifulSoup(html, 'html.parser')
        
        # 百度新闻的多种可能容器选择器
        selectors = [
            'div.result-op.c-container.xpath-log',
            'div.result.c-container',
            'div[class*="result"]',
            'div[tpl="news_summary"]',
            'div.c-container'
        ]
        
        containers = []
        for selector in selectors:
            found = soup.select(selector)
            if found:
                containers = found
                break
        
        # 如果没找到容器，尝试直接查找新闻标题
        if not containers:
            containers = soup.find_all('div', class_=lambda x: x and 'c-container' in x)
        
        for container in containers:
            try:
                news_item = self._parse_news_item(container, keyword)
                if news_item and news_item.title:
                    news_list.append(news_item)
            except Exception as e:
                continue
        
        return news_list
    
    def _parse_news_item(self, container, keyword: str) -> Optional[NewsItem]:
        """解析单条新闻"""
        # 提取标题和URL - 多种选择器
        title_elem = None
        for selector in ['h3.c-title a', 'h3 a', '.c-title a', 'a[href*="baidu.com"]']:
            title_elem = container.select_one(selector)
            if title_elem:
                break
        
        if not title_elem:
            return None
        
        title = title_elem.get_text(strip=True)
        url = title_elem.get('href', '')
        
        if not title or len(title) < 5:
            return None
        
        # 提取概要
        summary = ''
        for selector in ['.c-summary', '.c-abstract', 'div.c-span9', '.content-right', 'span.c-color-text']:
            elem = container.select_one(selector)
            if elem:
                summary = elem.get_text(strip=True)
                if summary:
                    break
        
        # 如果还没找到，尝试获取容器内所有文本
        if not summary:
            all_text = container.get_text(strip=True)
            if len(all_text) > len(title) + 20:
                summary = all_text[len(title):].strip()[:300]
        
        summary = self._clean_text(summary)
        
        # 提取封面图片
        cover = ''
        img_elem = container.select_one('img[src*="http"], img[data-src*="http"]')
        if img_elem:
            cover = img_elem.get('src', '') or img_elem.get('data-src', '')
        
        # 提取来源和时间
        source = ''
        publish_time = ''
        
        # 查找来源信息
        for selector in ['.c-author', '.news-source', 'span.c-color-gray', 'span.c-color-gray2', '.source-wrap']:
            source_elem = container.select_one(selector)
            if source_elem:
                source_text = source_elem.get_text(strip=True)
                if source_text:
                    # 解析来源和时间
                    parts = re.split(r'\s{2,}|·', source_text)
                    if parts:
                        source = parts[0].strip()
                        if len(parts) > 1:
                            publish_time = parts[-1].strip()
                    break
        
        # 尝试从其他位置提取时间
        if not publish_time:
            time_patterns = [
                r'(\d+分钟前)',
                r'(\d+小时前)',
                r'(\d+天前)',
                r'(今天\s*\d{1,2}:\d{2})',
                r'(昨天\s*\d{1,2}:\d{2})',
                r'(\d{1,2}月\d{1,2}日)',
                r'(\d{4}-\d{2}-\d{2})'
            ]
            container_text = container.get_text()
            for pattern in time_patterns:
                match = re.search(pattern, container_text)
                if match:
                    publish_time = match.group(1)
                    break
        
        return NewsItem(
            title=title,
            summary=summary[:500] if summary else '',
            cover=cover,
            url=url,
            source=source,
            publish_time=publish_time,
            keyword=keyword
        )
    
    def _clean_text(self, text: str) -> str:
        """清理文本"""
        if not text:
            return ''
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'^\s*[\u4e00-\u9fa5]+\s*\d{1,2}[\u5206\u5c0f\u65f6\u5929\u524d]+', '', text)
        return text.strip()
    
    def crawl_multiple_pages(self, keyword: str, pages: int = 3) -> List[NewsItem]:
        """采集多页数据"""
        all_news = []
        for page in range(1, pages + 1):
            print(f"正在采集第 {page} 页...")
            news = self.search(keyword, page)
            all_news.extend(news)
            print(f"第 {page} 页采集到 {len(news)} 条新闻")
            if not news:
                print("未获取到数据，停止采集")
                break
        return all_news


class SogouNewsCrawler:
    """搜狗新闻采集器"""
    
    BASE_URL = "https://news.sogou.com/news"
    
    HEADERS = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36'
    }
    
    def __init__(self, timeout: int = 10):
        self.session = requests.Session()
        self.session.headers.update(self.HEADERS)
        self.timeout = timeout
    
    def search(self, keyword: str, page: int = 1) -> List[NewsItem]:
        """搜索搜狗新闻"""
        params = {
            'query': keyword,
            'page': page,
            'sort': '1'  # 按时间排序
        }
        
        try:
            time.sleep(random.uniform(0.5, 1.5))
            response = self.session.get(self.BASE_URL, params=params, timeout=self.timeout)
            response.encoding = 'utf-8'
            return self._parse_response(response.text, keyword)
        except Exception as e:
            print(f"搜狗新闻采集失败: {e}")
            return []
    
    def _parse_response(self, html: str, keyword: str) -> List[NewsItem]:
        """解析搜狗新闻响应"""
        news_list = []
        soup = BeautifulSoup(html, 'html.parser')
        
        # 搜狗新闻结果容器
        items = soup.select('.news-list li, .vrwrap, .rb')
        
        for item in items:
            try:
                # 提取标题和URL
                title_elem = item.select_one('h3 a, .news-title a, a.title')
                if not title_elem:
                    continue
                
                title = title_elem.get_text(strip=True)
                url = title_elem.get('href', '')
                
                if not title or not url:
                    continue
                
                # 提取概要
                summary = ''
                summary_elem = item.select_one('.news-txt, .news-info, p')
                if summary_elem:
                    summary = summary_elem.get_text(strip=True)
                
                # 提取来源和时间
                source = '搜狗新闻'
                publish_time = ''
                info_elem = item.select_one('.news-from, .news-source, .s2')
                if info_elem:
                    info_text = info_elem.get_text(strip=True)
                    parts = info_text.split()
                    if parts:
                        source = parts[0] if parts[0] else '搜狗新闻'
                        if len(parts) > 1:
                            publish_time = parts[-1]
                
                # 提取封面
                cover = ''
                img_elem = item.select_one('img')
                if img_elem:
                    cover = img_elem.get('src', '') or img_elem.get('data-src', '')
                
                news_list.append(NewsItem(
                    title=title,
                    summary=summary[:500] if summary else '',
                    cover=cover,
                    url=url,
                    source=source,
                    publish_time=publish_time,
                    keyword=keyword
                ))
            except Exception as e:
                continue
        
        return news_list
    
    def crawl_multiple_pages(self, keyword: str, pages: int = 3) -> List[NewsItem]:
        """采集多页数据"""
        all_news = []
        for page in range(1, pages + 1):
            news = self.search(keyword, page)
            all_news.extend(news)
            if not news:
                break
        return all_news


class ToutiaoNewsCrawler:
    """今日头条新闻采集器（通过搜索接口）"""
    
    BASE_URL = "https://so.toutiao.com/search"
    
    HEADERS = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36'
    }
    
    def __init__(self, timeout: int = 10):
        self.session = requests.Session()
        self.session.headers.update(self.HEADERS)
        self.timeout = timeout
    
    def search(self, keyword: str, page: int = 1) -> List[NewsItem]:
        """搜索头条新闻"""
        params = {
            'keyword': keyword,
            'pd': 'information',
            'dvpf': 'pc',
            'page_num': page - 1
        }
        
        try:
            time.sleep(random.uniform(0.5, 1.5))
            response = self.session.get(self.BASE_URL, params=params, timeout=self.timeout)
            response.encoding = 'utf-8'
            return self._parse_response(response.text, keyword)
        except Exception as e:
            print(f"头条新闻采集失败: {e}")
            return []
    
    def _parse_response(self, html: str, keyword: str) -> List[NewsItem]:
        """解析头条新闻响应"""
        news_list = []
        soup = BeautifulSoup(html, 'html.parser')
        
        # 头条搜索结果
        items = soup.select('.result-content, .cs-view-block, article')
        
        for item in items:
            try:
                title_elem = item.select_one('a[href*="toutiao"], h3 a, .title a')
                if not title_elem:
                    continue
                
                title = title_elem.get_text(strip=True)
                url = title_elem.get('href', '')
                
                if not title:
                    continue
                
                summary = ''
                summary_elem = item.select_one('.text-underline-hover, .cs-source-content, p')
                if summary_elem:
                    summary = summary_elem.get_text(strip=True)
                
                source = '今日头条'
                publish_time = ''
                source_elem = item.select_one('.cs-source, .source, span[class*="source"]')
                if source_elem:
                    source_text = source_elem.get_text(strip=True)
                    if source_text:
                        source = source_text
                
                time_elem = item.select_one('.cs-source-time, .time, span[class*="time"]')
                if time_elem:
                    publish_time = time_elem.get_text(strip=True)
                
                cover = ''
                img_elem = item.select_one('img')
                if img_elem:
                    cover = img_elem.get('src', '') or img_elem.get('data-src', '')
                
                news_list.append(NewsItem(
                    title=title,
                    summary=summary[:500] if summary else '',
                    cover=cover,
                    url=url,
                    source=source,
                    publish_time=publish_time,
                    keyword=keyword
                ))
            except Exception:
                continue
        
        return news_list
    
    def crawl_multiple_pages(self, keyword: str, pages: int = 3) -> List[NewsItem]:
        """采集多页数据"""
        all_news = []
        for page in range(1, pages + 1):
            news = self.search(keyword, page)
            all_news.extend(news)
            if not news:
                break
        return all_news


class BingNewsCrawler:
    """必应新闻采集器"""
    
    BASE_URL = "https://cn.bing.com/news/search"
    
    HEADERS = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36'
    }
    
    def __init__(self, timeout: int = 10):
        self.session = requests.Session()
        self.session.headers.update(self.HEADERS)
        self.timeout = timeout
    
    def search(self, keyword: str, page: int = 1) -> List[NewsItem]:
        """搜索必应新闻"""
        params = {
            'q': keyword,
            'FORM': 'HDRSC6',
            'first': (page - 1) * 10 + 1
        }
        
        try:
            time.sleep(random.uniform(0.5, 1.5))
            response = self.session.get(self.BASE_URL, params=params, timeout=self.timeout)
            response.encoding = 'utf-8'
            return self._parse_response(response.text, keyword)
        except Exception as e:
            print(f"必应新闻采集失败: {e}")
            return []
    
    def _parse_response(self, html: str, keyword: str) -> List[NewsItem]:
        """解析必应新闻响应"""
        news_list = []
        soup = BeautifulSoup(html, 'html.parser')
        
        items = soup.select('.news-card, .newsitem, article')
        
        for item in items:
            try:
                title_elem = item.select_one('a.title, h2 a, a[href*="http"]')
                if not title_elem:
                    continue
                
                title = title_elem.get_text(strip=True)
                url = title_elem.get('href', '')
                
                if not title:
                    continue
                
                summary = ''
                summary_elem = item.select_one('.snippet, .description, p')
                if summary_elem:
                    summary = summary_elem.get_text(strip=True)
                
                source = '必应新闻'
                publish_time = ''
                source_elem = item.select_one('.source, span[data-author]')
                if source_elem:
                    source = source_elem.get_text(strip=True) or '必应新闻'
                
                time_elem = item.select_one('time, .time, span[aria-label*="前"]')
                if time_elem:
                    publish_time = time_elem.get_text(strip=True) or time_elem.get('datetime', '')
                
                cover = ''
                img_elem = item.select_one('img')
                if img_elem:
                    cover = img_elem.get('src', '') or img_elem.get('data-src', '')
                
                news_list.append(NewsItem(
                    title=title,
                    summary=summary[:500] if summary else '',
                    cover=cover,
                    url=url,
                    source=source,
                    publish_time=publish_time,
                    keyword=keyword
                ))
            except Exception:
                continue
        
        return news_list
    
    def crawl_multiple_pages(self, keyword: str, pages: int = 3) -> List[NewsItem]:
        """采集多页数据"""
        all_news = []
        for page in range(1, pages + 1):
            news = self.search(keyword, page)
            all_news.extend(news)
            if not news:
                break
        return all_news


# 数据源配置
DATA_SOURCES = {
    'baidu': {
        'name': '百度新闻',
        'crawler': BaiduNewsCrawler,
        'enabled': True
    },
    'sogou': {
        'name': '搜狗新闻',
        'crawler': SogouNewsCrawler,
        'enabled': True
    },
    'toutiao': {
        'name': '今日头条',
        'crawler': ToutiaoNewsCrawler,
        'enabled': True
    },
    'bing': {
        'name': '必应新闻',
        'crawler': BingNewsCrawler,
        'enabled': True
    }
}


def crawl_news(keyword: str, pages: int = 1) -> List[Dict[str, Any]]:
    """
    采集新闻的便捷函数
    
    Args:
        keyword: 搜索关键词
        pages: 采集页数
        
    Returns:
        新闻字典列表，每条包含: title, summary, cover, url, source, publish_time
    """
    crawler = BaiduNewsCrawler()
    if pages == 1:
        news_list = crawler.search(keyword)
    else:
        news_list = crawler.crawl_multiple_pages(keyword, pages)
    
    return [news.to_dict() for news in news_list]


# 深度采集器
class DeepCrawler:
    """深度采集器，用于获取新闻正文内容"""
    
    HEADERS = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36'
    }
    
    def __init__(self, timeout: int = 10):
        self.session = requests.Session()
        self.session.headers.update(self.HEADERS)
        self.timeout = timeout
    
    def crawl(self, url: str) -> Dict[str, Any]:
        """
        深度采集单个URL的正文内容
        
        Args:
            url: 新闻URL
            
        Returns:
            包含正文内容的字典
        """
        try:
            # 添加随机延迟
            time.sleep(random.uniform(0.5, 1.5))
            
            response = self.session.get(url, timeout=self.timeout, allow_redirects=True)
            response.encoding = response.apparent_encoding or 'utf-8'
            
            content = self._extract_content(response.text)
            
            return {
                'success': True,
                'content': content,
                'url': url,
                'message': '深度采集成功'
            }
        except Exception as e:
            return {
                'success': False,
                'content': '',
                'url': url,
                'message': f'深度采集失败: {str(e)}'
            }
    
    def _extract_content(self, html: str) -> str:
        """从HTML中提取正文内容"""
        soup = BeautifulSoup(html, 'html.parser')
        
        # 移除脚本和样式
        for tag in soup(['script', 'style', 'nav', 'header', 'footer', 'aside', 'iframe', 'noscript']):
            tag.decompose()
        
        # 常见的正文容器选择器
        content_selectors = [
            'article',
            '.article-content',
            '.article-body',
            '.content',
            '.post-content',
            '.entry-content',
            '.news-content',
            '.detail-content',
            '#article-content',
            '#content',
            '.main-content',
            '[class*="article"]',
            '[class*="content"]',
            '.text',
            '.body'
        ]
        
        content = ''
        
        # 尝试各种选择器
        for selector in content_selectors:
            elem = soup.select_one(selector)
            if elem:
                # 获取所有段落文本
                paragraphs = elem.find_all(['p', 'div'])
                texts = []
                for p in paragraphs:
                    text = p.get_text(strip=True)
                    if text and len(text) > 20:  # 过滤短文本
                        texts.append(text)
                if texts:
                    content = '\n\n'.join(texts)
                    break
        
        # 如果还没找到，尝试获取body内所有段落
        if not content:
            body = soup.find('body')
            if body:
                paragraphs = body.find_all('p')
                texts = [p.get_text(strip=True) for p in paragraphs if len(p.get_text(strip=True)) > 30]
                content = '\n\n'.join(texts)
        
        # 清理内容
        content = self._clean_content(content)
        
        return content[:5000] if content else ''  # 限制长度
    
    def _clean_content(self, text: str) -> str:
        """清理正文内容"""
        if not text:
            return ''
        
        # 移除多余空白
        text = re.sub(r'\s+', ' ', text)
        # 移除特殊字符
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
        # 恢复段落换行
        text = re.sub(r'\s*\n\s*', '\n\n', text)
        
        return text.strip()


class RuleBasedCrawler:
    """基于规则库的详细内容采集器"""
    
    DEFAULT_HEADERS = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36'
    }
    
    def __init__(self, timeout: int = 15):
        self.timeout = timeout
        self._rules_cache = {}
        self._cache_time = None
    
    def _get_rules(self) -> List[Dict]:
        """获取规则库（带缓存）"""
        import json
        from datetime import datetime, timedelta
        
        # 缓存5分钟
        if self._cache_time and datetime.now() - self._cache_time < timedelta(minutes=5):
            return self._rules_cache.get('rules', [])
        
        try:
            # 延迟导入避免循环依赖
            from app.models import CrawlerRule
            rules = CrawlerRule.query.filter_by(is_active=True).order_by(CrawlerRule.priority.desc()).all()
            self._rules_cache['rules'] = [r.to_dict() for r in rules]
            self._cache_time = datetime.now()
            return self._rules_cache['rules']
        except Exception as e:
            print(f"获取规则库失败: {e}")
            return []
    
    def _match_rule(self, source: str, url: str) -> Optional[Dict]:
        """
        根据来源和URL匹配规则
        
        Args:
            source: 新闻来源名称
            url: 新闻URL
            
        Returns:
            匹配的规则字典，未匹配返回None
        """
        import fnmatch
        from urllib.parse import urlparse
        
        rules = self._get_rules()
        parsed_url = urlparse(url)
        domain = parsed_url.netloc
        
        for rule in rules:
            # 1. 优先通过站点名称匹配来源
            if rule.get('site_name') and source:
                if rule['site_name'] in source or source in rule['site_name']:
                    return rule
            
            # 2. 通过域名匹配
            rule_domain = rule.get('site_domain', '')
            if rule_domain:
                # 支持通配符匹配
                if fnmatch.fnmatch(domain, rule_domain):
                    return rule
                # 精确匹配
                if domain == rule_domain or domain.endswith('.' + rule_domain):
                    return rule
        
        return None
    
    def crawl_with_rule(self, url: str, source: str = '', article_id: int = None) -> Dict[str, Any]:
        """
        使用规则库进行详细内容采集
        
        Args:
            url: 新闻URL
            source: 新闻来源
            article_id: 文章ID（用于更新规则）
            
        Returns:
            采集结果字典
        """
        import json
        from lxml import etree
        
        # 匹配规则
        rule = self._match_rule(source, url)
        rule_used = rule is not None
        rule_info = None
        
        # 准备请求头
        headers = self.DEFAULT_HEADERS.copy()
        if rule and rule.get('request_headers'):
            try:
                custom_headers = json.loads(rule['request_headers'])
                headers.update(custom_headers)
            except:
                pass
        
        try:
            time.sleep(random.uniform(0.5, 1.5))
            
            session = requests.Session()
            session.headers.update(headers)
            
            response = session.get(url, timeout=self.timeout, allow_redirects=True)
            response.encoding = response.apparent_encoding or 'utf-8'
            html = response.text
            
            title = ''
            content = ''
            extraction_method = 'auto'
            
            # 如果有匹配的规则，使用XPath提取
            if rule:
                rule_info = {
                    'id': rule.get('id'),
                    'name': rule.get('name'),
                    'site_name': rule.get('site_name')
                }
                
                try:
                    tree = etree.HTML(html)
                    
                    # 提取标题
                    if rule.get('title_xpath'):
                        title_result = tree.xpath(rule['title_xpath'])
                        if title_result:
                            if isinstance(title_result[0], str):
                                title = title_result[0].strip()
                            else:
                                title = title_result[0].text or etree.tostring(title_result[0], encoding='unicode', method='text').strip()
                    
                    # 提取内容
                    if rule.get('content_xpath'):
                        content_result = tree.xpath(rule['content_xpath'])
                        if content_result:
                            if isinstance(content_result[0], str):
                                content = content_result[0].strip()
                            else:
                                # 获取元素内所有文本
                                content_parts = []
                                for elem in content_result:
                                    if hasattr(elem, 'itertext'):
                                        for text in elem.itertext():
                                            text = text.strip()
                                            if text and len(text) > 10:
                                                content_parts.append(text)
                                    elif isinstance(elem, str):
                                        content_parts.append(elem.strip())
                                content = '\n\n'.join(content_parts)
                    
                    if content:
                        extraction_method = 'xpath_rule'
                        
                except Exception as e:
                    print(f"XPath提取失败: {e}")
            
            # 如果规则提取失败或没有规则，使用通用提取
            if not content:
                extraction_method = 'auto'
                content = self._auto_extract_content(html)
                
                # 如果自动提取成功且有规则但规则失败，可能需要更新规则
                if content and rule and article_id:
                    self._suggest_rule_update(rule, html, content)
            
            # 清理内容
            content = self._clean_content(content)
            
            return {
                'success': True,
                'title': title,
                'content': content,
                'url': url,
                'rule_used': rule_used,
                'rule_info': rule_info,
                'extraction_method': extraction_method,
                'message': '详细内容采集成功'
            }
            
        except Exception as e:
            return {
                'success': False,
                'title': '',
                'content': '',
                'url': url,
                'rule_used': rule_used,
                'rule_info': rule_info,
                'extraction_method': 'failed',
                'message': f'详细内容采集失败: {str(e)}'
            }
    
    def _auto_extract_content(self, html: str) -> str:
        """自动提取正文内容（通用方法）"""
        soup = BeautifulSoup(html, 'html.parser')
        
        # 移除无用标签
        for tag in soup(['script', 'style', 'nav', 'header', 'footer', 'aside', 'iframe', 'noscript', 'form']):
            tag.decompose()
        
        # 常见正文选择器
        selectors = [
            'article',
            '.article-content', '.article-body', '.article_content',
            '.content', '.post-content', '.entry-content',
            '.news-content', '.detail-content', '.main-content',
            '#article-content', '#content', '#main-content',
            '[class*="article-content"]', '[class*="news-content"]',
            '.text-content', '.body-content'
        ]
        
        for selector in selectors:
            elem = soup.select_one(selector)
            if elem:
                paragraphs = elem.find_all(['p', 'div', 'section'])
                texts = []
                for p in paragraphs:
                    text = p.get_text(strip=True)
                    if text and len(text) > 20:
                        texts.append(text)
                if texts and len('\n'.join(texts)) > 100:
                    return '\n\n'.join(texts)
        
        # 回退：获取所有段落
        body = soup.find('body')
        if body:
            paragraphs = body.find_all('p')
            texts = [p.get_text(strip=True) for p in paragraphs if len(p.get_text(strip=True)) > 30]
            if texts:
                return '\n\n'.join(texts)
        
        return ''
    
    def _clean_content(self, text: str) -> str:
        """清理正文内容"""
        if not text:
            return ''
        
        # 移除多余空白
        text = re.sub(r'[ \t]+', ' ', text)
        text = re.sub(r'\n{3,}', '\n\n', text)
        # 移除特殊字符
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
        
        return text.strip()[:10000]  # 限制长度
    
    def _suggest_rule_update(self, rule: Dict, html: str, extracted_content: str):
        """
        当规则提取失败但自动提取成功时，尝试发现新的XPath并建议更新规则
        
        Args:
            rule: 当前规则
            html: 页面HTML
            extracted_content: 自动提取的内容
        """
        try:
            from lxml import etree
            from app.models import CrawlerRule
            from app import db
            
            tree = etree.HTML(html)
            
            # 尝试发现新的内容XPath
            new_content_xpath = None
            content_sample = extracted_content[:100] if extracted_content else ''
            
            # 常见的内容容器XPath模式
            xpath_patterns = [
                '//article',
                '//div[contains(@class, "article")]',
                '//div[contains(@class, "content")]',
                '//div[contains(@class, "text")]',
                '//div[contains(@class, "body")]',
                '//div[contains(@id, "article")]',
                '//div[contains(@id, "content")]',
            ]
            
            for xpath in xpath_patterns:
                try:
                    result = tree.xpath(xpath)
                    if result:
                        elem = result[0]
                        elem_text = etree.tostring(elem, encoding='unicode', method='text')
                        # 检查是否包含提取的内容
                        if content_sample and content_sample in elem_text:
                            new_content_xpath = xpath
                            break
                except:
                    continue
            
            # 如果发现了新的有效XPath，更新规则
            if new_content_xpath and new_content_xpath != rule.get('content_xpath'):
                rule_obj = CrawlerRule.query.get(rule['id'])
                if rule_obj:
                    old_xpath = rule_obj.content_xpath
                    rule_obj.content_xpath = new_content_xpath
                    db.session.commit()
                    print(f"规则自动更新: {rule['name']}, 内容XPath: {old_xpath} -> {new_content_xpath}")
                    
                    # 清除缓存
                    self._cache_time = None
                    
        except Exception as e:
            print(f"规则更新建议失败: {e}")


# 用于Flask应用集成的服务类
class CrawlerService:
    """采集服务，用于与Flask应用集成"""
    
    def __init__(self):
        self.deep_crawler = DeepCrawler()
        self.crawlers = {}
        # 初始化所有数据源采集器
        for source_id, config in DATA_SOURCES.items():
            if config['enabled']:
                self.crawlers[source_id] = config['crawler']()
    
    @staticmethod
    def get_available_sources() -> List[Dict[str, Any]]:
        """获取所有可用的数据源列表"""
        sources = []
        for source_id, config in DATA_SOURCES.items():
            sources.append({
                'id': source_id,
                'name': config['name'],
                'enabled': config['enabled']
            })
        return sources
    
    def crawl(self, keyword: str, pages: int = 1, sources: List[str] = None) -> Dict[str, Any]:
        """
        执行采集任务（支持多数据源）
        
        Args:
            keyword: 搜索关键词
            pages: 采集页数
            sources: 数据源ID列表，为空则使用所有可用数据源
            
        Returns:
            采集结果字典，包含 success, data, count, message
        """
        try:
            # 如果未指定数据源，使用所有可用数据源
            if not sources:
                sources = list(self.crawlers.keys())
            
            all_results = []
            source_stats = {}
            
            for source_id in sources:
                if source_id not in self.crawlers:
                    continue
                
                crawler = self.crawlers[source_id]
                source_name = DATA_SOURCES[source_id]['name']
                
                try:
                    if pages == 1:
                        news_list = crawler.search(keyword)
                    else:
                        news_list = crawler.crawl_multiple_pages(keyword, pages)
                    
                    # 为每条新闻添加数据源标识
                    for news in news_list:
                        news.keyword = keyword
                        news_dict = news.to_dict()
                        news_dict['data_source'] = source_id
                        news_dict['data_source_name'] = source_name
                        all_results.append(news_dict)
                    
                    source_stats[source_name] = len(news_list)
                except Exception as e:
                    print(f"数据源 {source_name} 采集失败: {e}")
                    source_stats[source_name] = 0
            
            # 生成统计信息
            stats_msg = ', '.join([f'{name}: {count}条' for name, count in source_stats.items()])
            
            return {
                'success': True,
                'data': all_results,
                'count': len(all_results),
                'keyword': keyword,
                'sources': sources,
                'source_stats': source_stats,
                'message': f'成功采集 {len(all_results)} 条新闻 ({stats_msg})'
            }
        except Exception as e:
            return {
                'success': False,
                'data': [],
                'count': 0,
                'keyword': keyword,
                'message': f'采集失败: {str(e)}'
            }
    
    def deep_crawl(self, url: str) -> Dict[str, Any]:
        """
        深度采集单个URL
        
        Args:
            url: 新闻URL
            
        Returns:
            深度采集结果
        """
        return self.deep_crawler.crawl(url)


# 测试代码
if __name__ == '__main__':
    import json
    
    keyword = "西昌"
    print(f"开始采集关键词: {keyword}")
    print("-" * 50)
    
    # 使用服务类进行采集
    service = CrawlerService()
    result = service.crawl(keyword, pages=1)
    
    if result['success']:
        print(f"\n{result['message']}")
        print("-" * 50)
        
        for i, news in enumerate(result['data'], 1):
            print(f"\n【{i}】")
            print(f"标题: {news['title']}")
            print(f"概要: {news['summary'][:100]}..." if len(news['summary']) > 100 else f"概要: {news['summary']}")
            print(f"封面: {news['cover']}")
            print(f"原始URL: {news['url']}")
            print(f"来源: {news['source']}")
            print(f"发布时间: {news['publish_time']}")
        
        print("\n" + "=" * 50)
        print("JSON格式输出:")
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"采集失败: {result['message']}")
