/**
 * 舆情系统主脚本
 */

// API 基础路径
const API_BASE = '/api';

// 工具函数
const utils = {
    // 格式化日期
    formatDate(dateStr) {
        if (!dateStr) return '-';
        const date = new Date(dateStr);
        return date.toLocaleString('zh-CN');
    },
    
    // 格式化数字
    formatNumber(num) {
        if (num >= 10000) {
            return (num / 10000).toFixed(1) + '万';
        }
        return num.toString();
    },
    
    // 显示消息
    showMessage(message, type = 'info') {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type}`;
        alertDiv.textContent = message;
        
        const container = document.querySelector('.page-content') || document.body;
        container.insertBefore(alertDiv, container.firstChild);
        
        setTimeout(() => {
            alertDiv.remove();
        }, 3000);
    },
    
    // 确认对话框
    confirm(message) {
        return window.confirm(message);
    }
};

// API 请求封装
const api = {
    async request(url, options = {}) {
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json'
            }
        };
        
        const response = await fetch(API_BASE + url, {
            ...defaultOptions,
            ...options
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return response.json();
    },
    
    get(url) {
        return this.request(url);
    },
    
    post(url, data) {
        return this.request(url, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    },
    
    delete(url) {
        return this.request(url, {
            method: 'DELETE'
        });
    }
};

// 文章模块
const articles = {
    async load(page = 1, filters = {}) {
        const params = new URLSearchParams({ page, ...filters });
        const result = await api.get(`/articles?${params}`);
        return result.data;
    },
    
    async getDetail(id) {
        const result = await api.get(`/articles/${id}`);
        return result.data;
    }
};

// 预警模块
const alerts = {
    async load(page = 1, filters = {}) {
        const params = new URLSearchParams({ page, ...filters });
        const result = await api.get(`/alerts?${params}`);
        return result.data;
    },
    
    async handle(id) {
        const result = await api.post(`/alerts/${id}/handle`);
        return result;
    }
};

// 关键词模块
const keywords = {
    async load() {
        const result = await api.get('/keywords');
        return result.data;
    },
    
    async add(data) {
        const result = await api.post('/keywords', data);
        return result;
    },
    
    async remove(id) {
        const result = await api.delete(`/keywords/${id}`);
        return result;
    }
};

// 统计模块
const statistics = {
    async getOverview() {
        const result = await api.get('/statistics/overview');
        return result.data;
    },
    
    async getTrend(days = 7) {
        const result = await api.get(`/statistics/trend?days=${days}`);
        return result.data;
    }
};

// 图表初始化
const charts = {
    // 初始化趋势图
    initTrendChart(elementId, data) {
        const ctx = document.getElementById(elementId);
        if (!ctx) return;
        
        // 使用 Chart.js 绑定图表
        if (typeof Chart !== 'undefined') {
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.dates,
                    datasets: [{
                        label: '文章数量',
                        data: data.counts,
                        borderColor: '#1890ff',
                        backgroundColor: 'rgba(24, 144, 255, 0.1)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
    },
    
    // 初始化情感分布图
    initSentimentChart(elementId, data) {
        const ctx = document.getElementById(elementId);
        if (!ctx) return;
        
        if (typeof Chart !== 'undefined') {
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['正面', '中性', '负面'],
                    datasets: [{
                        data: [
                            data.positive || 0,
                            data.neutral || 0,
                            data.negative || 0
                        ],
                        backgroundColor: ['#52c41a', '#1890ff', '#ff4d4f']
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }
    }
};

// 页面初始化
document.addEventListener('DOMContentLoaded', function() {
    // 侧边栏当前菜单高亮
    const currentPath = window.location.pathname;
    const menuLinks = document.querySelectorAll('.sidebar-menu a');
    menuLinks.forEach(link => {
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active');
        }
    });
    
    // 表单提交处理
    const forms = document.querySelectorAll('form[data-ajax]');
    forms.forEach(form => {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            const formData = new FormData(form);
            const data = Object.fromEntries(formData.entries());
            
            try {
                const result = await api.post(form.action, data);
                if (result.code === 0) {
                    utils.showMessage(result.message || '操作成功', 'success');
                    if (form.dataset.redirect) {
                        window.location.href = form.dataset.redirect;
                    }
                } else {
                    utils.showMessage(result.message || '操作失败', 'error');
                }
            } catch (error) {
                utils.showMessage('请求失败: ' + error.message, 'error');
            }
        });
    });
    
    // 删除确认
    const deleteButtons = document.querySelectorAll('[data-delete]');
    deleteButtons.forEach(btn => {
        btn.addEventListener('click', async function(e) {
            e.preventDefault();
            if (!utils.confirm('确定要删除吗？')) return;
            
            try {
                const result = await api.delete(btn.dataset.delete);
                if (result.code === 0) {
                    utils.showMessage('删除成功', 'success');
                    btn.closest('tr')?.remove();
                } else {
                    utils.showMessage(result.message || '删除失败', 'error');
                }
            } catch (error) {
                utils.showMessage('请求失败: ' + error.message, 'error');
            }
        });
    });
});

// 导出模块
window.app = {
    utils,
    api,
    articles,
    alerts,
    keywords,
    statistics,
    charts
};
