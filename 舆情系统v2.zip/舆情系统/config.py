"""
政企智能舆情分析报告生成智能体应用系统 - 配置文件
技术栈: Flask + SQLite + Layui
"""
import os
from datetime import timedelta

basedir = os.path.abspath(os.path.dirname(__file__))


class Config:
    """基础配置"""
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'yuqing-secret-key-2024'
    
    # 数据库配置 - SQLite
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(basedir, 'yuqing.db')
    
    # Session配置
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)
    
    # 分页配置
    PER_PAGE = 10
    
    # 系统默认配置
    APP_NAME = '政企智能舆情分析报告生成智能体应用系统'
    APP_SHORT_NAME = '智能舆情系统'
    
    @staticmethod
    def init_app(app):
        pass


class DevelopmentConfig(Config):
    """开发环境配置"""
    DEBUG = True


class ProductionConfig(Config):
    """生产环境配置"""
    DEBUG = False


config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}
