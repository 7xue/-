"""
政企智能舆情分析报告生成智能体应用系统 - 数据模型
"""
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from app import db, login_manager


class Role(db.Model):
    """角色模型"""
    __tablename__ = 'roles'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True, nullable=False)  # admin, user
    display_name = db.Column(db.String(64), nullable=False)  # 管理员, 普通用户
    description = db.Column(db.String(256))
    permissions = db.Column(db.Text)  # JSON格式的权限列表
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    users = db.relationship('User', backref='role', lazy='dynamic')
    
    def __repr__(self):
        return f'<Role {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'display_name': self.display_name,
            'description': self.description
        }


class User(UserMixin, db.Model):
    """用户模型"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, index=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    real_name = db.Column(db.String(64))  # 真实姓名
    email = db.Column(db.String(120))
    phone = db.Column(db.String(20))
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'))
    is_active = db.Column(db.Boolean, default=True)
    last_login = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def set_password(self, password):
        """设置密码（加密存储）"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """验证密码"""
        return check_password_hash(self.password_hash, password)
    
    def is_admin(self):
        """判断是否为管理员"""
        return self.role and self.role.name == 'admin'
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'real_name': self.real_name,
            'email': self.email,
            'phone': self.phone,
            'role_id': self.role_id,
            'role_name': self.role.display_name if self.role else '',
            'is_active': self.is_active,
            'last_login': self.last_login.strftime('%Y-%m-%d %H:%M:%S') if self.last_login else '',
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else ''
        }
    
    def __repr__(self):
        return f'<User {self.username}>'


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class SystemSetting(db.Model):
    """系统设置模型"""
    __tablename__ = 'system_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(64), unique=True, nullable=False)
    value = db.Column(db.Text)
    description = db.Column(db.String(256))
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @staticmethod
    def get(key, default=None):
        """获取设置值"""
        setting = SystemSetting.query.filter_by(key=key).first()
        return setting.value if setting else default
    
    @staticmethod
    def set(key, value, description=None):
        """设置值"""
        setting = SystemSetting.query.filter_by(key=key).first()
        if setting:
            setting.value = value
            if description:
                setting.description = description
        else:
            setting = SystemSetting(key=key, value=value, description=description)
            db.session.add(setting)
        db.session.commit()
        return setting
    
    def __repr__(self):
        return f'<SystemSetting {self.key}>'


class Report(db.Model):
    """舆情报告模型"""
    __tablename__ = 'reports'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(256), nullable=False)
    content = db.Column(db.Text)
    report_type = db.Column(db.String(64))  # daily, weekly, monthly, special
    status = db.Column(db.String(20), default='draft')  # draft, published
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    author = db.relationship('User', backref='reports')
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'report_type': self.report_type,
            'status': self.status,
            'author': self.author.real_name if self.author else '',
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else ''
        }
    
    def __repr__(self):
        return f'<Report {self.title[:20]}>'


class Article(db.Model):
    """舆情文章模型"""
    __tablename__ = 'articles'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(512), nullable=False)  # 标题
    summary = db.Column(db.Text)  # 概要/摘要
    content = db.Column(db.Text)  # 概要/内容（兼容旧字段）
    full_content = db.Column(db.Text)  # 深度采集的完整正文
    url = db.Column(db.String(1024), unique=True)  # 原始URL
    source = db.Column(db.String(128))  # 来源
    cover_image = db.Column(db.String(1024))  # 封面图片URL
    publish_time = db.Column(db.String(64))  # 发布时间（原始格式）
    keyword = db.Column(db.String(128))  # 采集关键词
    sentiment = db.Column(db.String(20))  # 情感: positive, negative, neutral
    category = db.Column(db.String(64))  # 分类
    is_important = db.Column(db.Boolean, default=False)  # 是否重要
    is_deep_crawled = db.Column(db.Boolean, default=False)  # 是否已深度采集
    deep_crawled_at = db.Column(db.DateTime)  # 深度采集时间
    # AI分析字段
    ai_summary = db.Column(db.Text)  # AI生成的摘要
    ai_keywords = db.Column(db.String(512))  # AI提取的关键词（逗号分隔）
    ai_analyzed_at = db.Column(db.DateTime)  # AI分析时间
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    author = db.relationship('User', backref='articles')
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'summary': self.summary or self.content,
            'content': self.content,
            'full_content': self.full_content,
            'url': self.url,
            'source': self.source,
            'cover_image': self.cover_image,
            'publish_time': self.publish_time,
            'keyword': self.keyword,
            'sentiment': self.sentiment,
            'category': self.category,
            'is_important': self.is_important,
            'is_deep_crawled': self.is_deep_crawled,
            'deep_crawled_at': self.deep_crawled_at.strftime('%Y-%m-%d %H:%M:%S') if self.deep_crawled_at else '',
            'ai_summary': self.ai_summary,
            'ai_keywords': self.ai_keywords.split(',') if self.ai_keywords else [],
            'ai_analyzed_at': self.ai_analyzed_at.strftime('%Y-%m-%d %H:%M:%S') if self.ai_analyzed_at else '',
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else ''
        }
    
    def __repr__(self):
        return f'<Article {self.title[:30]}>'


class Keyword(db.Model):
    """监控关键词模型"""
    __tablename__ = 'keywords'
    
    id = db.Column(db.Integer, primary_key=True)
    word = db.Column(db.String(128), unique=True, nullable=False)  # 关键词
    category = db.Column(db.String(64))  # 分类
    priority = db.Column(db.Integer, default=1)  # 优先级
    is_active = db.Column(db.Boolean, default=True)  # 是否启用
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'word': self.word,
            'category': self.category,
            'priority': self.priority,
            'is_active': self.is_active
        }
    
    def __repr__(self):
        return f'<Keyword {self.word}>'


class Alert(db.Model):
    """预警模型"""
    __tablename__ = 'alerts'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(256), nullable=False)
    content = db.Column(db.Text)
    level = db.Column(db.String(20), default='normal')  # low, normal, high, urgent
    article_id = db.Column(db.Integer, db.ForeignKey('articles.id'))
    is_read = db.Column(db.Boolean, default=False)
    is_handled = db.Column(db.Boolean, default=False)
    handled_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    handled_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    article = db.relationship('Article', backref='alerts')
    handler = db.relationship('User', backref='handled_alerts')
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'level': self.level,
            'is_read': self.is_read,
            'is_handled': self.is_handled,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else ''
        }
    
    def __repr__(self):
        return f'<Alert {self.title[:20]}>'


class CrawlerRule(db.Model):
    """采集规则模型"""
    __tablename__ = 'crawler_rules'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False)  # 规则名称
    site_domain = db.Column(db.String(256), nullable=False)  # 站点域名
    site_name = db.Column(db.String(128))  # 站点名称
    description = db.Column(db.String(512))  # 规则描述
    
    # XPath规则
    title_xpath = db.Column(db.String(512))  # 标题XPath
    content_xpath = db.Column(db.String(512))  # 详细内容XPath
    
    # 请求头配置（JSON格式）
    request_headers = db.Column(db.Text)  # Request Headers
    
    # 状态
    is_active = db.Column(db.Boolean, default=True)  # 是否启用
    priority = db.Column(db.Integer, default=0)  # 优先级，数值越大优先级越高
    
    # 时间戳
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    creator = db.relationship('User', backref='crawler_rules')
    
    def to_dict(self):
        import json
        headers = {}
        if self.request_headers:
            try:
                headers = json.loads(self.request_headers)
            except:
                pass
        
        return {
            'id': self.id,
            'name': self.name,
            'site_domain': self.site_domain,
            'site_name': self.site_name,
            'description': self.description,
            'title_xpath': self.title_xpath,
            'content_xpath': self.content_xpath,
            'request_headers': self.request_headers,
            'request_headers_dict': headers,
            'is_active': self.is_active,
            'priority': self.priority,
            'created_by': self.created_by,
            'creator_name': self.creator.real_name if self.creator else '',
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else '',
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S') if self.updated_at else ''
        }
    
    def __repr__(self):
        return f'<CrawlerRule {self.name}>'


class AIEngine(db.Model):
    """AI引擎模型 - 用于管理接入的大模型服务"""
    __tablename__ = 'ai_engines'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)  # 引擎名称
    provider = db.Column(db.String(50), nullable=False)  # 服务商（如：OpenAI, SiliconFlow, Azure等）
    model_name = db.Column(db.String(100), nullable=False)  # 模型名称
    api_base = db.Column(db.String(255), nullable=False)  # API基础地址
    api_key = db.Column(db.String(255), nullable=False)  # API密钥
    description = db.Column(db.Text)  # 描述
    icon = db.Column(db.String(50), default='layui-icon-engine')  # 图标
    color = db.Column(db.String(20), default='#667eea')  # 主题色
    max_tokens = db.Column(db.Integer, default=4096)  # 最大token数
    temperature = db.Column(db.Float, default=0.7)  # 温度参数
    is_active = db.Column(db.Boolean, default=True)  # 是否启用
    is_default = db.Column(db.Boolean, default=False)  # 是否为默认引擎
    priority = db.Column(db.Integer, default=0)  # 优先级
    extra_params = db.Column(db.Text)  # 额外参数（JSON格式）
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    creator = db.relationship('User', backref='ai_engines')
    
    def to_dict(self, hide_key=True):
        """转换为字典，可选择是否隐藏API密钥"""
        import json
        extra = {}
        if self.extra_params:
            try:
                extra = json.loads(self.extra_params)
            except:
                pass
        
        api_key_display = self.api_key
        if hide_key and self.api_key:
            # 只显示前8位和后4位
            if len(self.api_key) > 12:
                api_key_display = self.api_key[:8] + '****' + self.api_key[-4:]
            else:
                api_key_display = '****'
        
        return {
            'id': self.id,
            'name': self.name,
            'provider': self.provider,
            'model_name': self.model_name,
            'api_base': self.api_base,
            'api_key': api_key_display,
            'api_key_full': self.api_key if not hide_key else None,
            'description': self.description,
            'icon': self.icon,
            'color': self.color,
            'max_tokens': self.max_tokens,
            'temperature': self.temperature,
            'is_active': self.is_active,
            'is_default': self.is_default,
            'priority': self.priority,
            'extra_params': self.extra_params,
            'extra_params_dict': extra,
            'created_by': self.created_by,
            'creator_name': self.creator.real_name if self.creator else '',
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else '',
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S') if self.updated_at else ''
        }
    
    def __repr__(self):
        return f'<AIEngine {self.name}>'
