"""
后台管理视图
"""
from flask import render_template, request, jsonify, current_app
from flask_login import login_required, current_user
from functools import wraps
from app.admin import admin
from app.models import User, Role, SystemSetting, CrawlerRule, AIEngine
from app import db
import json


def admin_required(f):
    """管理员权限装饰器"""
    @wraps(f)
    @login_required
    def decorated_function(*args, **kwargs):
        if not current_user.is_admin():
            return jsonify({'code': 403, 'msg': '无权限访问'}), 403
        return f(*args, **kwargs)
    return decorated_function


@admin.route('/')
@admin_required
def index():
    """后台首页"""
    return render_template('admin/index.html')


# ============ 用户管理 ============
@admin.route('/users')
@admin_required
def users():
    """用户管理页面"""
    return render_template('admin/users.html')


@admin.route('/api/users')
@admin_required
def api_users():
    """获取用户列表API"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    username = request.args.get('username', '')
    
    query = User.query
    if username:
        query = query.filter(User.username.like(f'%{username}%'))
    
    pagination = query.order_by(User.id.desc()).paginate(page=page, per_page=limit, error_out=False)
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': pagination.total,
        'data': [user.to_dict() for user in pagination.items]
    })


@admin.route('/api/users', methods=['POST'])
@admin_required
def api_add_user():
    """添加用户API"""
    data = request.get_json()
    
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'code': 1, 'msg': '用户名已存在'})
    
    user = User(
        username=data['username'],
        real_name=data.get('real_name', ''),
        email=data.get('email', ''),
        phone=data.get('phone', ''),
        role_id=data.get('role_id'),
        is_active=data.get('is_active', True)
    )
    user.set_password(data['password'])
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '添加成功'})


@admin.route('/api/users/<int:id>', methods=['PUT'])
@admin_required
def api_update_user(id):
    """更新用户API"""
    user = User.query.get_or_404(id)
    data = request.get_json()
    
    if data.get('username') and data['username'] != user.username:
        if User.query.filter_by(username=data['username']).first():
            return jsonify({'code': 1, 'msg': '用户名已存在'})
        user.username = data['username']
    
    if data.get('real_name'):
        user.real_name = data['real_name']
    if data.get('email'):
        user.email = data['email']
    if data.get('phone'):
        user.phone = data['phone']
    if data.get('role_id'):
        user.role_id = data['role_id']
    if 'is_active' in data:
        user.is_active = data['is_active']
    if data.get('password'):
        user.set_password(data['password'])
    
    db.session.commit()
    return jsonify({'code': 0, 'msg': '更新成功'})


@admin.route('/api/users/<int:id>', methods=['DELETE'])
@admin_required
def api_delete_user(id):
    """删除用户API"""
    if id == current_user.id:
        return jsonify({'code': 1, 'msg': '不能删除当前登录用户'})
    
    user = User.query.get_or_404(id)
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '删除成功'})


# ============ 角色管理 ============
@admin.route('/roles')
@admin_required
def roles():
    """角色管理页面"""
    return render_template('admin/roles.html')


@admin.route('/api/roles')
@admin_required
def api_roles():
    """获取角色列表API"""
    roles = Role.query.all()
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': len(roles),
        'data': [role.to_dict() for role in roles]
    })


@admin.route('/api/roles', methods=['POST'])
@admin_required
def api_add_role():
    """添加角色API"""
    data = request.get_json()
    
    if Role.query.filter_by(name=data['name']).first():
        return jsonify({'code': 1, 'msg': '角色标识已存在'})
    
    role = Role(
        name=data['name'],
        display_name=data['display_name'],
        description=data.get('description', '')
    )
    db.session.add(role)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '添加成功'})


@admin.route('/api/roles/<int:id>', methods=['PUT'])
@admin_required
def api_update_role(id):
    """更新角色API"""
    role = Role.query.get_or_404(id)
    data = request.get_json()
    
    role.display_name = data.get('display_name', role.display_name)
    role.description = data.get('description', role.description)
    
    db.session.commit()
    return jsonify({'code': 0, 'msg': '更新成功'})


@admin.route('/api/roles/<int:id>', methods=['DELETE'])
@admin_required
def api_delete_role(id):
    """删除角色API"""
    role = Role.query.get_or_404(id)
    
    if role.name in ['admin', 'user']:
        return jsonify({'code': 1, 'msg': '系统内置角色不能删除'})
    
    if role.users.count() > 0:
        return jsonify({'code': 1, 'msg': '该角色下存在用户，不能删除'})
    
    db.session.delete(role)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '删除成功'})


# ============ 系统设置 ============
@admin.route('/settings')
@admin_required
def settings():
    """系统设置页面"""
    return render_template('admin/settings.html')


@admin.route('/api/settings')
@admin_required
def api_get_settings():
    """获取系统设置API"""
    settings = SystemSetting.query.all()
    return jsonify({
        'code': 0,
        'data': {s.key: s.value for s in settings}
    })


@admin.route('/api/settings', methods=['POST'])
@admin_required
def api_save_settings():
    """保存系统设置API"""
    data = request.get_json()
    
    for key, value in data.items():
        SystemSetting.set(key, value)
    
    return jsonify({'code': 0, 'msg': '保存成功'})


# ============ 数据采集管理 ============
@admin.route('/crawler')
@admin_required
def crawler():
    """数据采集管理页面"""
    return render_template('admin/crawler.html')


# ============ 采集规则库 ============
@admin.route('/crawler-rules')
@admin_required
def crawler_rules():
    """采集规则库页面"""
    return render_template('admin/crawler_rules.html')


@admin.route('/api/crawler-rules')
@admin_required
def api_crawler_rules():
    """获取采集规则列表API"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    keyword = request.args.get('keyword', '').strip()
    is_active = request.args.get('is_active', '')
    
    query = CrawlerRule.query
    
    if keyword:
        query = query.filter(
            db.or_(
                CrawlerRule.name.like(f'%{keyword}%'),
                CrawlerRule.site_domain.like(f'%{keyword}%'),
                CrawlerRule.site_name.like(f'%{keyword}%')
            )
        )
    if is_active == '1':
        query = query.filter(CrawlerRule.is_active == True)
    elif is_active == '0':
        query = query.filter(CrawlerRule.is_active == False)
    
    total = query.count()
    rules = query.order_by(CrawlerRule.priority.desc(), CrawlerRule.id.desc()).offset((page - 1) * limit).limit(limit).all()
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': total,
        'data': [r.to_dict() for r in rules]
    })


@admin.route('/api/crawler-rules', methods=['POST'])
@admin_required
def api_add_crawler_rule():
    """添加采集规则API"""
    data = request.get_json()
    
    # 验证必填字段
    if not data.get('name'):
        return jsonify({'code': 1, 'msg': '规则名称不能为空'})
    if not data.get('site_domain'):
        return jsonify({'code': 1, 'msg': '站点域名不能为空'})
    
    # 检查域名是否已存在
    existing = CrawlerRule.query.filter_by(site_domain=data['site_domain']).first()
    if existing:
        return jsonify({'code': 1, 'msg': '该站点域名的规则已存在'})
    
    # 处理请求头
    headers_str = data.get('request_headers', '')
    if headers_str:
        try:
            # 验证JSON格式
            json.loads(headers_str)
        except:
            return jsonify({'code': 1, 'msg': 'Request Headers格式错误，请输入有效的JSON'})
    
    rule = CrawlerRule(
        name=data['name'],
        site_domain=data['site_domain'],
        site_name=data.get('site_name', ''),
        description=data.get('description', ''),
        title_xpath=data.get('title_xpath', ''),
        content_xpath=data.get('content_xpath', ''),
        request_headers=headers_str,
        is_active=data.get('is_active', True),
        priority=data.get('priority', 0),
        created_by=current_user.id
    )
    
    db.session.add(rule)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '添加成功', 'data': rule.to_dict()})


@admin.route('/api/crawler-rules/<int:id>')
@admin_required
def api_get_crawler_rule(id):
    """获取单个采集规则API"""
    rule = CrawlerRule.query.get_or_404(id)
    return jsonify({'code': 0, 'data': rule.to_dict()})


@admin.route('/api/crawler-rules/<int:id>', methods=['PUT'])
@admin_required
def api_update_crawler_rule(id):
    """更新采集规则API"""
    rule = CrawlerRule.query.get_or_404(id)
    data = request.get_json()
    
    # 检查域名是否与其他规则冲突
    if data.get('site_domain') and data['site_domain'] != rule.site_domain:
        existing = CrawlerRule.query.filter_by(site_domain=data['site_domain']).first()
        if existing:
            return jsonify({'code': 1, 'msg': '该站点域名的规则已存在'})
        rule.site_domain = data['site_domain']
    
    # 处理请求头
    if 'request_headers' in data:
        headers_str = data['request_headers']
        if headers_str:
            try:
                json.loads(headers_str)
            except:
                return jsonify({'code': 1, 'msg': 'Request Headers格式错误，请输入有效的JSON'})
        rule.request_headers = headers_str
    
    if 'name' in data:
        rule.name = data['name']
    if 'site_name' in data:
        rule.site_name = data['site_name']
    if 'description' in data:
        rule.description = data['description']
    if 'title_xpath' in data:
        rule.title_xpath = data['title_xpath']
    if 'content_xpath' in data:
        rule.content_xpath = data['content_xpath']
    if 'is_active' in data:
        rule.is_active = data['is_active']
    if 'priority' in data:
        rule.priority = data['priority']
    
    db.session.commit()
    return jsonify({'code': 0, 'msg': '更新成功', 'data': rule.to_dict()})


@admin.route('/api/crawler-rules/<int:id>', methods=['DELETE'])
@admin_required
def api_delete_crawler_rule(id):
    """删除采集规则API"""
    rule = CrawlerRule.query.get_or_404(id)
    db.session.delete(rule)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '删除成功'})


@admin.route('/api/crawler-rules/batch-delete', methods=['POST'])
@admin_required
def api_batch_delete_crawler_rules():
    """批量删除采集规则API"""
    data = request.get_json()
    ids = data.get('ids', [])
    
    if not ids:
        return jsonify({'code': 1, 'msg': '请选择要删除的规则'})
    
    CrawlerRule.query.filter(CrawlerRule.id.in_(ids)).delete(synchronize_session=False)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': f'成功删除 {len(ids)} 条规则'})


@admin.route('/api/crawler-rules/<int:id>/toggle', methods=['POST'])
@admin_required
def api_toggle_crawler_rule(id):
    """切换采集规则启用状态API"""
    rule = CrawlerRule.query.get_or_404(id)
    rule.is_active = not rule.is_active
    db.session.commit()
    
    status = '启用' if rule.is_active else '禁用'
    return jsonify({'code': 0, 'msg': f'规则已{status}', 'data': rule.to_dict()})


# ==================== AI引擎管理 ====================

@admin.route('/ai-engines')
@admin_required
def ai_engines():
    """AI引擎管理页面"""
    return render_template('admin/ai_engines.html')


@admin.route('/api/ai-engines', methods=['GET'])
@admin_required
def api_list_ai_engines():
    """获取AI引擎列表API"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 20, type=int)
    keyword = request.args.get('keyword', '')
    provider = request.args.get('provider', '')
    is_active = request.args.get('is_active', '')
    
    query = AIEngine.query
    
    if keyword:
        query = query.filter(
            db.or_(
                AIEngine.name.like(f'%{keyword}%'),
                AIEngine.model_name.like(f'%{keyword}%')
            )
        )
    
    if provider:
        query = query.filter(AIEngine.provider == provider)
    
    if is_active != '':
        query = query.filter(AIEngine.is_active == (is_active == '1'))
    
    query = query.order_by(AIEngine.is_default.desc(), AIEngine.priority.desc(), AIEngine.id.desc())
    
    pagination = query.paginate(page=page, per_page=limit, error_out=False)
    engines = pagination.items
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': pagination.total,
        'data': [e.to_dict() for e in engines]
    })


@admin.route('/api/ai-engines', methods=['POST'])
@admin_required
def api_add_ai_engine():
    """新增AI引擎API"""
    data = request.get_json() or {}
    
    name = data.get('name', '').strip()
    provider = data.get('provider', '').strip()
    model_name = data.get('model_name', '').strip()
    api_base = data.get('api_base', '').strip()
    api_key = data.get('api_key', '').strip()
    
    if not name:
        return jsonify({'code': 1, 'msg': '请输入引擎名称'}), 400
    if not provider:
        return jsonify({'code': 1, 'msg': '请选择服务商'}), 400
    if not model_name:
        return jsonify({'code': 1, 'msg': '请输入模型名称'}), 400
    if not api_base:
        return jsonify({'code': 1, 'msg': '请输入API地址'}), 400
    if not api_key:
        return jsonify({'code': 1, 'msg': '请输入API密钥'}), 400
    
    # 如果设为默认，取消其他默认
    is_default = data.get('is_default', False)
    if is_default:
        AIEngine.query.filter_by(is_default=True).update({'is_default': False})
    
    engine = AIEngine(
        name=name,
        provider=provider,
        model_name=model_name,
        api_base=api_base,
        api_key=api_key,
        description=data.get('description', ''),
        icon=data.get('icon', 'layui-icon-engine'),
        color=data.get('color', '#667eea'),
        max_tokens=data.get('max_tokens', 4096),
        temperature=data.get('temperature', 0.7),
        is_active=data.get('is_active', True),
        is_default=is_default,
        priority=data.get('priority', 0),
        extra_params=data.get('extra_params', ''),
        created_by=current_user.id
    )
    
    db.session.add(engine)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '添加成功', 'data': engine.to_dict()})


@admin.route('/api/ai-engines/<int:id>', methods=['GET'])
@admin_required
def api_get_ai_engine(id):
    """获取单个AI引擎API"""
    engine = AIEngine.query.get_or_404(id)
    return jsonify({'code': 0, 'data': engine.to_dict(hide_key=False)})


@admin.route('/api/ai-engines/<int:id>', methods=['PUT'])
@admin_required
def api_update_ai_engine(id):
    """更新AI引擎API"""
    engine = AIEngine.query.get_or_404(id)
    data = request.get_json() or {}
    
    if 'name' in data:
        engine.name = data['name'].strip()
    if 'provider' in data:
        engine.provider = data['provider'].strip()
    if 'model_name' in data:
        engine.model_name = data['model_name'].strip()
    if 'api_base' in data:
        engine.api_base = data['api_base'].strip()
    if 'api_key' in data and data['api_key'].strip():
        engine.api_key = data['api_key'].strip()
    if 'description' in data:
        engine.description = data['description']
    if 'icon' in data:
        engine.icon = data['icon']
    if 'color' in data:
        engine.color = data['color']
    if 'max_tokens' in data:
        engine.max_tokens = data['max_tokens']
    if 'temperature' in data:
        engine.temperature = data['temperature']
    if 'is_active' in data:
        engine.is_active = data['is_active']
    if 'priority' in data:
        engine.priority = data['priority']
    if 'extra_params' in data:
        engine.extra_params = data['extra_params']
    
    # 处理默认引擎
    if data.get('is_default'):
        AIEngine.query.filter(AIEngine.id != id, AIEngine.is_default == True).update({'is_default': False})
        engine.is_default = True
    elif 'is_default' in data:
        engine.is_default = data['is_default']
    
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '更新成功', 'data': engine.to_dict()})


@admin.route('/api/ai-engines/<int:id>', methods=['DELETE'])
@admin_required
def api_delete_ai_engine(id):
    """删除AI引擎API"""
    engine = AIEngine.query.get_or_404(id)
    db.session.delete(engine)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '删除成功'})


@admin.route('/api/ai-engines/<int:id>/toggle', methods=['POST'])
@admin_required
def api_toggle_ai_engine(id):
    """切换AI引擎启用状态API"""
    engine = AIEngine.query.get_or_404(id)
    engine.is_active = not engine.is_active
    db.session.commit()
    
    status = '启用' if engine.is_active else '禁用'
    return jsonify({'code': 0, 'msg': f'引擎已{status}', 'data': engine.to_dict()})


@admin.route('/api/ai-engines/<int:id>/set-default', methods=['POST'])
@admin_required
def api_set_default_ai_engine(id):
    """设置默认AI引擎API"""
    engine = AIEngine.query.get_or_404(id)
    
    # 取消其他默认
    AIEngine.query.filter(AIEngine.id != id).update({'is_default': False})
    engine.is_default = True
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': f'已将 {engine.name} 设为默认引擎'})


@admin.route('/api/ai-engines/<int:id>/test', methods=['POST'])
@admin_required
def api_test_ai_engine(id):
    """测试AI引擎连接API"""
    import requests
    
    engine = AIEngine.query.get_or_404(id)
    
    try:
        # 构建测试请求
        headers = {
            'Authorization': f'Bearer {engine.api_key}',
            'Content-Type': 'application/json'
        }
        
        # 确保API地址格式正确
        api_url = engine.api_base.rstrip('/')
        if not api_url.endswith('/chat/completions'):
            api_url += '/chat/completions'
        
        payload = {
            'model': engine.model_name,
            'messages': [
                {'role': 'user', 'content': '你好，请简短回复一句话测试连接。'}
            ],
            'max_tokens': 50,
            'temperature': 0.7
        }
        
        response = requests.post(api_url, headers=headers, json=payload, timeout=30)
        
        if response.status_code == 200:
            result = response.json()
            reply = result.get('choices', [{}])[0].get('message', {}).get('content', '')
            return jsonify({
                'code': 0,
                'msg': '连接测试成功',
                'data': {
                    'reply': reply,
                    'model': result.get('model', engine.model_name),
                    'usage': result.get('usage', {})
                }
            })
        else:
            return jsonify({
                'code': 1,
                'msg': f'API返回错误: {response.status_code}',
                'data': {'error': response.text[:500]}
            }), 400
            
    except requests.Timeout:
        return jsonify({'code': 1, 'msg': '连接超时，请检查API地址'}), 400
    except requests.RequestException as e:
        return jsonify({'code': 1, 'msg': f'连接失败: {str(e)}'}), 400
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'测试失败: {str(e)}'}), 500
