"""
后台管理蓝图
"""
from flask import Blueprint

admin = Blueprint('admin', __name__)

from app.admin import views
