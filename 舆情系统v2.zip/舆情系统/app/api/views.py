"""
API视图
"""
from flask import request, jsonify
from flask_login import login_required, current_user
from app.api import api
from app.models import Article, Alert, Keyword, User
from app import db
from datetime import datetime, timedelta
from sqlalchemy import func


@api.route('/articles', methods=['GET'])
@login_required
def get_articles():
    """获取文章列表"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    query = Article.query.order_by(Article.created_at.desc())
    
    # 筛选
    sentiment = request.args.get('sentiment')
    if sentiment:
        query = query.filter_by(sentiment=sentiment)
    
    category = request.args.get('category')
    if category:
        query = query.filter_by(category=category)
    
    keyword = request.args.get('keyword')
    if keyword:
        query = query.filter(Article.title.contains(keyword) | Article.content.contains(keyword))
    
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'code': 0,
        'data': {
            'items': [article.to_dict() for article in pagination.items],
            'total': pagination.total,
            'page': page,
            'per_page': per_page,
            'pages': pagination.pages
        }
    })


@api.route('/articles/<int:id>', methods=['GET'])
@login_required
def get_article(id):
    """获取文章详情"""
    article = Article.query.get_or_404(id)
    return jsonify({
        'code': 0,
        'data': article.to_dict()
    })


@api.route('/alerts', methods=['GET'])
@login_required
def get_alerts():
    """获取预警列表"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    query = Alert.query.order_by(Alert.created_at.desc())
    
    level = request.args.get('level')
    if level:
        query = query.filter_by(level=level)
    
    is_handled = request.args.get('is_handled')
    if is_handled is not None:
        query = query.filter_by(is_handled=is_handled.lower() == 'true')
    
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'code': 0,
        'data': {
            'items': [{
                'id': alert.id,
                'title': alert.title,
                'content': alert.content,
                'level': alert.level,
                'is_read': alert.is_read,
                'is_handled': alert.is_handled,
                'created_at': alert.created_at.isoformat() if alert.created_at else None
            } for alert in pagination.items],
            'total': pagination.total,
            'page': page,
            'per_page': per_page
        }
    })


@api.route('/alerts/<int:id>/handle', methods=['POST'])
@login_required
def handle_alert(id):
    """处理预警"""
    alert = Alert.query.get_or_404(id)
    alert.is_handled = True
    alert.handled_by = current_user.id
    alert.handled_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'message': '预警已处理'
    })


@api.route('/keywords', methods=['GET'])
@login_required
def get_keywords():
    """获取关键词列表"""
    keywords = Keyword.query.order_by(Keyword.priority.desc()).all()
    return jsonify({
        'code': 0,
        'data': [{
            'id': kw.id,
            'word': kw.word,
            'category': kw.category,
            'priority': kw.priority,
            'is_active': kw.is_active
        } for kw in keywords]
    })


@api.route('/keywords', methods=['POST'])
@login_required
def add_keyword():
    """添加关键词"""
    data = request.get_json()
    
    if Keyword.query.filter_by(word=data['word']).first():
        return jsonify({
            'code': 1,
            'message': '关键词已存在'
        }), 400
    
    keyword = Keyword(
        word=data['word'],
        category=data.get('category'),
        priority=data.get('priority', 1),
        created_by=current_user.id
    )
    db.session.add(keyword)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'message': '关键词添加成功',
        'data': {'id': keyword.id}
    })


@api.route('/keywords/<int:id>', methods=['DELETE'])
@login_required
def delete_keyword(id):
    """删除关键词"""
    keyword = Keyword.query.get_or_404(id)
    db.session.delete(keyword)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'message': '关键词已删除'
    })


@api.route('/statistics/overview', methods=['GET'])
@login_required
def get_overview():
    """获取概览统计"""
    today = datetime.utcnow().date()
    week_ago = today - timedelta(days=7)
    
    # 今日数据
    today_articles = Article.query.filter(
        func.date(Article.created_at) == today
    ).count()
    
    today_alerts = Alert.query.filter(
        func.date(Alert.created_at) == today
    ).count()
    
    # 总数据
    total_articles = Article.query.count()
    total_alerts = Alert.query.count()
    pending_alerts = Alert.query.filter_by(is_handled=False).count()
    
    # 情感分布
    sentiment_stats = db.session.query(
        Article.sentiment,
        func.count(Article.id)
    ).group_by(Article.sentiment).all()
    
    return jsonify({
        'code': 0,
        'data': {
            'today_articles': today_articles,
            'today_alerts': today_alerts,
            'total_articles': total_articles,
            'total_alerts': total_alerts,
            'pending_alerts': pending_alerts,
            'sentiment_stats': dict(sentiment_stats)
        }
    })


@api.route('/statistics/trend', methods=['GET'])
@login_required
def get_trend():
    """获取趋势数据"""
    days = request.args.get('days', 7, type=int)
    end_date = datetime.utcnow().date()
    start_date = end_date - timedelta(days=days)
    
    # 每日文章数
    daily_articles = db.session.query(
        func.date(Article.created_at).label('date'),
        func.count(Article.id).label('count')
    ).filter(
        Article.created_at >= start_date
    ).group_by(
        func.date(Article.created_at)
    ).all()
    
    return jsonify({
        'code': 0,
        'data': {
            'dates': [str(item.date) for item in daily_articles],
            'counts': [item.count for item in daily_articles]
        }
    })


# ==================== 数据采集接口 ====================

@api.route('/crawler/sources', methods=['GET'])
@login_required
def crawler_sources():
    """获取可用的数据源列表"""
    import sys
    import os
    tools_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'tools')
    if tools_path not in sys.path:
        sys.path.insert(0, tools_path)
    
    from crawler import CrawlerService
    
    sources = CrawlerService.get_available_sources()
    return jsonify({
        'code': 0,
        'data': sources
    })


@api.route('/crawler/search', methods=['POST'])
@login_required
def crawler_search():
    """
    采集新闻数据（支持多数据源）
    
    请求参数:
        keyword: 搜索关键词（必填）
        pages: 采集页数（可选，默认1）
        sources: 数据源ID列表（可选，默认全部）
        
    返回数据:
        每条新闻包含: title, summary, cover, url, source, publish_time, data_source
    """
    import sys
    import os
    # 添加tools目录到路径
    tools_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'tools')
    if tools_path not in sys.path:
        sys.path.insert(0, tools_path)
    
    from crawler import CrawlerService
    
    data = request.get_json() or {}
    keyword = data.get('keyword', '').strip()
    
    if not keyword:
        return jsonify({
            'code': 1,
            'message': '请输入搜索关键词'
        }), 400
    
    pages = data.get('pages', 1)
    if not isinstance(pages, int) or pages < 1:
        pages = 1
    if pages > 5:
        pages = 5  # 限制最大页数
    
    # 获取数据源列表
    sources = data.get('sources', [])
    if isinstance(sources, str):
        sources = [sources]
    
    # 执行采集
    service = CrawlerService()
    result = service.crawl(keyword, pages, sources if sources else None)
    
    if result['success']:
        return jsonify({
            'code': 0,
            'message': result['message'],
            'data': {
                'keyword': result['keyword'],
                'count': result['count'],
                'items': result['data'],
                'source_stats': result.get('source_stats', {})
            }
        })
    else:
        return jsonify({
            'code': 1,
            'message': result['message']
        }), 500


@api.route('/crawler/save', methods=['POST'])
@login_required
def crawler_save():
    """
    保存采集的新闻到数据库
    
    请求参数:
        items: 新闻列表，每条包含 title, summary, cover, url, source
    """
    data = request.get_json() or {}
    items = data.get('items', [])
    
    if not items:
        return jsonify({
            'code': 1,
            'message': '没有要保存的数据'
        }), 400
    
    saved_count = 0
    skipped_count = 0
    
    for item in items:
        # 检查是否已存在（通过URL判断）
        existing = Article.query.filter_by(url=item.get('url', '')).first()
        if existing:
            skipped_count += 1
            continue
        
        article = Article(
            title=item.get('title', ''),
            summary=item.get('summary', ''),
            content=item.get('summary', ''),
            full_content=item.get('full_content', ''),
            url=item.get('url', ''),
            source=item.get('source', ''),
            cover_image=item.get('cover', ''),
            publish_time=item.get('publish_time', ''),
            keyword=item.get('keyword', ''),
            is_deep_crawled=item.get('_deepCrawled', False),
            created_by=current_user.id
        )
        db.session.add(article)
        saved_count += 1
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'message': f'保存成功: {saved_count} 条，跳过重复: {skipped_count} 条',
        'data': {
            'saved': saved_count,
            'skipped': skipped_count
        }
    })


@api.route('/crawler/deep', methods=['POST'])
@login_required
def crawler_deep():
    """
    深度采集单个URL的正文内容
    
    请求参数:
        url: 新闻URL
    """
    import sys
    import os
    tools_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'tools')
    if tools_path not in sys.path:
        sys.path.insert(0, tools_path)
    
    from crawler import CrawlerService
    
    data = request.get_json() or {}
    url = data.get('url', '').strip()
    
    if not url:
        return jsonify({
            'code': 1,
            'message': '请提供URL'
        }), 400
    
    service = CrawlerService()
    result = service.deep_crawl(url)
    
    if result['success']:
        return jsonify({
            'code': 0,
            'message': result['message'],
            'data': {
                'content': result['content'],
                'url': result['url']
            }
        })
    else:
        return jsonify({
            'code': 1,
            'message': result['message']
        }), 500


@api.route('/crawler/saved', methods=['GET'])
@login_required
def crawler_saved_list():
    """获取已保存的采集数据列表"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    keyword = request.args.get('keyword', '')
    
    query = Article.query
    if keyword:
        query = query.filter(Article.keyword.like(f'%{keyword}%'))
    
    pagination = query.order_by(Article.created_at.desc()).paginate(
        page=page, per_page=limit, error_out=False
    )
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': pagination.total,
        'data': [article.to_dict() for article in pagination.items]
    })


@api.route('/crawler/saved/<int:id>', methods=['DELETE'])
@login_required
def crawler_saved_delete(id):
    """删除已保存的采集数据"""
    article = Article.query.get_or_404(id)
    db.session.delete(article)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'message': '删除成功'
    })


@api.route('/crawler/deep-saved/<int:id>', methods=['POST'])
@login_required
def crawler_deep_saved(id):
    """对已保存的数据执行深度采集"""
    import sys
    import os
    tools_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'tools')
    if tools_path not in sys.path:
        sys.path.insert(0, tools_path)
    
    from crawler import CrawlerService
    
    article = Article.query.get_or_404(id)
    
    if article.is_deep_crawled:
        return jsonify({
            'code': 1,
            'message': '该数据已完成深度采集'
        })
    
    service = CrawlerService()
    result = service.deep_crawl(article.url)
    
    if result['success']:
        article.full_content = result['content']
        article.is_deep_crawled = True
        article.deep_crawled_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'code': 0,
            'message': '深度采集成功',
            'data': {
                'content': result['content'][:200] + '...' if len(result['content']) > 200 else result['content']
            }
        })
    else:
        return jsonify({
            'code': 1,
            'message': result['message']
        }), 500


# ==================== 数据仓库管理 API ====================

@api.route('/warehouse/list', methods=['GET'])
@login_required
def warehouse_list():
    """
    获取数据仓库列表（分页）
    
    请求参数:
        page: 页码，默认1
        limit: 每页条数，默认20
        keyword: 搜索关键词（标题）
        source: 来源筛选
        is_deep_crawled: 是否已深度采集 (0/1)
    """
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 20, type=int)
    keyword = request.args.get('keyword', '').strip()
    source = request.args.get('source', '').strip()
    is_deep = request.args.get('is_deep_crawled', '')
    
    query = Article.query
    
    if keyword:
        query = query.filter(Article.title.like(f'%{keyword}%'))
    if source:
        query = query.filter(Article.source.like(f'%{source}%'))
    if is_deep == '1':
        query = query.filter(Article.is_deep_crawled == True)
    elif is_deep == '0':
        query = query.filter(Article.is_deep_crawled == False)
    
    total = query.count()
    articles = query.order_by(Article.created_at.desc()).offset((page - 1) * limit).limit(limit).all()
    
    return jsonify({
        'code': 0,
        'message': 'success',
        'count': total,
        'data': [a.to_dict() for a in articles]
    })


@api.route('/warehouse/detail/<int:id>', methods=['GET'])
@login_required
def warehouse_detail(id):
    """获取单条数据详情"""
    article = Article.query.get_or_404(id)
    return jsonify({
        'code': 0,
        'data': article.to_dict()
    })


@api.route('/warehouse/update/<int:id>', methods=['POST'])
@login_required
def warehouse_update(id):
    """
    更新数据
    
    请求参数:
        title: 标题
        summary: 摘要
        source: 来源
        category: 分类
        sentiment: 情感
        is_important: 是否重要
    """
    article = Article.query.get_or_404(id)
    data = request.get_json() or {}
    
    if 'title' in data:
        article.title = data['title']
    if 'summary' in data:
        article.summary = data['summary']
        article.content = data['summary']
    if 'source' in data:
        article.source = data['source']
    if 'category' in data:
        article.category = data['category']
    if 'sentiment' in data:
        article.sentiment = data['sentiment']
    if 'is_important' in data:
        article.is_important = data['is_important']
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'message': '更新成功',
        'data': article.to_dict()
    })


@api.route('/warehouse/delete/<int:id>', methods=['POST'])
@login_required
def warehouse_delete(id):
    """删除单条数据"""
    article = Article.query.get_or_404(id)
    db.session.delete(article)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'message': '删除成功'
    })


@api.route('/warehouse/batch-delete', methods=['POST'])
@login_required
def warehouse_batch_delete():
    """批量删除数据"""
    data = request.get_json() or {}
    ids = data.get('ids', [])
    
    if not ids:
        return jsonify({
            'code': 1,
            'message': '请选择要删除的数据'
        }), 400
    
    Article.query.filter(Article.id.in_(ids)).delete(synchronize_session=False)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'message': f'成功删除 {len(ids)} 条数据'
    })


@api.route('/warehouse/ai-analyze/<int:id>', methods=['POST'])
@login_required
def warehouse_ai_analyze(id):
    """
    AI分析数据
    
    请求参数:
        analyze_type: 分析类型 (sentiment/summary/keywords/category/full)
    """
    from tools.ai_service import ai_service
    
    article = Article.query.get_or_404(id)
    data = request.get_json() or {}
    analyze_type = data.get('analyze_type', 'full')
    
    # 获取文章内容
    title = article.title or ''
    content = article.full_content or article.content or article.summary or ''
    
    if not title and not content:
        return jsonify({
            'code': 1,
            'message': '文章内容为空，无法分析'
        }), 400
    
    # 根据分析类型调用不同的分析方法
    if analyze_type == 'sentiment':
        result = ai_service.analyze_sentiment(title, content)
        if result['success']:
            # 更新文章情感
            article.sentiment = result['sentiment']
            db.session.commit()
            return jsonify({
                'code': 0,
                'message': '情感分析完成',
                'data': {
                    'article_id': id,
                    'sentiment': result['sentiment'],
                    'confidence': result.get('confidence', 0),
                    'reason': result.get('reason', '')
                }
            })
    
    elif analyze_type == 'summary':
        result = ai_service.generate_summary(title, content)
        if result['success']:
            # 更新文章摘要
            article.ai_summary = result['summary']
            db.session.commit()
            return jsonify({
                'code': 0,
                'message': '摘要生成完成',
                'data': {
                    'article_id': id,
                    'summary': result['summary']
                }
            })
    
    elif analyze_type == 'keywords':
        result = ai_service.extract_keywords(title, content)
        if result['success']:
            # 更新文章关键词
            article.ai_keywords = ','.join(result['keywords'])
            db.session.commit()
            return jsonify({
                'code': 0,
                'message': '关键词提取完成',
                'data': {
                    'article_id': id,
                    'keywords': result['keywords']
                }
            })
    
    elif analyze_type == 'category':
        result = ai_service.classify_category(title, content)
        if result['success']:
            # 更新文章分类
            article.category = result['category']
            db.session.commit()
            return jsonify({
                'code': 0,
                'message': '分类完成',
                'data': {
                    'article_id': id,
                    'category': result['category'],
                    'reason': result.get('reason', '')
                }
            })
    
    else:  # full - 综合分析
        result = ai_service.full_analysis(title, content)
        if result['success']:
            # 更新所有字段
            article.sentiment = result['sentiment']
            article.ai_summary = result.get('summary', '')
            article.ai_keywords = ','.join(result.get('keywords', []))
            article.category = result.get('category', '')
            db.session.commit()
            return jsonify({
                'code': 0,
                'message': 'AI综合分析完成',
                'data': {
                    'article_id': id,
                    'sentiment': result['sentiment'],
                    'sentiment_confidence': result.get('sentiment_confidence', 0),
                    'summary': result.get('summary', ''),
                    'keywords': result.get('keywords', []),
                    'category': result.get('category', '')
                }
            })
    
    # 分析失败
    return jsonify({
        'code': 1,
        'message': result.get('error', 'AI分析失败')
    }), 500


@api.route('/warehouse/batch-ai-analyze', methods=['POST'])
@login_required
def warehouse_batch_ai_analyze():
    """
    批量AI分析
    
    请求参数:
        ids: 数据ID列表
        analyze_type: 分析类型 (sentiment/summary/keywords/category/full)
    """
    from tools.ai_service import ai_service
    
    data = request.get_json() or {}
    ids = data.get('ids', [])
    analyze_type = data.get('analyze_type', 'full')
    
    if not ids:
        return jsonify({
            'code': 1,
            'message': '请选择要分析的数据'
        }), 400
    
    articles = Article.query.filter(Article.id.in_(ids)).all()
    
    success_count = 0
    fail_count = 0
    results = []
    
    for article in articles:
        title = article.title or ''
        content = article.full_content or article.content or article.summary or ''
        
        if not title and not content:
            fail_count += 1
            results.append({
                'id': article.id,
                'title': article.title,
                'success': False,
                'error': '内容为空'
            })
            continue
        
        try:
            if analyze_type == 'full':
                result = ai_service.full_analysis(title, content)
                if result['success']:
                    article.sentiment = result['sentiment']
                    article.ai_summary = result.get('summary', '')
                    article.ai_keywords = ','.join(result.get('keywords', []))
                    article.category = result.get('category', '')
                    success_count += 1
                    results.append({
                        'id': article.id,
                        'title': article.title,
                        'success': True,
                        'sentiment': result['sentiment'],
                        'category': result.get('category', '')
                    })
                else:
                    fail_count += 1
                    results.append({
                        'id': article.id,
                        'title': article.title,
                        'success': False,
                        'error': result.get('error', '分析失败')
                    })
            
            elif analyze_type == 'sentiment':
                result = ai_service.analyze_sentiment(title, content)
                if result['success']:
                    article.sentiment = result['sentiment']
                    success_count += 1
                    results.append({
                        'id': article.id,
                        'title': article.title,
                        'success': True,
                        'sentiment': result['sentiment']
                    })
                else:
                    fail_count += 1
                    results.append({
                        'id': article.id,
                        'title': article.title,
                        'success': False,
                        'error': result.get('error', '分析失败')
                    })
            
            elif analyze_type == 'summary':
                result = ai_service.generate_summary(title, content)
                if result['success']:
                    article.ai_summary = result['summary']
                    success_count += 1
                    results.append({
                        'id': article.id,
                        'title': article.title,
                        'success': True
                    })
                else:
                    fail_count += 1
                    results.append({
                        'id': article.id,
                        'title': article.title,
                        'success': False,
                        'error': result.get('error', '生成失败')
                    })
            
            elif analyze_type == 'keywords':
                result = ai_service.extract_keywords(title, content)
                if result['success']:
                    article.ai_keywords = ','.join(result['keywords'])
                    success_count += 1
                    results.append({
                        'id': article.id,
                        'title': article.title,
                        'success': True,
                        'keywords': result['keywords']
                    })
                else:
                    fail_count += 1
                    results.append({
                        'id': article.id,
                        'title': article.title,
                        'success': False,
                        'error': result.get('error', '提取失败')
                    })
            
            elif analyze_type == 'category':
                result = ai_service.classify_category(title, content)
                if result['success']:
                    article.category = result['category']
                    success_count += 1
                    results.append({
                        'id': article.id,
                        'title': article.title,
                        'success': True,
                        'category': result['category']
                    })
                else:
                    fail_count += 1
                    results.append({
                        'id': article.id,
                        'title': article.title,
                        'success': False,
                        'error': result.get('error', '分类失败')
                    })
                    
        except Exception as e:
            fail_count += 1
            results.append({
                'id': article.id,
                'title': article.title,
                'success': False,
                'error': str(e)
            })
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'message': f'批量分析完成，成功: {success_count}，失败: {fail_count}',
        'data': {
            'success_count': success_count,
            'fail_count': fail_count,
            'total': len(ids),
            'analyze_type': analyze_type,
            'results': results
        }
    })


@api.route('/warehouse/detail-crawl/<int:id>', methods=['POST'])
@login_required
def warehouse_detail_crawl(id):
    """
    详细内容采集（基于规则库）
    
    通过来源匹配规则库中的站点名称进行规则匹配，
    使用规则库中的xpath+request headers进行定向解析
    """
    from tools.crawler import RuleBasedCrawler
    
    article = Article.query.get_or_404(id)
    
    if not article.url:
        return jsonify({
            'code': 1,
            'message': '文章URL为空，无法采集'
        }), 400
    
    crawler = RuleBasedCrawler()
    result = crawler.crawl_with_rule(
        url=article.url,
        source=article.source or '',
        article_id=article.id
    )
    
    if result['success'] and result['content']:
        # 更新文章内容
        if result.get('title'):
            article.title = result['title']
        article.full_content = result['content']
        article.is_deep_crawled = True
        db.session.commit()
        
        return jsonify({
            'code': 0,
            'message': '详细内容采集成功',
            'data': {
                'id': article.id,
                'title': article.title,
                'content': result['content'][:500] + '...' if len(result['content']) > 500 else result['content'],
                'rule_used': result.get('rule_used', False),
                'rule_info': result.get('rule_info'),
                'extraction_method': result.get('extraction_method', 'auto')
            }
        })
    else:
        return jsonify({
            'code': 1,
            'message': result.get('message', '详细内容采集失败')
        }), 500


@api.route('/warehouse/batch-detail-crawl', methods=['POST'])
@login_required
def warehouse_batch_detail_crawl():
    """
    批量详细内容采集（基于规则库）
    
    请求参数:
        ids: 数据ID列表
    """
    from tools.crawler import RuleBasedCrawler
    
    data = request.get_json() or {}
    ids = data.get('ids', [])
    
    if not ids:
        return jsonify({
            'code': 1,
            'message': '请选择要采集的数据'
        }), 400
    
    crawler = RuleBasedCrawler()
    success_count = 0
    fail_count = 0
    results = []
    
    articles = Article.query.filter(Article.id.in_(ids)).all()
    
    for article in articles:
        if not article.url:
            fail_count += 1
            results.append({
                'id': article.id,
                'title': article.title,
                'success': False,
                'message': 'URL为空'
            })
            continue
        
        result = crawler.crawl_with_rule(
            url=article.url,
            source=article.source or '',
            article_id=article.id
        )
        
        if result['success'] and result['content']:
            if result.get('title'):
                article.title = result['title']
            article.full_content = result['content']
            article.is_deep_crawled = True
            success_count += 1
            results.append({
                'id': article.id,
                'title': article.title,
                'success': True,
                'rule_used': result.get('rule_used', False),
                'extraction_method': result.get('extraction_method', 'auto')
            })
        else:
            fail_count += 1
            results.append({
                'id': article.id,
                'title': article.title,
                'success': False,
                'message': result.get('message', '采集失败')
            })
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'message': f'批量采集完成，成功: {success_count}，失败: {fail_count}',
        'data': {
            'success_count': success_count,
            'fail_count': fail_count,
            'total': len(ids),
            'results': results
        }
    })
