# 神人聊天室

一个基于 Flask + WebSocket 的多人在线聊天室应用。

## 功能特性

- 🔐 **登录系统**：用户输入昵称、密码登录，支持服务器选择
- 💬 **实时聊天**：基于 WebSocket 的实时消息推送
- 👥 **多人群聊**：支持多人同时在线聊天
- 😀 **Emoji表情**：内置丰富的 Emoji 表情选择器
- 📢 **@功能**：支持 @小理、@音乐一下、@电影、@天气、@新闻、@小视频（预留接口）
- 📱 **响应式设计**：自适应各种屏幕尺寸

## 技术栈

- **后端**：Python 3 + Flask + Flask-SocketIO
- **前端**：HTML5 + CSS3 + JavaScript + jQuery
- **通信**：WebSocket (Socket.IO)

## 项目结构

```
神人聊天室/
├── app.py                 # Flask 主应用
├── config.json            # 配置文件（服务器地址等）
├── requirements.txt       # Python 依赖
├── README.md             # 项目说明
├── templates/            # HTML 模板
│   ├── login.html        # 登录页面
│   └── chat.html         # 聊天室页面
└── static/               # 静态资源
    ├── css/
    │   ├── login.css     # 登录页样式
    │   └── chat.css      # 聊天室样式
    ├── js/
    │   ├── jquery-3.7.1.min.js  # jQuery（需手动添加）
    │   ├── login.js      # 登录页脚本
    │   └── chat.js       # 聊天室脚本
    └── images/           # 图片资源
```

## 安装与运行

### 1. 创建虚拟环境

```bash
cd 神人聊天室
python -m venv venv
```

### 2. 激活虚拟环境

**Windows:**
```bash
venv\Scripts\activate
```

**Linux/Mac:**
```bash
source venv/bin/activate
```

### 3. 安装依赖

```bash
pip install -r requirements.txt
```

### 4. 添加 jQuery

将 `jquery-3.7.1.min.js` 文件复制到 `static/js/` 目录下。

### 5. 运行应用

```bash
python app.py
```

### 6. 访问应用

打开浏览器访问：http://localhost:5000

## 配置说明

编辑 `config.json` 文件可以配置：

- **servers**：WebSocket 服务器地址列表
- **app.name**：应用名称
- **app.password**：登录密码（默认：123456）

## 使用说明

1. 在登录页面输入昵称和密码（123456）
2. 选择服务器并点击登录
3. 进入聊天室后即可与其他在线用户聊天
4. 点击表情按钮可以发送 Emoji
5. 点击 @ 按钮可以使用特殊功能（开发中）
6. 点击退出按钮返回登录页面

## 开发计划

- [x] 登录功能
- [x] 实时聊天
- [x] Emoji 表情
- [x] @功能预留接口
- [ ] 历史记录查看
- [ ] @小理 AI 对话
- [ ] @音乐一下 音乐播放
- [ ] @电影 电影推荐
- [ ] @天气 天气查询
- [ ] @新闻 新闻推送
- [ ] @小视频 视频推荐

## 许可证

MIT License
