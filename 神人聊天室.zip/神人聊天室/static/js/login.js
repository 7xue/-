/**
 * 神人聊天室 - 登录页面脚本
 */

$(document).ready(function() {
    // 加载服务器列表
    loadServers();
    
    // 表单提交
    $('#loginForm').on('submit', handleLogin);
});

/**
 * 加载服务器列表
 */
function loadServers() {
    $.ajax({
        url: '/api/config',
        method: 'GET',
        success: function(data) {
            const serverSelect = $('#server');
            serverSelect.empty();
            serverSelect.append('<option value="">请选择服务器</option>');
            
            data.servers.forEach(function(server) {
                serverSelect.append(
                    `<option value="${server.url}">${server.name}</option>`
                );
            });
            
            // 默认选择第一个服务器
            if (data.servers.length > 0) {
                serverSelect.val(data.servers[0].url);
            }
        },
        error: function() {
            showToast('加载服务器列表失败');
        }
    });
}

/**
 * 处理登录
 */
function handleLogin(e) {
    e.preventDefault();
    
    const nickname = $('#nickname').val().trim();
    const password = $('#password').val();
    const server = $('#server').val();
    const agreement = $('#agreement').is(':checked');
    
    // 验证协议
    if (!agreement) {
        showToast('请先同意服务协议和隐私保护指引');
        return;
    }
    
    // 验证昵称
    if (!nickname) {
        showToast('请输入昵称');
        return;
    }
    
    if (nickname.length < 2 || nickname.length > 20) {
        showToast('昵称长度应为2-20个字符');
        return;
    }
    
    // 验证密码
    if (!password) {
        showToast('请输入密码');
        return;
    }
    
    // 验证服务器
    if (!server) {
        showToast('请选择服务器');
        return;
    }
    
    // 发送验证请求
    $.ajax({
        url: '/api/validate',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            nickname: nickname,
            password: password,
            server: server
        }),
        success: function(data) {
            if (data.success) {
                // 保存用户信息到sessionStorage
                sessionStorage.setItem('chatUser', JSON.stringify({
                    nickname: nickname,
                    server: server,
                    loginTime: new Date().toISOString()
                }));
                
                // 跳转到聊天室
                window.location.href = '/chat';
            } else {
                showToast(data.message);
            }
        },
        error: function() {
            showToast('登录失败，请稍后重试');
        }
    });
}

/**
 * 显示提示消息
 */
function showToast(message) {
    const toast = $('#errorToast');
    toast.text(message);
    toast.addClass('show');
    
    setTimeout(function() {
        toast.removeClass('show');
    }, 3000);
}
