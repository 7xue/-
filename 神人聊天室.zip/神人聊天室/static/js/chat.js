/**
 * 神人聊天室 - 聊天室页面脚本
 */

// 全局变量
let socket = null;
let currentUser = null;

// Emoji列表
const emojis = [
    '😀', '😁', '😂', '🤣', '😃', '😄', '😅', '😆',
    '😉', '😊', '😋', '😎', '😍', '😘', '🥰', '😗',
    '😙', '😚', '🙂', '🤗', '🤩', '🤔', '🤨', '😐',
    '😑', '😶', '🙄', '😏', '😣', '😥', '😮', '🤐',
    '😯', '😪', '😫', '🥱', '😴', '😌', '😛', '😜',
    '😝', '🤤', '😒', '😓', '😔', '😕', '🙃', '🤑',
    '😲', '🙁', '😖', '😞', '😟', '😤', '😢', '😭',
    '😦', '😧', '😨', '😩', '🤯', '😬', '😰', '😱',
    '🥵', '🥶', '😳', '🤪', '😵', '🥴', '😠', '😡',
    '🤬', '😷', '🤒', '🤕', '🤢', '🤮', '🤧', '😇',
    '🥳', '🥺', '🤠', '🤡', '🤥', '🤫', '🤭', '🧐',
    '🤓', '😈', '👿', '👋', '🤚', '🖐️', '✋', '🖖',
    '👌', '🤌', '🤏', '✌️', '🤞', '🤟', '🤘', '🤙',
    '👈', '👉', '👆', '👇', '☝️', '👍', '👎', '✊',
    '👊', '🤛', '🤜', '👏', '🙌', '👐', '🤲', '🤝',
    '🙏', '💪', '🦾', '❤️', '🧡', '💛', '💚', '💙',
    '💜', '🖤', '🤍', '🤎', '💔', '❣️', '💕', '💖',
    '💗', '💘', '💝', '💞', '💟', '🔥', '✨', '🎉'
];

$(document).ready(function() {
    // 检查登录状态
    checkLoginStatus();
    
    // 初始化Emoji选择器
    initEmojiPicker();
    
    // 绑定事件
    bindEvents();
    
    // 连接WebSocket
    connectSocket();
});

/**
 * 检查登录状态
 */
function checkLoginStatus() {
    const userStr = sessionStorage.getItem('chatUser');
    if (!userStr) {
        window.location.href = '/';
        return;
    }
    
    currentUser = JSON.parse(userStr);
}

/**
 * 初始化Emoji选择器
 */
function initEmojiPicker() {
    const grid = $('#emojiGrid');
    emojis.forEach(function(emoji) {
        grid.append(`<span class="emoji-item" data-emoji="${emoji}">${emoji}</span>`);
    });
}

/**
 * 绑定事件
 */
function bindEvents() {
    // 发送消息
    $('#sendBtn').on('click', sendMessage);
    
    // 回车发送消息
    $('#messageInput').on('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // Emoji选择器
    $('#emojiBtn').on('click', function(e) {
        e.stopPropagation();
        $('#atPicker').removeClass('show');
        $('#emojiPicker').toggleClass('show');
    });
    
    // 选择Emoji
    $(document).on('click', '.emoji-item', function() {
        const emoji = $(this).data('emoji');
        const input = $('#messageInput');
        input.val(input.val() + emoji);
        input.focus();
        $('#emojiPicker').removeClass('show');
    });
    
    // @选择器
    $('#atBtn').on('click', function(e) {
        e.stopPropagation();
        $('#emojiPicker').removeClass('show');
        $('#atPicker').toggleClass('show');
    });
    
    // 选择@功能
    $(document).on('click', '.at-item', function(e) {
        e.stopPropagation();
        const at = $(this).data('at');
        const input = $('#messageInput');
        input.val(input.val() + at + ' ');
        input.focus();
        $('#atPicker').removeClass('show');
    });
    
    // 点击其他区域关闭选择器
    $(document).on('click', function(e) {
        if (!$(e.target).closest('#emojiPicker, #emojiBtn').length) {
            $('#emojiPicker').removeClass('show');
        }
        if (!$(e.target).closest('#atPicker, #atBtn').length) {
            $('#atPicker').removeClass('show');
        }
    });
    
    // 退出按钮
    $('#logoutBtn').on('click', function() {
        showConfirmModal('确定要退出聊天室吗？', function() {
            logout();
        });
    });
    
    // 历史记录按钮
    $('#historyBtn, #historyMsgBtn').on('click', function() {
        showToast('历史记录功能正在建设中，敬请期待！');
    });
    
    // 模态框按钮
    $('#modalCancel').on('click', hideConfirmModal);
    $('#modalConfirm').on('click', function() {
        if (window.confirmCallback) {
            window.confirmCallback();
        }
        hideConfirmModal();
    });
}

/**
 * 连接WebSocket
 */
function connectSocket() {
    // 获取用户选择的服务器URL
    let serverUrl = currentUser.server || '';
    
    // 将 ws:// 或 wss:// 转换为 http:// 或 https://
    if (serverUrl.startsWith('ws://')) {
        serverUrl = serverUrl.replace('ws://', 'http://');
    } else if (serverUrl.startsWith('wss://')) {
        serverUrl = serverUrl.replace('wss://', 'https://');
    }
    
    console.log('连接服务器:', serverUrl);
    
    // 使用Socket.IO连接
    // 公网使用polling模式更稳定，本地优先websocket
    const isPublic = serverUrl && serverUrl.includes('https://');
    socket = io(serverUrl || undefined, {
        transports: isPublic ? ['polling', 'websocket'] : ['websocket', 'polling'],
        reconnectionAttempts: 5,
        reconnectionDelay: 1000,
        timeout: 20000,
        forceNew: true
    });
    
    // 连接成功
    socket.on('connect', function() {
        console.log('WebSocket连接成功');
        showToast('连接成功！');
        // 加入聊天室
        socket.emit('join', {
            nickname: currentUser.nickname
        });
    });
    
    // 连接错误
    socket.on('connect_error', function(error) {
        console.error('连接错误:', error);
        showToast('连接服务器失败: ' + error.message);
    });
    
    // 连接断开
    socket.on('disconnect', function(reason) {
        console.log('WebSocket连接断开:', reason);
        showToast('连接已断开: ' + reason);
    });
    
    // 用户加入
    socket.on('user_joined', function(data) {
        updateOnlineUsers(data.users, data.online_count);
    });
    
    // 用户离开
    socket.on('user_left', function(data) {
        updateOnlineUsers(data.users, data.online_count);
    });
    
    // 系统消息
    socket.on('system_message', function(data) {
        appendSystemMessage(data.content, data.time);
    });
    
    // 新消息
    socket.on('new_message', function(data) {
        appendMessage(data);
    });
    
    // @功能响应
    socket.on('at_response', function(data) {
        appendAtResponse(data);
    });
    
    // AI流式响应开始
    socket.on('ai_stream_start', function(data) {
        handleAIStreamStart(data);
    });
    
    // 电影播放器
    socket.on('movie_player', function(data) {
        appendMoviePlayer(data);
    });
    
    // 音乐加载
    socket.on('music_loading', function(data) {
        handleMusicLoading(data);
    });
    
    // 天气加载
    socket.on('weather_loading', function(data) {
        handleWeatherLoading(data);
    });
    
    // 新闻加载
    socket.on('news_loading', function(data) {
        handleNewsLoading(data);
    });
    
    // 在线用户列表
    socket.on('online_users', function(data) {
        updateOnlineUsers(data.users, data.online_count);
    });
}

/**
 * 发送消息
 */
function sendMessage() {
    const input = $('#messageInput');
    const content = input.val().trim();
    
    if (!content) {
        return;
    }
    
    socket.emit('send_message', {
        content: content
    });
    
    input.val('');
    input.focus();
}

/**
 * 更新在线用户列表
 */
function updateOnlineUsers(users, count) {
    $('#onlineCount').text(count);
    $('#memberCount').text(count);
    
    const userList = $('#userList');
    userList.empty();
    
    users.forEach(function(nickname) {
        const initial = nickname.charAt(0).toUpperCase();
        const colors = [
            'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
            'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
            'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
            'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
            'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)'
        ];
        const colorIndex = nickname.charCodeAt(0) % colors.length;
        
        userList.append(`
            <li class="user-list-item">
                <div class="user-list-avatar" style="background: ${colors[colorIndex]}">${initial}</div>
                <span class="user-list-name">${escapeHtml(nickname)}</span>
                <span class="user-status"></span>
            </li>
        `);
    });
}

/**
 * 添加系统消息
 */
function appendSystemMessage(content, time) {
    const wrapper = $('#messagesWrapper');
    
    // 移除欢迎消息
    wrapper.find('.welcome-message').remove();
    
    wrapper.append(`
        <div class="system-message">
            <span class="system-message-content">${escapeHtml(content)}</span>
        </div>
    `);
    
    scrollToBottom();
    updateLastMessage(content, time);
}

/**
 * 添加消息
 */
function appendMessage(data) {
    const wrapper = $('#messagesWrapper');
    
    // 移除欢迎消息
    wrapper.find('.welcome-message').remove();
    
    const isSelf = data.nickname === currentUser.nickname;
    const initial = data.nickname.charAt(0).toUpperCase();
    const colors = [
        'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
        'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
        'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
        'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
        'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)'
    ];
    const colorIndex = data.nickname.charCodeAt(0) % colors.length;
    
    // 处理消息内容中的@
    let content = escapeHtml(data.content);
    const atKeywords = ['@小理', '@音乐一下', '@电影', '@天气', '@新闻', '@小视频'];
    atKeywords.forEach(function(keyword) {
        content = content.replace(new RegExp(keyword, 'g'), `<span style="color: #1890ff">${keyword}</span>`);
    });
    
    wrapper.append(`
        <div class="message-item ${isSelf ? 'self' : ''}">
            <div class="message-avatar" style="background: ${colors[colorIndex]}">${initial}</div>
            <div class="message-content">
                <div class="message-header">
                    <span class="message-nickname">${escapeHtml(data.nickname)}</span>
                    <span class="message-time">${data.time}</span>
                </div>
                <div class="message-bubble">${content}</div>
            </div>
        </div>
    `);
    
    scrollToBottom();
    updateLastMessage(data.content, data.time);
}

/**
 * 添加@功能响应
 */
function appendAtResponse(data) {
    const wrapper = $('#messagesWrapper');
    
    wrapper.append(`
        <div class="message-item">
            <div class="message-avatar" style="background: linear-gradient(135deg, #1890ff 0%, #096dd9 100%)">🤖</div>
            <div class="message-content">
                <div class="message-header">
                    <span class="message-nickname">系统助手</span>
                    <span class="message-level">BOT</span>
                    <span class="message-time">${data.time}</span>
                </div>
                <div class="message-bubble">${escapeHtml(data.content)}</div>
            </div>
        </div>
    `);
    
    scrollToBottom();
}

/**
 * 添加电影播放器
 */
function appendMoviePlayer(data) {
    const wrapper = $('#messagesWrapper');
    
    // 创建消息容器
    const messageItem = $('<div class="message-item"></div>');
    messageItem.html(`
        <div class="message-avatar" style="background: linear-gradient(135deg, #722ed1 0%, #531dab 100%)">🎬</div>
        <div class="message-content">
            <div class="message-header">
                <span class="message-nickname">电影助手</span>
                <span class="message-level" style="background: linear-gradient(135deg, #722ed1 0%, #531dab 100%)">MOVIE</span>
                <span class="message-time">${escapeHtml(data.time)}</span>
            </div>
            <div class="message-bubble movie-bubble">
                <div class="movie-info">
                    <span class="movie-label">🎬 ${escapeHtml(data.nickname)} 分享了视频</span>
                </div>
                <div class="movie-player"></div>
            </div>
        </div>
    `);
    
    // 安全地创建iframe
    const iframe = document.createElement('iframe');
    iframe.src = data.iframe_src;
    iframe.width = '400';
    iframe.height = '400';
    iframe.frameBorder = '0';
    iframe.allowFullscreen = true;
    iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
    
    messageItem.find('.movie-player').append(iframe);
    wrapper.append(messageItem);
    
    scrollToBottom();
    updateLastMessage('🎬 分享了视频', data.time);
}

/**
 * 处理音乐加载 - 支持随机和搜索
 */
function handleMusicLoading(data) {
    const wrapper = $('#messagesWrapper');
    const musicId = 'music_' + Date.now();
    const keyword = data.keyword || '';
    
    // 显示加载中
    const loadingText = keyword ? 
        `正在为 ${escapeHtml(data.nickname)} 搜索「${escapeHtml(keyword)}」...` : 
        `正在为 ${escapeHtml(data.nickname)} 随机点歌...`;
    
    wrapper.append(`
        <div class="message-item" id="${musicId}">
            <div class="message-avatar" style="background: linear-gradient(135deg, #eb2f96 0%, #c41d7f 100%)">🎵</div>
            <div class="message-content">
                <div class="message-header">
                    <span class="message-nickname">音乐助手</span>
                    <span class="message-level" style="background: linear-gradient(135deg, #eb2f96 0%, #c41d7f 100%)">MUSIC</span>
                    <span class="message-time">${escapeHtml(data.time)}</span>
                </div>
                <div class="message-bubble music-bubble">
                    <div class="music-loading">
                        <div class="loading-spinner"></div>
                        <span>${loadingText}</span>
                    </div>
                </div>
            </div>
        </div>
    `);
    
    scrollToBottom();
    
    // 根据是否有关键词决定搜索还是随机
    if (keyword) {
        // 搜索音乐
        fetch(`/api/music/search?keyword=${encodeURIComponent(keyword)}&limit=5`)
            .then(response => response.json())
            .then(result => {
                if (result.success && result.data && result.data.songs && result.data.songs.length > 0) {
                    appendMusicSearchResults(musicId, result.data.songs, data, keyword);
                } else {
                    $(`#${musicId} .music-bubble`).html(`
                        <div class="music-error">
                            <span>😢 未找到「${escapeHtml(keyword)}」相关的音乐</span>
                            <div class="music-error-tip">试试输入歌名或歌手名吧~</div>
                        </div>
                    `);
                }
            })
            .catch(error => {
                console.error('搜索音乐失败:', error);
                $(`#${musicId} .music-bubble`).html(`
                    <div class="music-error">
                        <span>😢 搜索失败，请稍后再试</span>
                    </div>
                `);
            });
    } else {
        // 随机音乐
        fetch('/api/music/random')
            .then(response => response.json())
            .then(result => {
                if (result.success && result.data) {
                    const music = result.data;
                    appendMusicCard(musicId, music, data);
                } else {
                    $(`#${musicId} .music-bubble`).html(`
                        <div class="music-error">
                            <span>😢 获取音乐失败，请稍后再试</span>
                        </div>
                    `);
                }
            })
            .catch(error => {
                console.error('获取音乐失败:', error);
                $(`#${musicId} .music-bubble`).html(`
                    <div class="music-error">
                        <span>😢 网络错误，请稍后再试</span>
                    </div>
                `);
            });
    }
}

/**
 * 显示音乐搜索结果列表
 */
function appendMusicSearchResults(musicId, songs, data, keyword) {
    let songsHtml = songs.map((song, index) => `
        <div class="music-search-item" onclick="playSearchedMusic('${musicId}', ${index})" data-song='${JSON.stringify(song).replace(/'/g, "&#39;")}'>
            <div class="music-search-index">${index + 1}</div>
            <img class="music-search-cover" src="${song.image || ''}" alt="" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 40 40%22><rect width=%2240%22 height=%2240%22 fill=%22%23f0f0f0%22/><text x=%2220%22 y=%2224%22 text-anchor=%22middle%22 fill=%22%23999%22 font-size=%2214%22>🎵</text></svg>'">
            <div class="music-search-info">
                <div class="music-search-name">${escapeHtml(song.name)}</div>
                <div class="music-search-singer">${escapeHtml(song.singer)}</div>
            </div>
            <div class="music-search-play">▶</div>
        </div>
    `).join('');
    
    const resultHtml = `
        <div class="music-search-header">
            <span class="music-search-title">🔍 搜索「${escapeHtml(keyword)}」的结果</span>
            <span class="music-search-count">共 ${songs.length} 首</span>
        </div>
        <div class="music-search-list" id="list_${musicId}">
            ${songsHtml}
        </div>
        <div class="music-player-container" id="player_${musicId}" style="display: none;"></div>
    `;
    
    $(`#${musicId} .music-bubble`).html(resultHtml);
    scrollToBottom();
    updateLastMessage(`🎵 搜索: ${keyword}`, data.time);
}

/**
 * 播放搜索结果中的音乐
 */
function playSearchedMusic(musicId, index) {
    const listContainer = $(`#list_${musicId}`);
    const playerContainer = $(`#player_${musicId}`);
    const item = listContainer.find('.music-search-item').eq(index);
    const songData = JSON.parse(item.attr('data-song').replace(/&#39;/g, "'"));
    
    // 高亮选中项
    listContainer.find('.music-search-item').removeClass('active');
    item.addClass('active');
    
    // 显示播放器
    const playerHtml = `
        <div class="music-card">
            <div class="music-cover">
                <img src="${songData.image || ''}" alt="封面" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect width=%22100%22 height=%22100%22 fill=%22%23f0f0f0%22/><text x=%2250%22 y=%2255%22 text-anchor=%22middle%22 fill=%22%23999%22 font-size=%2230%22>🎵</text></svg>'">
                <div class="music-play-btn" onclick="toggleMusicPlay('${musicId}')">
                    <svg class="play-icon" viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M8 5v14l11-7z"/></svg>
                    <svg class="pause-icon" viewBox="0 0 24 24" width="24" height="24" style="display:none"><path fill="currentColor" d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
                </div>
            </div>
            <div class="music-info">
                <div class="music-name">${escapeHtml(songData.name || '未知歌曲')}</div>
                <div class="music-singer">${escapeHtml(songData.singer || '未知歌手')}</div>
                ${songData.album ? `<div class="music-album">💿 ${escapeHtml(songData.album)}</div>` : ''}
            </div>
            <audio id="audio_${musicId}" src="${songData.url || ''}" preload="metadata"></audio>
        </div>
        <div class="music-progress">
            <div class="progress-bar" onclick="seekMusic(event, '${musicId}')">
                <div class="progress-current" id="progress_${musicId}"></div>
            </div>
            <div class="progress-time">
                <span id="current_${musicId}">0:00</span>
                <span id="duration_${musicId}">0:00</span>
            </div>
        </div>
    `;
    
    playerContainer.html(playerHtml).show();
    
    // 绑定音频事件
    const audio = document.getElementById('audio_' + musicId);
    if (audio) {
        // 移除旧的事件监听器
        audio.onloadedmetadata = null;
        audio.ontimeupdate = null;
        audio.onended = null;
        
        audio.addEventListener('timeupdate', function() {
            const progress = (audio.currentTime / audio.duration) * 100;
            $(`#progress_${musicId}`).css('width', progress + '%');
            $(`#current_${musicId}`).text(formatTime(audio.currentTime));
        });
        
        audio.addEventListener('loadedmetadata', function() {
            $(`#duration_${musicId}`).text(formatTime(audio.duration));
        });
        
        audio.addEventListener('ended', function() {
            $(`#${musicId} .play-icon`).show();
            $(`#${musicId} .pause-icon`).hide();
            $(`#${musicId} .music-cover`).removeClass('playing');
        });
        
        // 自动播放
        audio.play().catch(e => console.log('自动播放失败:', e));
        $(`#${musicId} .play-icon`).hide();
        $(`#${musicId} .pause-icon`).show();
        $(`#${musicId} .music-cover`).addClass('playing');
    }
    
    scrollToBottom();
}

/**
 * 音乐进度条点击跳转
 */
function seekMusic(event, musicId) {
    const audio = document.getElementById('audio_' + musicId);
    if (!audio || !audio.duration) return;
    
    const progressBar = event.currentTarget;
    const rect = progressBar.getBoundingClientRect();
    const percent = (event.clientX - rect.left) / rect.width;
    audio.currentTime = percent * audio.duration;
}

/**
 * 添加音乐卡片
 */
function appendMusicCard(musicId, music, data) {
    const cardHtml = `
        <div class="music-card">
            <div class="music-cover">
                <img src="${music.image || ''}" alt="封面" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect width=%22100%22 height=%22100%22 fill=%22%23f0f0f0%22/><text x=%2250%22 y=%2255%22 text-anchor=%22middle%22 fill=%22%23999%22 font-size=%2230%22>🎵</text></svg>'">
                <div class="music-play-btn" onclick="toggleMusicPlay('${musicId}')">
                    <svg class="play-icon" viewBox="0 0 24 24" width="24" height="24"><path fill="currentColor" d="M8 5v14l11-7z"/></svg>
                    <svg class="pause-icon" viewBox="0 0 24 24" width="24" height="24" style="display:none"><path fill="currentColor" d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
                </div>
            </div>
            <div class="music-info">
                <div class="music-name">${escapeHtml(music.name || '未知歌曲')}</div>
                <div class="music-singer">${escapeHtml(music.singer || '未知歌手')}</div>
                <div class="music-sharer">🎧 ${escapeHtml(data.nickname)} 点播</div>
            </div>
            <audio id="audio_${musicId}" src="${music.url || ''}" preload="metadata"></audio>
        </div>
        <div class="music-progress">
            <div class="progress-bar">
                <div class="progress-current" id="progress_${musicId}"></div>
            </div>
            <div class="progress-time">
                <span id="current_${musicId}">0:00</span>
                <span id="duration_${musicId}">0:00</span>
            </div>
        </div>
    `;
    
    $(`#${musicId} .music-bubble`).html(cardHtml);
    
    // 绑定音频事件
    const audio = document.getElementById('audio_' + musicId);
    if (audio) {
        audio.addEventListener('timeupdate', function() {
            const progress = (audio.currentTime / audio.duration) * 100;
            $(`#progress_${musicId}`).css('width', progress + '%');
            $(`#current_${musicId}`).text(formatTime(audio.currentTime));
        });
        
        audio.addEventListener('loadedmetadata', function() {
            $(`#duration_${musicId}`).text(formatTime(audio.duration));
        });
        
        audio.addEventListener('ended', function() {
            $(`#${musicId} .play-icon`).show();
            $(`#${musicId} .pause-icon`).hide();
            $(`#${musicId} .music-cover`).removeClass('playing');
        });
    }
    
    scrollToBottom();
    updateLastMessage('🎵 ' + (music.name || '音乐'), data.time);
}

/**
 * 切换音乐播放
 */
function toggleMusicPlay(musicId) {
    const audio = document.getElementById('audio_' + musicId);
    if (!audio) return;
    
    // 暂停其他正在播放的音乐
    document.querySelectorAll('audio').forEach(a => {
        if (a.id !== 'audio_' + musicId && !a.paused) {
            a.pause();
            const otherId = a.id.replace('audio_', '');
            $(`#${otherId} .play-icon`).show();
            $(`#${otherId} .pause-icon`).hide();
            $(`#${otherId} .music-cover`).removeClass('playing');
        }
    });
    
    if (audio.paused) {
        audio.play();
        $(`#${musicId} .play-icon`).hide();
        $(`#${musicId} .pause-icon`).show();
        $(`#${musicId} .music-cover`).addClass('playing');
    } else {
        audio.pause();
        $(`#${musicId} .play-icon`).show();
        $(`#${musicId} .pause-icon`).hide();
        $(`#${musicId} .music-cover`).removeClass('playing');
    }
}

/**
 * 格式化时间
 */
function formatTime(seconds) {
    if (isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return mins + ':' + (secs < 10 ? '0' : '') + secs;
}

/**
 * 处理AI流式响应开始
 */
function handleAIStreamStart(data) {
    const wrapper = $('#messagesWrapper');
    const messageId = data.message_id;
    
    // 创建AI消息容器
    wrapper.append(`
        <div class="message-item" id="${messageId}">
            <div class="message-avatar" style="background: linear-gradient(135deg, #52c41a 0%, #389e0d 100%)">🤖</div>
            <div class="message-content">
                <div class="message-header">
                    <span class="message-nickname">小理</span>
                    <span class="message-level" style="background: linear-gradient(135deg, #52c41a 0%, #389e0d 100%)">AI</span>
                    <span class="message-time">${data.time}</span>
                </div>
                <div class="message-bubble ai-bubble">
                    <span class="ai-content"></span>
                    <span class="typing-cursor">|</span>
                </div>
            </div>
        </div>
    `);
    
    scrollToBottom();
    
    // 开始SSE流式请求
    startAIStream(data.question, messageId);
}

/**
 * 开始AI流式请求
 */
function startAIStream(question, messageId) {
    const userId = currentUser.nickname;
    
    fetch('/api/ai/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            question: question,
            user_id: userId
        })
    }).then(response => {
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        
        function read() {
            reader.read().then(({done, value}) => {
                if (done) {
                    // 移除光标
                    $(`#${messageId} .typing-cursor`).remove();
                    return;
                }
                
                buffer += decoder.decode(value, {stream: true});
                
                // 处理SSE数据
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                
                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.slice(6));
                            
                            if (data.error) {
                                // 显示错误
                                $(`#${messageId} .ai-content`).text('抱歉，' + data.error);
                                $(`#${messageId} .typing-cursor`).remove();
                                return;
                            }
                            
                            if (data.content) {
                                // 追加内容
                                const contentEl = $(`#${messageId} .ai-content`);
                                contentEl.text(contentEl.text() + data.content);
                                scrollToBottom();
                            }
                            
                            if (data.done) {
                                // 完成，移除光标
                                $(`#${messageId} .typing-cursor`).remove();
                                updateLastMessage('小理: ' + data.full_content.substring(0, 15) + '...', new Date().toLocaleTimeString('zh-CN', {hour: '2-digit', minute: '2-digit'}));
                            }
                        } catch (e) {
                            console.error('解析SSE数据错误:', e);
                        }
                    }
                }
                
                read();
            }).catch(error => {
                console.error('读取流错误:', error);
                $(`#${messageId} .ai-content`).text('抱歉，连接出现问题，请稍后重试');
                $(`#${messageId} .typing-cursor`).remove();
            });
        }
        
        read();
    }).catch(error => {
        console.error('请求错误:', error);
        $(`#${messageId} .ai-content`).text('抱歉，请求失败，请稍后重试');
        $(`#${messageId} .typing-cursor`).remove();
    });
}

/**
 * 更新最后一条消息
 */
function updateLastMessage(content, time) {
    $('#lastMessage').text(content.substring(0, 20) + (content.length > 20 ? '...' : ''));
    $('#lastTime').text(time);
}

/**
 * 滚动到底部
 */
function scrollToBottom() {
    const container = $('#messagesContainer');
    container.scrollTop(container[0].scrollHeight);
}

/**
 * 显示确认对话框
 */
function showConfirmModal(message, callback) {
    $('#modalBody').text(message);
    $('#confirmModal').addClass('show');
    window.confirmCallback = callback;
}

/**
 * 隐藏确认对话框
 */
function hideConfirmModal() {
    $('#confirmModal').removeClass('show');
    window.confirmCallback = null;
}

/**
 * 退出登录
 */
function logout() {
    if (socket) {
        socket.emit('leave');
        socket.disconnect();
    }
    sessionStorage.removeItem('chatUser');
    window.location.href = '/';
}

/**
 * 显示提示消息
 */
function showToast(message) {
    const toast = $('#toast');
    toast.text(message);
    toast.addClass('show');
    
    setTimeout(function() {
        toast.removeClass('show');
    }, 3000);
}

/**
 * HTML转义
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * 处理天气加载
 */
function handleWeatherLoading(data) {
    const wrapper = $('#messagesWrapper');
    const weatherId = 'weather_' + Date.now();
    
    // 先显示加载中
    wrapper.append(`
        <div class="message-item" id="${weatherId}">
            <div class="message-avatar" style="background: linear-gradient(135deg, #36cfc9 0%, #13c2c2 100%)">🌤️</div>
            <div class="message-content">
                <div class="message-header">
                    <span class="message-nickname">天气助手</span>
                    <span class="message-level" style="background: linear-gradient(135deg, #36cfc9 0%, #13c2c2 100%)">WEATHER</span>
                    <span class="message-time">${escapeHtml(data.time)}</span>
                </div>
                <div class="message-bubble weather-bubble">
                    <div class="weather-loading">
                        <div class="loading-spinner"></div>
                        <span>正在查询 ${escapeHtml(data.city)} 的天气...</span>
                    </div>
                </div>
            </div>
        </div>
    `);
    
    scrollToBottom();
    
    // 请求天气API
    fetch('/api/weather?city=' + encodeURIComponent(data.city))
        .then(response => response.json())
        .then(result => {
            if (result.success && result.data) {
                appendWeatherCard(weatherId, result.data, data);
            } else {
                $(`#${weatherId} .weather-bubble`).html(`
                    <div class="weather-error">
                        <span>😢 ${result.message || '获取天气失败，请检查城市名称'}</span>
                    </div>
                `);
            }
        })
        .catch(error => {
            console.error('获取天气失败:', error);
            $(`#${weatherId} .weather-bubble`).html(`
                <div class="weather-error">
                    <span>😢 网络错误，请稍后再试</span>
                </div>
            `);
        });
}

/**
 * 添加天气卡片
 */
function appendWeatherCard(weatherId, weather, data) {
    // 获取天气图标
    const weatherIcon = getWeatherIcon(weather.weather || weather.wea || '');
    
    // 构建天气卡片HTML
    let html = `
        <div class="weather-card">
            <div class="weather-header">
                <div class="weather-city">
                    <span class="city-icon">📍</span>
                    <span class="city-name">${escapeHtml(weather.city || data.city)}</span>
                </div>
                <div class="weather-date">${escapeHtml(weather.date || new Date().toLocaleDateString())}</div>
            </div>
            <div class="weather-main">
                <div class="weather-icon">${weatherIcon}</div>
                <div class="weather-temp">
                    <span class="temp-value">${escapeHtml(weather.tem || weather.temperature || '--')}</span>
                    <span class="temp-unit">°C</span>
                </div>
                <div class="weather-desc">${escapeHtml(weather.weather || weather.wea || '未知')}</div>
            </div>
            <div class="weather-details">
                <div class="weather-detail-item">
                    <span class="detail-icon">🌡️</span>
                    <span class="detail-label">温度范围</span>
                    <span class="detail-value">${escapeHtml(weather.tem_night || weather.tem2 || '--')}°C ~ ${escapeHtml(weather.tem_day || weather.tem1 || '--')}°C</span>
                </div>
                <div class="weather-detail-item">
                    <span class="detail-icon">💧</span>
                    <span class="detail-label">湿度</span>
                    <span class="detail-value">${escapeHtml(weather.humidity || '--')}%</span>
                </div>
                <div class="weather-detail-item">
                    <span class="detail-icon">🌬️</span>
                    <span class="detail-label">风向风力</span>
                    <span class="detail-value">${escapeHtml(weather.win || '--')} ${escapeHtml(weather.win_speed || weather.win_meter || '--')}</span>
                </div>
                <div class="weather-detail-item">
                    <span class="detail-icon">👁️</span>
                    <span class="detail-label">能见度</span>
                    <span class="detail-value">${escapeHtml(weather.visibility || '--')}km</span>
                </div>
                <div class="weather-detail-item">
                    <span class="detail-icon">🌅</span>
                    <span class="detail-label">日出日落</span>
                    <span class="detail-value">${escapeHtml(weather.sunrise || '--')} / ${escapeHtml(weather.sunset || '--')}</span>
                </div>
                <div class="weather-detail-item">
                    <span class="detail-icon">📊</span>
                    <span class="detail-label">空气质量</span>
                    <span class="detail-value aqi-${getAqiLevel(weather.aqi)}">${escapeHtml(weather.air || weather.aqi || '--')} ${escapeHtml(weather.air_level || '')}</span>
                </div>
            </div>
            ${weather.air_tips ? `<div class="weather-tips">💡 ${escapeHtml(weather.air_tips)}</div>` : ''}
        </div>
    `;
    
    $(`#${weatherId} .weather-bubble`).html(html);
    scrollToBottom();
}

/**
 * 获取天气图标
 */
function getWeatherIcon(weather) {
    const iconMap = {
        '晴': '☀️',
        '多云': '⛅',
        '阴': '☁️',
        '小雨': '🌧️',
        '中雨': '🌧️',
        '大雨': '🌧️',
        '暴雨': '⛈️',
        '雷阵雨': '⛈️',
        '阵雨': '🌦️',
        '小雪': '🌨️',
        '中雪': '🌨️',
        '大雪': '❄️',
        '暴雪': '❄️',
        '雨夹雪': '🌨️',
        '雾': '🌫️',
        '霾': '😷',
        '沙尘暴': '🌪️',
        '浮尘': '🌫️',
        '扬沙': '🌫️'
    };
    
    for (const [key, icon] of Object.entries(iconMap)) {
        if (weather.includes(key)) {
            return icon;
        }
    }
    return '🌤️';
}

/**
 * 获取空气质量等级
 */
function getAqiLevel(aqi) {
    const value = parseInt(aqi);
    if (isNaN(value)) return 'unknown';
    if (value <= 50) return 'good';
    if (value <= 100) return 'moderate';
    if (value <= 150) return 'unhealthy-sensitive';
    if (value <= 200) return 'unhealthy';
    if (value <= 300) return 'very-unhealthy';
    return 'hazardous';
}

/**
 * 处理新闻加载
 */
function handleNewsLoading(data) {
    const wrapper = $('#messagesWrapper');
    const newsId = 'news_' + Date.now();
    
    // 先显示加载中
    wrapper.append(`
        <div class="message-item" id="${newsId}">
            <div class="message-avatar" style="background: linear-gradient(135deg, #ff7a45 0%, #fa541c 100%)">📰</div>
            <div class="message-content">
                <div class="message-header">
                    <span class="message-nickname">新闻助手</span>
                    <span class="message-level" style="background: linear-gradient(135deg, #ff7a45 0%, #fa541c 100%)">NEWS</span>
                    <span class="message-time">${escapeHtml(data.time)}</span>
                </div>
                <div class="message-bubble news-bubble">
                    <div class="news-loading">
                        <div class="loading-spinner"></div>
                        <span>正在获取${data.type ? escapeHtml(data.type) : '热点'}新闻...</span>
                    </div>
                </div>
            </div>
        </div>
    `);
    
    scrollToBottom();
    
    // 请求新闻API
    fetch('/api/news?type=' + encodeURIComponent(data.type || ''))
        .then(response => response.json())
        .then(result => {
            if (result.success && result.data) {
                appendNewsCard(newsId, result.data, data);
            } else {
                $(`#${newsId} .news-bubble`).html(`
                    <div class="news-error">
                        <span>😢 ${result.message || '获取新闻失败'}</span>
                    </div>
                `);
            }
        })
        .catch(error => {
            console.error('获取新闻失败:', error);
            $(`#${newsId} .news-bubble`).html(`
                <div class="news-error">
                    <span>😢 网络错误，请稍后再试</span>
                </div>
            `);
        });
}

/**
 * 添加新闻卡片
 */
function appendNewsCard(newsId, news, data) {
    const newsList = news.list || [];
    
    let newsItemsHtml = newsList.map((item, idx) => `
        <div class="news-item" onclick="window.open('${escapeHtml(item.url)}', '_blank')">
            <div class="news-rank ${idx < 3 ? 'top' : ''}">${item.index}</div>
            <div class="news-title">${escapeHtml(item.title)}</div>
            ${item.hot ? `<div class="news-hot">🔥 ${escapeHtml(item.hot)}</div>` : ''}
        </div>
    `).join('');
    
    let html = `
        <div class="news-card">
            <div class="news-header">
                <div class="news-type">
                    <span class="type-icon">📰</span>
                    <span class="type-name">${escapeHtml(news.title || '热点新闻')}</span>
                </div>
                <div class="news-time">${new Date().toLocaleString()}</div>
            </div>
            <div class="news-list">
                ${newsItemsHtml}
            </div>
            <div class="news-footer">
                <span>点击新闻标题查看详情</span>
            </div>
        </div>
    `;
    
    $(`#${newsId} .news-bubble`).html(html);
    scrollToBottom();
}
