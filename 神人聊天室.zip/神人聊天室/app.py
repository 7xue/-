"""
神人聊天室 - Flask + WebSocket 多人在线聊天室
"""
import json
import os
import requests
from datetime import datetime
from flask import Flask, render_template, request, jsonify, Response
from flask_socketio import SocketIO, emit, join_room, leave_room

app = Flask(__name__)
app.config['SECRET_KEY'] = 'shenren-chatroom-secret-key-2024'
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# AI配置 - SiliconFlow API
AI_CONFIG = {
    'api_key': 'sk-ofymdructhrvdueccxefpmulzdovxedwxhlsvmeomgfgksya',
    'api_url': 'https://api.siliconflow.cn/v1/chat/completions',
    'model': 'Qwen/Qwen2.5-7B-Instruct'
}

# 存储对话历史（简单实现，每个用户保留最近10条）
chat_histories = {}

# 加载配置文件
def load_config():
    config_path = os.path.join(os.path.dirname(__file__), 'config.json')
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)

# 存储在线用户
online_users = {}

# 默认聊天室
DEFAULT_ROOM = 'main_room'

@app.route('/')
def index():
    """登录页面"""
    return render_template('login.html')

@app.route('/chat')
def chat():
    """聊天室页面"""
    return render_template('chat.html')

@app.route('/api/config')
def get_config():
    """获取配置信息"""
    config = load_config()
    return jsonify({
        'servers': config['servers'],
        'app_name': config['app']['name']
    })

@app.route('/api/validate', methods=['POST'])
def validate_login():
    """验证登录信息"""
    data = request.get_json()
    nickname = data.get('nickname', '').strip()
    password = data.get('password', '')
    server = data.get('server', '')
    
    config = load_config()
    
    # 验证昵称
    if not nickname:
        return jsonify({'success': False, 'message': '请输入昵称'})
    if len(nickname) < 2 or len(nickname) > 20:
        return jsonify({'success': False, 'message': '昵称长度应为2-20个字符'})
    
    # 验证密码
    if password != config['app']['password']:
        return jsonify({'success': False, 'message': '密码错误'})
    
    # 验证服务器
    if not server:
        return jsonify({'success': False, 'message': '请选择服务器'})
    
    # 检查昵称是否已被使用
    if nickname in [user['nickname'] for user in online_users.values()]:
        return jsonify({'success': False, 'message': '该昵称已被使用'})
    
    return jsonify({'success': True, 'message': '验证成功'})

# WebSocket 事件处理
@socketio.on('connect')
def handle_connect():
    """处理连接"""
    print(f'客户端连接: {request.sid}')

@socketio.on('disconnect')
def handle_disconnect():
    """处理断开连接"""
    sid = request.sid
    if sid in online_users:
        user = online_users[sid]
        del online_users[sid]
        # 通知其他用户
        emit('user_left', {
            'nickname': user['nickname'],
            'time': datetime.now().strftime('%H:%M'),
            'online_count': len(online_users),
            'users': list(set([u['nickname'] for u in online_users.values()]))
        }, room=DEFAULT_ROOM)
    print(f'客户端断开: {sid}')

@socketio.on('join')
def handle_join(data):
    """用户加入聊天室"""
    nickname = data.get('nickname', '')
    sid = request.sid
    
    # 存储用户信息
    online_users[sid] = {
        'nickname': nickname,
        'join_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    # 加入房间
    join_room(DEFAULT_ROOM)
    
    # 通知所有用户
    emit('user_joined', {
        'nickname': nickname,
        'time': datetime.now().strftime('%H:%M'),
        'online_count': len(online_users),
        'users': list(set([u['nickname'] for u in online_users.values()]))
    }, room=DEFAULT_ROOM)
    
    # 发送系统消息
    emit('system_message', {
        'content': f'欢迎 {nickname} 加入聊天室！',
        'time': datetime.now().strftime('%H:%M')
    }, room=DEFAULT_ROOM)

@socketio.on('leave')
def handle_leave():
    """用户离开聊天室"""
    sid = request.sid
    if sid in online_users:
        user = online_users[sid]
        del online_users[sid]
        leave_room(DEFAULT_ROOM)
        
        emit('user_left', {
            'nickname': user['nickname'],
            'time': datetime.now().strftime('%H:%M'),
            'online_count': len(online_users),
            'users': list(set([u['nickname'] for u in online_users.values()]))
        }, room=DEFAULT_ROOM)

@socketio.on('send_message')
def handle_message(data):
    """处理发送消息"""
    sid = request.sid
    if sid not in online_users:
        return
    
    user = online_users[sid]
    content = data.get('content', '').strip()
    
    if not content:
        return
    
    # 检查是否有@功能
    at_targets = []
    at_keywords = ['@小理', '@音乐一下', '@电影', '@天气', '@新闻', '@小视频']
    for keyword in at_keywords:
        if keyword in content:
            at_targets.append(keyword)
    
    message_data = {
        'nickname': user['nickname'],
        'content': content,
        'time': datetime.now().strftime('%H:%M'),
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'sender_id': sid,
        'at_targets': at_targets
    }
    
    # 广播消息给所有用户
    emit('new_message', message_data, room=DEFAULT_ROOM)
    
    # 处理@功能
    for target in at_targets:
        if target == '@小理':
            # @小理 使用AI对话，通知前端开始流式响应
            # 提取用户问题（去掉@小理）
            user_question = content.replace('@小理', '').strip()
            if not user_question:
                user_question = '你好'
            
            emit('ai_stream_start', {
                'target': '@小理',
                'question': user_question,
                'time': datetime.now().strftime('%H:%M'),
                'message_id': f'ai_{int(datetime.now().timestamp() * 1000)}'
            }, room=DEFAULT_ROOM)
        elif target == '@电影':
            # @电影 解析视频URL并插入iframe
            # 提取URL（去掉@电影）
            video_url = content.replace('@电影', '').strip()
            if video_url:
                # 解析服务器地址
                parse_server = 'https://jx.m3u8.tv/jiexi/?url='
                iframe_src = parse_server + video_url
                
                emit('movie_player', {
                    'target': '@电影',
                    'video_url': video_url,
                    'iframe_src': iframe_src,
                    'time': datetime.now().strftime('%H:%M'),
                    'nickname': user['nickname']
                }, room=DEFAULT_ROOM)
            else:
                emit('at_response', {
                    'target': target,
                    'content': '请提供视频URL，格式：@电影 视频链接',
                    'time': datetime.now().strftime('%H:%M')
                }, room=DEFAULT_ROOM)
        elif target == '@音乐一下':
            # @音乐一下 支持随机点歌和搜索
            # 提取搜索关键词（去掉@音乐一下）
            search_keyword = content.replace('@音乐一下', '').strip()
            
            emit('music_loading', {
                'target': '@音乐一下',
                'time': datetime.now().strftime('%H:%M'),
                'nickname': user['nickname'],
                'keyword': search_keyword  # 传递搜索关键词
            }, room=DEFAULT_ROOM)
        elif target == '@天气':
            # @天气 查询天气信息
            # 提取城市名称（去掉@天气）
            city_name = content.replace('@天气', '').strip()
            if not city_name:
                city_name = '北京'  # 默认城市
            
            emit('weather_loading', {
                'target': '@天气',
                'time': datetime.now().strftime('%H:%M'),
                'nickname': user['nickname'],
                'city': city_name
            }, room=DEFAULT_ROOM)
        elif target == '@新闻':
            # @新闻 获取热点新闻
            # 提取新闻类型（去掉@新闻）
            news_type = content.replace('@新闻', '').strip()
            
            emit('news_loading', {
                'target': '@新闻',
                'time': datetime.now().strftime('%H:%M'),
                'nickname': user['nickname'],
                'type': news_type  # 可选：头条、科技、娱乐、体育等
            }, room=DEFAULT_ROOM)
        else:
            # 其他@功能仍然显示开发中
            emit('at_response', {
                'target': target,
                'content': f'{target} 功能正在开发中，敬请期待！',
                'time': datetime.now().strftime('%H:%M')
            }, room=DEFAULT_ROOM)

@socketio.on('get_online_users')
def handle_get_online_users():
    """获取在线用户列表"""
    emit('online_users', {
        'users': list(set([u['nickname'] for u in online_users.values()])),
        'online_count': len(online_users)
    })

# 天气API
@app.route('/api/weather')
def get_weather():
    """获取天气信息 - 使用多个备用API"""
    city = request.args.get('city', '北京')
    
    # 多个备用天气API
    apis = [
        {
            'url': f'https://wttr.in/{city}?format=j1',
            'parser': 'wttr'
        },
        {
            'url': f'https://api.seniverse.com/v3/weather/now.json?key=SqpGSfYkFNbBT0fXj&location={city}&language=zh-Hans&unit=c',
            'parser': 'seniverse'
        }
    ]
    
    for api in apis:
        try:
            response = requests.get(api['url'], timeout=8, headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept-Language': 'zh-CN,zh;q=0.9'
            })
            
            if response.status_code == 200:
                data = response.json()
                
                if api['parser'] == 'wttr':
                    # wttr.in API 解析
                    current = data.get('current_condition', [{}])[0]
                    weather_desc = current.get('lang_zh', [{}])
                    weather_text = weather_desc[0].get('value', '') if weather_desc else current.get('weatherDesc', [{}])[0].get('value', '')
                    
                    return jsonify({
                        'success': True,
                        'data': {
                            'city': city,
                            'date': data.get('weather', [{}])[0].get('date', ''),
                            'weather': weather_text,
                            'tem': current.get('temp_C', ''),
                            'tem_day': data.get('weather', [{}])[0].get('maxtempC', ''),
                            'tem_night': data.get('weather', [{}])[0].get('mintempC', ''),
                            'humidity': current.get('humidity', ''),
                            'win': current.get('winddir16Point', ''),
                            'win_speed': current.get('windspeedKmph', '') + 'km/h',
                            'air': '',
                            'air_level': '',
                            'air_tips': '',
                            'sunrise': data.get('weather', [{}])[0].get('astronomy', [{}])[0].get('sunrise', ''),
                            'sunset': data.get('weather', [{}])[0].get('astronomy', [{}])[0].get('sunset', ''),
                            'visibility': current.get('visibility', '')
                        }
                    })
                    
                elif api['parser'] == 'seniverse':
                    # 心知天气 API 解析
                    results = data.get('results', [{}])[0]
                    now = results.get('now', {})
                    location = results.get('location', {})
                    
                    return jsonify({
                        'success': True,
                        'data': {
                            'city': location.get('name', city),
                            'date': results.get('last_update', '')[:10],
                            'weather': now.get('text', ''),
                            'tem': now.get('temperature', ''),
                            'tem_day': '',
                            'tem_night': '',
                            'humidity': '',
                            'win': '',
                            'win_speed': '',
                            'air': '',
                            'air_level': '',
                            'air_tips': '',
                            'sunrise': '',
                            'sunset': '',
                            'visibility': ''
                        }
                    })
                    
        except Exception as e:
            print(f'天气API请求失败: {str(e)}')
            continue
    
    return jsonify({'success': False, 'message': '获取天气失败，请稍后重试'})

# 新闻API
@app.route('/api/news')
def get_news():
    """获取热点新闻"""
    news_type = request.args.get('type', '')
    
    # 新闻分类映射
    category_map = {
        '': '',
        '时政': '时政',
        '科技': '科技',
        '财经': '财经',
        '娱乐': '娱乐'
    }
    category = category_map.get(news_type, '')
    
    try:
        # 使用 topurl 新闻API（稳定可用）
        api_url = 'https://news.topurl.cn/api'
        if category:
            api_url += f'?category={category}'
        
        response = requests.get(api_url, timeout=10, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        if response.status_code == 200:
            data = response.json()
            
            if data.get('code') == 200:
                news_list = data.get('data', {}).get('newsList', [])[:10]
                return jsonify({
                    'success': True,
                    'data': {
                        'type': news_type or '热点',
                        'title': '今日热点新闻',
                        'list': [{
                            'title': item.get('title', ''),
                            'url': item.get('url', '#'),
                            'hot': f"{item.get('score', '')}分" if item.get('score') else '',
                            'index': idx + 1,
                            'category': item.get('category', '')
                        } for idx, item in enumerate(news_list)]
                    }
                })
    except Exception as e:
        print(f'新闻API请求失败: {str(e)}')
    
    return jsonify({'success': False, 'message': '获取新闻失败，请稍后重试'})

# 音乐API配置 - 多个备用源
MUSIC_APIS = {
    'random': [
        'https://api.uomg.com/api/rand.music?sort=热歌榜&format=json',
        'https://api.uomg.com/api/rand.music?sort=新歌榜&format=json',
        'https://api.uomg.com/api/rand.music?sort=飙升榜&format=json',
        'https://api.uomg.com/api/rand.music?sort=抖音榜&format=json',
    ],
    'search': 'https://api.uomg.com/api/comments.163?format=json'
}

@app.route('/api/music/random')
def get_random_music():
    """获取随机音乐 - 使用多个备用API源"""
    import random as rand_module
    
    # 随机选择一个榜单
    api_url = rand_module.choice(MUSIC_APIS['random'])
    
    try:
        response = requests.get(api_url, timeout=10, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        if response.status_code == 200:
            data = response.json()
            if data.get('code') == 1:
                music_data = data.get('data', {})
                return jsonify({
                    'success': True,
                    'data': {
                        'name': music_data.get('name', '未知歌曲'),
                        'singer': music_data.get('artistsname', '未知歌手'),
                        'url': music_data.get('url', ''),
                        'image': music_data.get('picurl', '')
                    }
                })
        
        # 备用API
        return try_backup_music_api()
    except Exception as e:
        return try_backup_music_api()

def try_backup_music_api():
    """尝试备用音乐API"""
    try:
        # 备用API: 酷我音乐随机
        response = requests.get('https://v2.xxapi.cn/api/randomkuwo', timeout=10)
        if response.status_code == 200:
            data = response.json()
            if data.get('code') == 200:
                return jsonify({
                    'success': True,
                    'data': data.get('data', {})
                })
        return jsonify({'success': False, 'message': '获取音乐失败，请稍后重试'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'请求错误: {str(e)}'})

@app.route('/api/music/search')
def search_music():
    """搜索音乐 - 使用网易云音乐API"""
    keyword = request.args.get('keyword', '').strip()
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    
    if not keyword:
        return jsonify({'success': False, 'message': '请输入搜索关键词'})
    
    try:
        # 使用网易云音乐搜索API
        search_url = f'https://music.163.com/api/search/get/web?s={keyword}&type=1&offset={(page-1)*limit}&limit={limit}'
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Referer': 'https://music.163.com/',
            'Cookie': 'appver=2.0.2'
        }
        
        response = requests.get(search_url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            if data.get('code') == 200 and data.get('result'):
                songs = data['result'].get('songs', [])
                song_list = []
                
                for song in songs[:limit]:
                    artists = song.get('artists', [])
                    artist_names = ', '.join([a.get('name', '') for a in artists])
                    album = song.get('album', {})
                    
                    song_list.append({
                        'id': song.get('id'),
                        'name': song.get('name', '未知歌曲'),
                        'singer': artist_names or '未知歌手',
                        'album': album.get('name', ''),
                        'image': album.get('picUrl', '') or f"https://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg",
                        'url': f"https://music.163.com/song/media/outer/url?id={song.get('id')}.mp3",
                        'duration': song.get('duration', 0)
                    })
                
                return jsonify({
                    'success': True,
                    'data': {
                        'songs': song_list,
                        'total': data['result'].get('songCount', 0),
                        'page': page,
                        'limit': limit
                    }
                })
        
        return jsonify({'success': False, 'message': '搜索失败，请稍后重试'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'搜索错误: {str(e)}'})

@app.route('/api/music/play/<int:song_id>')
def get_music_url(song_id):
    """获取音乐播放链接"""
    try:
        # 直接返回网易云音乐外链
        music_url = f"https://music.163.com/song/media/outer/url?id={song_id}.mp3"
        
        # 获取歌曲详情
        detail_url = f"https://music.163.com/api/song/detail/?ids=[{song_id}]"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Referer': 'https://music.163.com/'
        }
        
        response = requests.get(detail_url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            songs = data.get('songs', [])
            if songs:
                song = songs[0]
                artists = song.get('artists', [])
                artist_names = ', '.join([a.get('name', '') for a in artists])
                album = song.get('album', {})
                
                return jsonify({
                    'success': True,
                    'data': {
                        'id': song_id,
                        'name': song.get('name', '未知歌曲'),
                        'singer': artist_names or '未知歌手',
                        'album': album.get('name', ''),
                        'image': album.get('picUrl', ''),
                        'url': music_url
                    }
                })
        
        return jsonify({
            'success': True,
            'data': {
                'id': song_id,
                'url': music_url
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'message': f'获取播放链接失败: {str(e)}'})

@app.route('/api/music/hot')
def get_hot_songs():
    """获取热门歌曲推荐"""
    try:
        # 获取热门歌曲
        hot_url = 'https://music.163.com/api/playlist/detail?id=3778678'
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Referer': 'https://music.163.com/'
        }
        
        response = requests.get(hot_url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            if data.get('code') == 200:
                playlist = data.get('result', {})
                tracks = playlist.get('tracks', [])[:20]  # 取前20首
                
                song_list = []
                for track in tracks:
                    artists = track.get('artists', [])
                    artist_names = ', '.join([a.get('name', '') for a in artists])
                    album = track.get('album', {})
                    
                    song_list.append({
                        'id': track.get('id'),
                        'name': track.get('name', '未知歌曲'),
                        'singer': artist_names or '未知歌手',
                        'album': album.get('name', ''),
                        'image': album.get('picUrl', ''),
                        'url': f"https://music.163.com/song/media/outer/url?id={track.get('id')}.mp3"
                    })
                
                return jsonify({
                    'success': True,
                    'data': {
                        'songs': song_list,
                        'playlist_name': playlist.get('name', '热门歌曲')
                    }
                })
        
        return jsonify({'success': False, 'message': '获取热门歌曲失败'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'请求错误: {str(e)}'})

@app.route('/api/ai/chat', methods=['POST'])
def ai_chat_stream():
    """AI对话SSE流式接口"""
    data = request.get_json()
    question = data.get('question', '').strip()
    user_id = data.get('user_id', 'default')
    
    if not question:
        return jsonify({'error': '问题不能为空'}), 400
    
    def generate():
        try:
            # 获取或初始化用户对话历史
            if user_id not in chat_histories:
                chat_histories[user_id] = []
            
            history = chat_histories[user_id]
            
            # 构建消息列表
            messages = [
                {
                    "role": "system",
                    "content": "你是小理，一个友好、智能的AI助手。你在一个名为'神人聊天室'的群聊中帮助用户解答问题。请用简洁、友好的语气回复，适当使用emoji表情让对话更生动。"
                }
            ]
            
            # 添加历史对话
            for h in history[-10:]:  # 只保留最近10条
                messages.append(h)
            
            # 添加当前问题
            messages.append({"role": "user", "content": question})
            
            # 调用SiliconFlow API
            headers = {
                'Authorization': f'Bearer {AI_CONFIG["api_key"]}',
                'Content-Type': 'application/json'
            }
            
            payload = {
                'model': AI_CONFIG['model'],
                'messages': messages,
                'stream': True,
                'max_tokens': 1024,
                'temperature': 0.7
            }
            
            response = requests.post(
                AI_CONFIG['api_url'],
                headers=headers,
                json=payload,
                stream=True,
                timeout=60
            )
            
            if response.status_code != 200:
                yield f"data: {json.dumps({'error': f'API错误: {response.status_code}'})}\n\n"
                return
            
            full_response = ""
            
            for line in response.iter_lines():
                if line:
                    line_text = line.decode('utf-8')
                    if line_text.startswith('data: '):
                        json_str = line_text[6:]
                        if json_str.strip() == '[DONE]':
                            # 流式响应结束
                            yield f"data: {json.dumps({'done': True, 'full_content': full_response})}\n\n"
                            
                            # 保存对话历史
                            history.append({"role": "user", "content": question})
                            history.append({"role": "assistant", "content": full_response})
                            # 只保留最近20条
                            chat_histories[user_id] = history[-20:]
                            break
                        
                        try:
                            chunk_data = json.loads(json_str)
                            if 'choices' in chunk_data and len(chunk_data['choices']) > 0:
                                delta = chunk_data['choices'][0].get('delta', {})
                                content = delta.get('content', '')
                                if content:
                                    full_response += content
                                    yield f"data: {json.dumps({'content': content})}\n\n"
                        except json.JSONDecodeError:
                            continue
                            
        except requests.exceptions.Timeout:
            yield f"data: {json.dumps({'error': '请求超时，请稍后重试'})}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'error': f'发生错误: {str(e)}'})}\n\n"
    
    return Response(
        generate(),
        mimetype='text/event-stream',
        headers={
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'X-Accel-Buffering': 'no'
        }
    )

if __name__ == '__main__':
    print('=' * 50)
    print('神人聊天室 v1.0.0')
    print('服务器启动中...')
    print('访问地址: http://localhost:5050')
    print('=' * 50)
    socketio.run(app, host='0.0.0.0', port=5050, debug=True, use_reloader=False, allow_unsafe_werkzeug=True)
