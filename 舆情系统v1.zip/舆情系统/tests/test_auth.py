"""
认证测试
"""
import pytest


class TestAuth:
    """认证测试"""
    
    def test_login_page(self, client):
        """测试登录页面"""
        response = client.get('/auth/login')
        assert response.status_code == 200
    
    def test_register_page(self, client):
        """测试注册页面"""
        response = client.get('/auth/register')
        assert response.status_code == 200
    
    def test_register(self, client, app):
        """测试用户注册"""
        response = client.post('/auth/register', data={
            'username': 'newuser',
            'email': 'newuser@example.com',
            'password': 'password123',
            'confirm_password': 'password123'
        }, follow_redirects=True)
        assert response.status_code == 200
        
        with app.app_context():
            from app.models import User
            user = User.query.filter_by(username='newuser').first()
            assert user is not None
    
    def test_login(self, client, app):
        """测试用户登录"""
        # 先创建用户
        with app.app_context():
            from app import db
            from app.models import User
            user = User(username='testuser', email='test@example.com')
            user.set_password('password123')
            db.session.add(user)
            db.session.commit()
        
        # 测试登录
        response = client.post('/auth/login', data={
            'username': 'testuser',
            'password': 'password123'
        }, follow_redirects=True)
        assert response.status_code == 200
    
    def test_login_invalid_password(self, client, app):
        """测试错误密码登录"""
        with app.app_context():
            from app import db
            from app.models import User
            user = User(username='testuser', email='test@example.com')
            user.set_password('password123')
            db.session.add(user)
            db.session.commit()
        
        response = client.post('/auth/login', data={
            'username': 'testuser',
            'password': 'wrongpassword'
        })
        assert b'\xe7\x94\xa8\xe6\x88\xb7\xe5\x90\x8d\xe6\x88\x96\xe5\xaf\x86\xe7\xa0\x81\xe9\x94\x99\xe8\xaf\xaf' in response.data or response.status_code == 200
    
    def test_logout(self, auth_client):
        """测试登出"""
        response = auth_client.get('/auth/logout', follow_redirects=True)
        assert response.status_code == 200
