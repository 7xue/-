"""
API测试
"""
import pytest
import json


class TestArticleAPI:
    """文章API测试"""
    
    def test_get_articles_unauthorized(self, client):
        """测试未授权访问文章列表"""
        response = client.get('/api/articles')
        assert response.status_code in [401, 302]  # 未授权或重定向到登录
    
    def test_get_articles(self, auth_client, app, sample_article):
        """测试获取文章列表"""
        response = auth_client.get('/api/articles')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['code'] == 0
        assert 'items' in data['data']
    
    def test_get_article_detail(self, auth_client, app, sample_article):
        """测试获取文章详情"""
        response = auth_client.get(f'/api/articles/{sample_article}')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['code'] == 0
        assert data['data']['title'] == '测试文章标题'


class TestKeywordAPI:
    """关键词API测试"""
    
    def test_get_keywords(self, auth_client):
        """测试获取关键词列表"""
        response = auth_client.get('/api/keywords')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['code'] == 0
    
    def test_add_keyword(self, auth_client):
        """测试添加关键词"""
        response = auth_client.post('/api/keywords',
            data=json.dumps({'word': '新关键词', 'priority': 3}),
            content_type='application/json'
        )
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['code'] == 0
    
    def test_add_duplicate_keyword(self, auth_client, app):
        """测试添加重复关键词"""
        # 先添加一个关键词
        with app.app_context():
            from app import db
            from app.models import Keyword
            keyword = Keyword(word='已存在关键词')
            db.session.add(keyword)
            db.session.commit()
        
        # 尝试添加重复关键词
        response = auth_client.post('/api/keywords',
            data=json.dumps({'word': '已存在关键词'}),
            content_type='application/json'
        )
        assert response.status_code == 400


class TestStatisticsAPI:
    """统计API测试"""
    
    def test_get_overview(self, auth_client):
        """测试获取概览统计"""
        response = auth_client.get('/api/statistics/overview')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['code'] == 0
        assert 'total_articles' in data['data']
    
    def test_get_trend(self, auth_client):
        """测试获取趋势数据"""
        response = auth_client.get('/api/statistics/trend?days=7')
        assert response.status_code == 200
        
        data = json.loads(response.data)
        assert data['code'] == 0
