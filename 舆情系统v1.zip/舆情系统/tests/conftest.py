"""
Pytest 配置和 fixtures
"""
import pytest
from app import create_app, db
from app.models import User, Article, Keyword, Alert


@pytest.fixture
def app():
    """创建测试应用"""
    app = create_app('testing')
    
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()


@pytest.fixture
def client(app):
    """创建测试客户端"""
    return app.test_client()


@pytest.fixture
def runner(app):
    """创建 CLI 测试运行器"""
    return app.test_cli_runner()


@pytest.fixture
def auth_client(app, client):
    """创建已认证的测试客户端"""
    with app.app_context():
        user = User(username='testuser', email='test@example.com')
        user.set_password('password123')
        db.session.add(user)
        db.session.commit()
        
        client.post('/auth/login', data={
            'username': 'testuser',
            'password': 'password123'
        })
    
    return client


@pytest.fixture
def sample_article(app):
    """创建示例文章"""
    with app.app_context():
        article = Article(
            title='测试文章标题',
            content='这是测试文章的内容',
            source='测试来源',
            sentiment='neutral',
            sentiment_score=0.5
        )
        db.session.add(article)
        db.session.commit()
        return article.id
