"""
模型测试
"""
import pytest
from app.models import User, Article, Keyword, Alert


class TestUserModel:
    """用户模型测试"""
    
    def test_password_setter(self, app):
        """测试密码设置"""
        with app.app_context():
            from app import db
            user = User(username='test', email='test@test.com')
            user.set_password('password123')
            assert user.password_hash is not None
    
    def test_password_verification(self, app):
        """测试密码验证"""
        with app.app_context():
            from app import db
            user = User(username='test', email='test@test.com')
            user.set_password('password123')
            assert user.check_password('password123') is True
            assert user.check_password('wrongpassword') is False
    
    def test_password_salts_are_random(self, app):
        """测试密码盐值随机性"""
        with app.app_context():
            from app import db
            user1 = User(username='test1', email='test1@test.com')
            user2 = User(username='test2', email='test2@test.com')
            user1.set_password('password123')
            user2.set_password('password123')
            assert user1.password_hash != user2.password_hash


class TestArticleModel:
    """文章模型测试"""
    
    def test_article_creation(self, app):
        """测试文章创建"""
        with app.app_context():
            from app import db
            article = Article(
                title='测试标题',
                content='测试内容',
                source='测试来源'
            )
            db.session.add(article)
            db.session.commit()
            
            assert article.id is not None
            assert article.title == '测试标题'
    
    def test_article_to_dict(self, app):
        """测试文章序列化"""
        with app.app_context():
            from app import db
            article = Article(
                title='测试标题',
                content='测试内容',
                sentiment='positive'
            )
            db.session.add(article)
            db.session.commit()
            
            data = article.to_dict()
            assert data['title'] == '测试标题'
            assert data['sentiment'] == 'positive'


class TestKeywordModel:
    """关键词模型测试"""
    
    def test_keyword_creation(self, app):
        """测试关键词创建"""
        with app.app_context():
            from app import db
            keyword = Keyword(word='测试关键词', priority=5)
            db.session.add(keyword)
            db.session.commit()
            
            assert keyword.id is not None
            assert keyword.is_active is True
