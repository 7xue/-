# 舆情监控系统

基于 Flask 的舆情监控与分析平台。

## 功能特性

- 实时舆情监控
- 情感分析（正面/中性/负面）
- 智能预警
- 关键词管理
- 数据可视化分析

## 快速开始

```bash
# 1. 安装依赖
pip install -r requirements/dev.txt

# 2. 配置环境变量
copy .env.example .env

# 3. 初始化数据库
flask init

# 4. 运行
flask run
```

访问 http://localhost:5000

## 项目结构

```
├── app/                # 应用代码
│   ├── main/          # 主模块
│   ├── auth/          # 认证模块
│   └── api/           # API接口
├── migrations/        # 数据库迁移
├── tests/             # 测试代码
├── static/            # 静态资源
├── templates/         # 模板文件
├── docs/              # 文档
├── requirements/      # 依赖配置
├── tools/             # 工具脚本
└── config.py          # 配置文件
```

## 技术栈

- Flask 3.0
- SQLAlchemy
- Chart.js
- Jinja2

## License

MIT
