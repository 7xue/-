#!/usr/bin/env python
"""
舆情数据采集模块
用于从百度新闻接口采集舆情数据
"""
import re
import time
import random
import requests
from urllib.parse import quote, urlencode
from bs4 import BeautifulSoup
from dataclasses import dataclass, asdict, field
from typing import List, Optional, Dict, Any
from datetime import datetime


@dataclass
class NewsItem:
    """新闻数据项"""
    title: str           # 标题
    summary: str         # 概要
    cover: str           # 封面图片URL
    url: str             # 原始URL
    source: str          # 来源
    publish_time: str = ""   # 发布时间
    keyword: str = ""        # 采集关键词
    crawl_time: str = field(default_factory=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class BaiduNewsCrawler:
    """百度新闻采集器"""
    
    BASE_URL = "https://www.baidu.com/s"
    
    # 完整的请求头配置
    HEADERS = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Sec-Ch-Ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.5845.97 Safari/537.36 Core/1.116.586.400 QQBrowser/19.8.6883.400'
    }
    
    # 完整Cookie配置
    COOKIE_STRING = "BIDUPSID=D48AC21A701043225723F7B0416A45A5; PSTM=1749868400; BD_UPN=1a314753; BAIDUID=D48AC21A70104322974B66FAE2F73383:SL=0:NR=10:FG=1; MAWEBCUID=web_YJdcNWbgVAvBDdOlAjnOFGURksbLStlKretXHCZPDmkKBoCWao; MCITY=-75%3A; newlogin=1; BDUSS=Bsb0RmVWp3c0NmMHNwOVpnVTZpSUU1Rn5IU1c1S29EVVJQYVI0ZWFnWEhDazVwSVFBQUFBJCQAAAAAAAAAAAEAAACr7QECeWFuZ2FodWkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMd9JmnHfSZpNX; BDUSS_BFESS=Bsb0RmVWp3c0NmMHNwOVpnVTZpSUU1Rn5IU1c1S29EVVJQYVI0ZWFnWEhDazVwSVFBQUFBJCQAAAAAAAAAAAEAAACr7QECeWFuZ2FodWkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMd9JmnHfSZpNX; BAIDUID_BFESS=D48AC21A70104322974B66FAE2F73383:SL=0:NR=10:FG=1; H_WISE_SIDS_BFESS=60272_63144_66104_66109_66213_66232_66288_66271_66393_66510_66516_66529_66552_66589_66591_66601_66606_66652_66671_66669_66694_66685_66599_66720_66744_66623; __bid_n=19ad5be04673728d3e48c8; PAD_BROWSER=1; ZFY=:BbjM:A1IBjzvZvV4stKekEFIixozKxmgJlX2ZrIwt9J0:C; Hm_lvt_aec699bb6442ba076c8981c6dc490771=1764321838,1764467635,1764522517,1764723037; COOKIE_SESSION=61096_0_9_9_12_35_1_3_9_8_0_1_61094_0_4_0_1764723038_0_1764723034%7C9%2325100_26_1764063190%7C9; sug=3; sugstore=0; ORIGIN=0; bdime=0; H_PS_PSSID=60272_63144_66104_66109_66213_66232_66288_66271_66393_66510_66516_66529_66552_66589_66591_66601_66606_66652_66671_66669_66694_66685_66720_66744_66623_66772_66787_66792_66747_66806_66799_66599"
    
    def __init__(self, timeout: int = 15, max_retries: int = 3):
        """
        初始化采集器
        
        Args:
            timeout: 请求超时时间（秒）
            max_retries: 最大重试次数
        """
        self.session = requests.Session()
        self.session.headers.update(self.HEADERS)
        self.session.headers['Cookie'] = self.COOKIE_STRING
        self.timeout = timeout
        self.max_retries = max_retries
    
    def search(self, keyword: str, page: int = 1) -> List[NewsItem]:
        """
        搜索新闻
        
        Args:
            keyword: 搜索关键词
            page: 页码（从1开始）
            
        Returns:
            新闻列表
        """
        params = {
            'rtt': '1',
            'bsst': '1',
            'cl': '2',
            'tn': 'news',
            'rsv_dl': 'ns_pc',
            'word': keyword,
            'pn': (page - 1) * 10
        }
        
        for attempt in range(self.max_retries):
            try:
                # 添加随机延迟
                time.sleep(random.uniform(1.0, 3.0))
                
                response = self.session.get(
                    self.BASE_URL,
                    params=params,
                    timeout=self.timeout,
                    allow_redirects=True
                )
                response.raise_for_status()
                response.encoding = 'utf-8'
                
                news_list = self._parse_response(response.text, keyword)
                if news_list:
                    return news_list
                    
            except requests.RequestException as e:
                print(f"请求失败 (尝试 {attempt + 1}/{self.max_retries}): {e}")
                if attempt < self.max_retries - 1:
                    time.sleep(random.uniform(2.0, 5.0))
                continue
        
        return []
    
    def _parse_response(self, html: str, keyword: str) -> List[NewsItem]:
        """解析响应HTML"""
        news_list = []
        soup = BeautifulSoup(html, 'html.parser')
        
        # 百度新闻的多种可能容器选择器
        selectors = [
            'div.result-op.c-container.xpath-log',
            'div.result.c-container',
            'div[class*="result"]',
            'div[tpl="news_summary"]',
            'div.c-container'
        ]
        
        containers = []
        for selector in selectors:
            found = soup.select(selector)
            if found:
                containers = found
                break
        
        # 如果没找到容器，尝试直接查找新闻标题
        if not containers:
            containers = soup.find_all('div', class_=lambda x: x and 'c-container' in x)
        
        for container in containers:
            try:
                news_item = self._parse_news_item(container, keyword)
                if news_item and news_item.title:
                    news_list.append(news_item)
            except Exception as e:
                continue
        
        return news_list
    
    def _parse_news_item(self, container, keyword: str) -> Optional[NewsItem]:
        """解析单条新闻"""
        # 提取标题和URL - 多种选择器
        title_elem = None
        for selector in ['h3.c-title a', 'h3 a', '.c-title a', 'a[href*="baidu.com"]']:
            title_elem = container.select_one(selector)
            if title_elem:
                break
        
        if not title_elem:
            return None
        
        title = title_elem.get_text(strip=True)
        url = title_elem.get('href', '')
        
        if not title or len(title) < 5:
            return None
        
        # 提取概要
        summary = ''
        for selector in ['.c-summary', '.c-abstract', 'div.c-span9', '.content-right', 'span.c-color-text']:
            elem = container.select_one(selector)
            if elem:
                summary = elem.get_text(strip=True)
                if summary:
                    break
        
        # 如果还没找到，尝试获取容器内所有文本
        if not summary:
            all_text = container.get_text(strip=True)
            if len(all_text) > len(title) + 20:
                summary = all_text[len(title):].strip()[:300]
        
        summary = self._clean_text(summary)
        
        # 提取封面图片
        cover = ''
        img_elem = container.select_one('img[src*="http"], img[data-src*="http"]')
        if img_elem:
            cover = img_elem.get('src', '') or img_elem.get('data-src', '')
        
        # 提取来源和时间
        source = ''
        publish_time = ''
        
        # 查找来源信息
        for selector in ['.c-author', '.news-source', 'span.c-color-gray', 'span.c-color-gray2', '.source-wrap']:
            source_elem = container.select_one(selector)
            if source_elem:
                source_text = source_elem.get_text(strip=True)
                if source_text:
                    # 解析来源和时间
                    parts = re.split(r'\s{2,}|·', source_text)
                    if parts:
                        source = parts[0].strip()
                        if len(parts) > 1:
                            publish_time = parts[-1].strip()
                    break
        
        # 尝试从其他位置提取时间
        if not publish_time:
            time_patterns = [
                r'(\d+分钟前)',
                r'(\d+小时前)',
                r'(\d+天前)',
                r'(今天\s*\d{1,2}:\d{2})',
                r'(昨天\s*\d{1,2}:\d{2})',
                r'(\d{1,2}月\d{1,2}日)',
                r'(\d{4}-\d{2}-\d{2})'
            ]
            container_text = container.get_text()
            for pattern in time_patterns:
                match = re.search(pattern, container_text)
                if match:
                    publish_time = match.group(1)
                    break
        
        return NewsItem(
            title=title,
            summary=summary[:500] if summary else '',
            cover=cover,
            url=url,
            source=source,
            publish_time=publish_time,
            keyword=keyword
        )
    
    def _clean_text(self, text: str) -> str:
        """清理文本"""
        if not text:
            return ''
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'^\s*[\u4e00-\u9fa5]+\s*\d{1,2}[\u5206\u5c0f\u65f6\u5929\u524d]+', '', text)
        return text.strip()
    
    def crawl_multiple_pages(self, keyword: str, pages: int = 3) -> List[NewsItem]:
        """采集多页数据"""
        all_news = []
        for page in range(1, pages + 1):
            print(f"正在采集第 {page} 页...")
            news = self.search(keyword, page)
            all_news.extend(news)
            print(f"第 {page} 页采集到 {len(news)} 条新闻")
            if not news:
                print("未获取到数据，停止采集")
                break
        return all_news


def crawl_news(keyword: str, pages: int = 1) -> List[Dict[str, Any]]:
    """
    采集新闻的便捷函数
    
    Args:
        keyword: 搜索关键词
        pages: 采集页数
        
    Returns:
        新闻字典列表，每条包含: title, summary, cover, url, source, publish_time
    """
    crawler = BaiduNewsCrawler()
    if pages == 1:
        news_list = crawler.search(keyword)
    else:
        news_list = crawler.crawl_multiple_pages(keyword, pages)
    
    return [news.to_dict() for news in news_list]


# 用于Flask应用集成的服务类
class CrawlerService:
    """采集服务，用于与Flask应用集成"""
    
    def __init__(self):
        self.crawler = BaiduNewsCrawler()
    
    def crawl(self, keyword: str, pages: int = 1) -> Dict[str, Any]:
        """
        执行采集任务
        
        Args:
            keyword: 搜索关键词
            pages: 采集页数
            
        Returns:
            采集结果字典，包含 success, data, count, message
        """
        try:
            if pages == 1:
                news_list = self.crawler.search(keyword)
            else:
                news_list = self.crawler.crawl_multiple_pages(keyword, pages)
            
            results = [news.to_dict() for news in news_list]
            
            return {
                'success': True,
                'data': results,
                'count': len(results),
                'keyword': keyword,
                'message': f'成功采集 {len(results)} 条新闻'
            }
        except Exception as e:
            return {
                'success': False,
                'data': [],
                'count': 0,
                'keyword': keyword,
                'message': f'采集失败: {str(e)}'
            }


# 测试代码
if __name__ == '__main__':
    import json
    
    keyword = "西昌"
    print(f"开始采集关键词: {keyword}")
    print("-" * 50)
    
    # 使用服务类进行采集
    service = CrawlerService()
    result = service.crawl(keyword, pages=1)
    
    if result['success']:
        print(f"\n{result['message']}")
        print("-" * 50)
        
        for i, news in enumerate(result['data'], 1):
            print(f"\n【{i}】")
            print(f"标题: {news['title']}")
            print(f"概要: {news['summary'][:100]}..." if len(news['summary']) > 100 else f"概要: {news['summary']}")
            print(f"封面: {news['cover']}")
            print(f"原始URL: {news['url']}")
            print(f"来源: {news['source']}")
            print(f"发布时间: {news['publish_time']}")
        
        print("\n" + "=" * 50)
        print("JSON格式输出:")
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"采集失败: {result['message']}")
