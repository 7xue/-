#!/usr/bin/env python
"""
政企智能舆情分析报告生成智能体应用系统 - 入口文件
"""
import os
from app import create_app, db
from app.models import User, Role, SystemSetting, Report

app = create_app(os.getenv('FLASK_ENV') or 'default')


@app.shell_context_processor
def make_shell_context():
    return dict(db=db, User=User, Role=Role, SystemSetting=SystemSetting, Report=Report)


def init_database():
    """初始化数据库和默认数据"""
    with app.app_context():
        # 创建所有表
        db.create_all()
        
        # 创建默认角色
        if not Role.query.filter_by(name='admin').first():
            admin_role = Role(
                name='admin',
                display_name='管理员',
                description='系统管理员，拥有所有权限'
            )
            db.session.add(admin_role)
            print('创建角色: 管理员')
        
        if not Role.query.filter_by(name='user').first():
            user_role = Role(
                name='user',
                display_name='普通用户',
                description='普通用户，可查看报表和报告'
            )
            db.session.add(user_role)
            print('创建角色: 普通用户')
        
        db.session.commit()
        
        # 创建默认管理员账户
        admin_role = Role.query.filter_by(name='admin').first()
        if not User.query.filter_by(username='admin').first():
            admin_user = User(
                username='admin',
                real_name='系统管理员',
                role_id=admin_role.id,
                is_active=True
            )
            admin_user.set_password('admin123')
            db.session.add(admin_user)
            db.session.commit()
            print('创建管理员账户: admin / admin123')
        
        # 初始化系统设置
        if not SystemSetting.query.filter_by(key='app_name').first():
            SystemSetting.set('app_name', '政企智能舆情分析报告生成智能体应用系统', '应用名称')
            SystemSetting.set('app_short_name', '智能舆情系统', '应用简称')
            print('初始化系统设置完成')
        
        print('数据库初始化完成!')


if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == 'init':
        init_database()
    else:
        app.run(debug=True, host='0.0.0.0', port=5000)
