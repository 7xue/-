# 部署指南

## 环境要求
- Python 3.8+
- MySQL 5.7+ 或 SQLite

## 安装步骤

1. 克隆项目
```bash
git clone <repo_url>
cd 舆情系统
```

2. 创建虚拟环境
```bash
python -m venv venv
venv\Scripts\activate  # Windows
```

3. 安装依赖
```bash
pip install -r requirements/dev.txt
```

4. 配置环境变量
```bash
copy .env.example .env
# 编辑 .env 文件
```

5. 初始化数据库
```bash
flask db upgrade
```

6. 运行应用
```bash
flask run
```

## 生产部署
使用 Gunicorn + Nginx 部署
