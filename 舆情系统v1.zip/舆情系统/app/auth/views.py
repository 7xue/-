"""
认证视图 - 登录/退出
"""
from datetime import datetime
from flask import render_template, redirect, url_for, request, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from app.auth import auth
from app.models import User
from app import db


@auth.route('/login', methods=['GET', 'POST'])
def login():
    """登录页面"""
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    return render_template('auth/login.html')


@auth.route('/api/login', methods=['POST'])
def api_login():
    """登录API"""
    data = request.get_json()
    username = data.get('username', '')
    password = data.get('password', '')
    
    if not username or not password:
        return jsonify({'code': 1, 'msg': '请输入用户名和密码'})
    
    user = User.query.filter_by(username=username).first()
    
    if not user:
        return jsonify({'code': 1, 'msg': '用户名或密码错误'})
    
    if not user.check_password(password):
        return jsonify({'code': 1, 'msg': '用户名或密码错误'})
    
    if not user.is_active:
        return jsonify({'code': 1, 'msg': '账户已被禁用，请联系管理员'})
    
    # 更新最后登录时间
    user.last_login = datetime.utcnow()
    db.session.commit()
    
    login_user(user, remember=True)
    
    # 登录后统一跳转到主界面
    redirect_url = url_for('main.index')
    
    return jsonify({
        'code': 0,
        'msg': '登录成功',
        'data': {
            'redirect': redirect_url
        }
    })


@auth.route('/logout')
@login_required
def logout():
    """退出登录"""
    logout_user()
    return redirect(url_for('auth.login'))
