"""
API视图
"""
from flask import request, jsonify
from flask_login import login_required, current_user
from app.api import api
from app.models import Article, Alert, Keyword, User
from app import db
from datetime import datetime, timedelta
from sqlalchemy import func


@api.route('/articles', methods=['GET'])
@login_required
def get_articles():
    """获取文章列表"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    query = Article.query.order_by(Article.created_at.desc())
    
    # 筛选
    sentiment = request.args.get('sentiment')
    if sentiment:
        query = query.filter_by(sentiment=sentiment)
    
    category = request.args.get('category')
    if category:
        query = query.filter_by(category=category)
    
    keyword = request.args.get('keyword')
    if keyword:
        query = query.filter(Article.title.contains(keyword) | Article.content.contains(keyword))
    
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'code': 0,
        'data': {
            'items': [article.to_dict() for article in pagination.items],
            'total': pagination.total,
            'page': page,
            'per_page': per_page,
            'pages': pagination.pages
        }
    })


@api.route('/articles/<int:id>', methods=['GET'])
@login_required
def get_article(id):
    """获取文章详情"""
    article = Article.query.get_or_404(id)
    return jsonify({
        'code': 0,
        'data': article.to_dict()
    })


@api.route('/alerts', methods=['GET'])
@login_required
def get_alerts():
    """获取预警列表"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    query = Alert.query.order_by(Alert.created_at.desc())
    
    level = request.args.get('level')
    if level:
        query = query.filter_by(level=level)
    
    is_handled = request.args.get('is_handled')
    if is_handled is not None:
        query = query.filter_by(is_handled=is_handled.lower() == 'true')
    
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'code': 0,
        'data': {
            'items': [{
                'id': alert.id,
                'title': alert.title,
                'content': alert.content,
                'level': alert.level,
                'is_read': alert.is_read,
                'is_handled': alert.is_handled,
                'created_at': alert.created_at.isoformat() if alert.created_at else None
            } for alert in pagination.items],
            'total': pagination.total,
            'page': page,
            'per_page': per_page
        }
    })


@api.route('/alerts/<int:id>/handle', methods=['POST'])
@login_required
def handle_alert(id):
    """处理预警"""
    alert = Alert.query.get_or_404(id)
    alert.is_handled = True
    alert.handled_by = current_user.id
    alert.handled_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'message': '预警已处理'
    })


@api.route('/keywords', methods=['GET'])
@login_required
def get_keywords():
    """获取关键词列表"""
    keywords = Keyword.query.order_by(Keyword.priority.desc()).all()
    return jsonify({
        'code': 0,
        'data': [{
            'id': kw.id,
            'word': kw.word,
            'category': kw.category,
            'priority': kw.priority,
            'is_active': kw.is_active
        } for kw in keywords]
    })


@api.route('/keywords', methods=['POST'])
@login_required
def add_keyword():
    """添加关键词"""
    data = request.get_json()
    
    if Keyword.query.filter_by(word=data['word']).first():
        return jsonify({
            'code': 1,
            'message': '关键词已存在'
        }), 400
    
    keyword = Keyword(
        word=data['word'],
        category=data.get('category'),
        priority=data.get('priority', 1),
        created_by=current_user.id
    )
    db.session.add(keyword)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'message': '关键词添加成功',
        'data': {'id': keyword.id}
    })


@api.route('/keywords/<int:id>', methods=['DELETE'])
@login_required
def delete_keyword(id):
    """删除关键词"""
    keyword = Keyword.query.get_or_404(id)
    db.session.delete(keyword)
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'message': '关键词已删除'
    })


@api.route('/statistics/overview', methods=['GET'])
@login_required
def get_overview():
    """获取概览统计"""
    today = datetime.utcnow().date()
    week_ago = today - timedelta(days=7)
    
    # 今日数据
    today_articles = Article.query.filter(
        func.date(Article.created_at) == today
    ).count()
    
    today_alerts = Alert.query.filter(
        func.date(Alert.created_at) == today
    ).count()
    
    # 总数据
    total_articles = Article.query.count()
    total_alerts = Alert.query.count()
    pending_alerts = Alert.query.filter_by(is_handled=False).count()
    
    # 情感分布
    sentiment_stats = db.session.query(
        Article.sentiment,
        func.count(Article.id)
    ).group_by(Article.sentiment).all()
    
    return jsonify({
        'code': 0,
        'data': {
            'today_articles': today_articles,
            'today_alerts': today_alerts,
            'total_articles': total_articles,
            'total_alerts': total_alerts,
            'pending_alerts': pending_alerts,
            'sentiment_stats': dict(sentiment_stats)
        }
    })


@api.route('/statistics/trend', methods=['GET'])
@login_required
def get_trend():
    """获取趋势数据"""
    days = request.args.get('days', 7, type=int)
    end_date = datetime.utcnow().date()
    start_date = end_date - timedelta(days=days)
    
    # 每日文章数
    daily_articles = db.session.query(
        func.date(Article.created_at).label('date'),
        func.count(Article.id).label('count')
    ).filter(
        Article.created_at >= start_date
    ).group_by(
        func.date(Article.created_at)
    ).all()
    
    return jsonify({
        'code': 0,
        'data': {
            'dates': [str(item.date) for item in daily_articles],
            'counts': [item.count for item in daily_articles]
        }
    })


# ==================== 数据采集接口 ====================

@api.route('/crawler/search', methods=['POST'])
@login_required
def crawler_search():
    """
    采集新闻数据
    
    请求参数:
        keyword: 搜索关键词（必填）
        pages: 采集页数（可选，默认1）
        
    返回数据:
        每条新闻包含: title, summary, cover, url, source, publish_time
    """
    import sys
    import os
    # 添加tools目录到路径
    tools_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'tools')
    if tools_path not in sys.path:
        sys.path.insert(0, tools_path)
    
    from crawler import CrawlerService
    
    data = request.get_json() or {}
    keyword = data.get('keyword', '').strip()
    
    if not keyword:
        return jsonify({
            'code': 1,
            'message': '请输入搜索关键词'
        }), 400
    
    pages = data.get('pages', 1)
    if not isinstance(pages, int) or pages < 1:
        pages = 1
    if pages > 5:
        pages = 5  # 限制最大页数
    
    # 执行采集
    service = CrawlerService()
    result = service.crawl(keyword, pages)
    
    if result['success']:
        return jsonify({
            'code': 0,
            'message': result['message'],
            'data': {
                'keyword': result['keyword'],
                'count': result['count'],
                'items': result['data']
            }
        })
    else:
        return jsonify({
            'code': 1,
            'message': result['message']
        }), 500


@api.route('/crawler/save', methods=['POST'])
@login_required
def crawler_save():
    """
    保存采集的新闻到数据库
    
    请求参数:
        items: 新闻列表，每条包含 title, summary, cover, url, source
    """
    data = request.get_json() or {}
    items = data.get('items', [])
    
    if not items:
        return jsonify({
            'code': 1,
            'message': '没有要保存的数据'
        }), 400
    
    saved_count = 0
    skipped_count = 0
    
    for item in items:
        # 检查是否已存在（通过URL判断）
        existing = Article.query.filter_by(url=item.get('url', '')).first()
        if existing:
            skipped_count += 1
            continue
        
        article = Article(
            title=item.get('title', ''),
            content=item.get('summary', ''),
            url=item.get('url', ''),
            source=item.get('source', ''),
            cover_image=item.get('cover', ''),
            publish_time=item.get('publish_time', ''),
            keyword=item.get('keyword', ''),
            created_by=current_user.id
        )
        db.session.add(article)
        saved_count += 1
    
    db.session.commit()
    
    return jsonify({
        'code': 0,
        'message': f'保存成功: {saved_count} 条，跳过重复: {skipped_count} 条',
        'data': {
            'saved': saved_count,
            'skipped': skipped_count
        }
    })
