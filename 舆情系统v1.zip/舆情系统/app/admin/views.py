"""
后台管理视图
"""
from flask import render_template, request, jsonify, current_app
from flask_login import login_required, current_user
from functools import wraps
from app.admin import admin
from app.models import User, Role, SystemSetting
from app import db


def admin_required(f):
    """管理员权限装饰器"""
    @wraps(f)
    @login_required
    def decorated_function(*args, **kwargs):
        if not current_user.is_admin():
            return jsonify({'code': 403, 'msg': '无权限访问'}), 403
        return f(*args, **kwargs)
    return decorated_function


@admin.route('/')
@admin_required
def index():
    """后台首页"""
    return render_template('admin/index.html')


# ============ 用户管理 ============
@admin.route('/users')
@admin_required
def users():
    """用户管理页面"""
    return render_template('admin/users.html')


@admin.route('/api/users')
@admin_required
def api_users():
    """获取用户列表API"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    username = request.args.get('username', '')
    
    query = User.query
    if username:
        query = query.filter(User.username.like(f'%{username}%'))
    
    pagination = query.order_by(User.id.desc()).paginate(page=page, per_page=limit, error_out=False)
    
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': pagination.total,
        'data': [user.to_dict() for user in pagination.items]
    })


@admin.route('/api/users', methods=['POST'])
@admin_required
def api_add_user():
    """添加用户API"""
    data = request.get_json()
    
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'code': 1, 'msg': '用户名已存在'})
    
    user = User(
        username=data['username'],
        real_name=data.get('real_name', ''),
        email=data.get('email', ''),
        phone=data.get('phone', ''),
        role_id=data.get('role_id'),
        is_active=data.get('is_active', True)
    )
    user.set_password(data['password'])
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '添加成功'})


@admin.route('/api/users/<int:id>', methods=['PUT'])
@admin_required
def api_update_user(id):
    """更新用户API"""
    user = User.query.get_or_404(id)
    data = request.get_json()
    
    if data.get('username') and data['username'] != user.username:
        if User.query.filter_by(username=data['username']).first():
            return jsonify({'code': 1, 'msg': '用户名已存在'})
        user.username = data['username']
    
    if data.get('real_name'):
        user.real_name = data['real_name']
    if data.get('email'):
        user.email = data['email']
    if data.get('phone'):
        user.phone = data['phone']
    if data.get('role_id'):
        user.role_id = data['role_id']
    if 'is_active' in data:
        user.is_active = data['is_active']
    if data.get('password'):
        user.set_password(data['password'])
    
    db.session.commit()
    return jsonify({'code': 0, 'msg': '更新成功'})


@admin.route('/api/users/<int:id>', methods=['DELETE'])
@admin_required
def api_delete_user(id):
    """删除用户API"""
    if id == current_user.id:
        return jsonify({'code': 1, 'msg': '不能删除当前登录用户'})
    
    user = User.query.get_or_404(id)
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '删除成功'})


# ============ 角色管理 ============
@admin.route('/roles')
@admin_required
def roles():
    """角色管理页面"""
    return render_template('admin/roles.html')


@admin.route('/api/roles')
@admin_required
def api_roles():
    """获取角色列表API"""
    roles = Role.query.all()
    return jsonify({
        'code': 0,
        'msg': 'success',
        'count': len(roles),
        'data': [role.to_dict() for role in roles]
    })


@admin.route('/api/roles', methods=['POST'])
@admin_required
def api_add_role():
    """添加角色API"""
    data = request.get_json()
    
    if Role.query.filter_by(name=data['name']).first():
        return jsonify({'code': 1, 'msg': '角色标识已存在'})
    
    role = Role(
        name=data['name'],
        display_name=data['display_name'],
        description=data.get('description', '')
    )
    db.session.add(role)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '添加成功'})


@admin.route('/api/roles/<int:id>', methods=['PUT'])
@admin_required
def api_update_role(id):
    """更新角色API"""
    role = Role.query.get_or_404(id)
    data = request.get_json()
    
    role.display_name = data.get('display_name', role.display_name)
    role.description = data.get('description', role.description)
    
    db.session.commit()
    return jsonify({'code': 0, 'msg': '更新成功'})


@admin.route('/api/roles/<int:id>', methods=['DELETE'])
@admin_required
def api_delete_role(id):
    """删除角色API"""
    role = Role.query.get_or_404(id)
    
    if role.name in ['admin', 'user']:
        return jsonify({'code': 1, 'msg': '系统内置角色不能删除'})
    
    if role.users.count() > 0:
        return jsonify({'code': 1, 'msg': '该角色下存在用户，不能删除'})
    
    db.session.delete(role)
    db.session.commit()
    
    return jsonify({'code': 0, 'msg': '删除成功'})


# ============ 系统设置 ============
@admin.route('/settings')
@admin_required
def settings():
    """系统设置页面"""
    return render_template('admin/settings.html')


@admin.route('/api/settings')
@admin_required
def api_get_settings():
    """获取系统设置API"""
    settings = SystemSetting.query.all()
    return jsonify({
        'code': 0,
        'data': {s.key: s.value for s in settings}
    })


@admin.route('/api/settings', methods=['POST'])
@admin_required
def api_save_settings():
    """保存系统设置API"""
    data = request.get_json()
    
    for key, value in data.items():
        SystemSetting.set(key, value)
    
    return jsonify({'code': 0, 'msg': '保存成功'})
