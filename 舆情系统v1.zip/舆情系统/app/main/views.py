"""
主视图 - 普通用户页面
"""
from flask import render_template, jsonify, redirect, url_for
from flask_login import login_required, current_user
from app.main import main
from app.models import Report


@main.route('/')
def index():
    """首页 - 未登录跳转登录页，已登录显示主界面"""
    if not current_user.is_authenticated:
        return redirect(url_for('auth.login'))
    return render_template('main/index.html')


@main.route('/reports')
@login_required
def reports():
    """报告列表"""
    return render_template('main/reports.html')


@main.route('/api/reports')
@login_required
def api_reports():
    """获取已发布报告列表API"""
    reports = Report.query.filter_by(status='published').order_by(Report.created_at.desc()).limit(20).all()
    return jsonify({
        'code': 0,
        'data': [r.to_dict() for r in reports]
    })


@main.route('/report/<int:id>')
@login_required
def report_detail(id):
    """报告详情"""
    report = Report.query.get_or_404(id)
    return render_template('main/report_detail.html', report=report)
