"""
政企智能舆情分析报告生成智能体应用系统
技术栈: Flask + SQLite + Layui
"""
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from config import config

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message = '请先登录'


def create_app(config_name='default'):
    """应用工厂函数"""
    app = Flask(__name__,
                template_folder='../templates',
                static_folder='../static')
    
    app.config.from_object(config[config_name])
    config[config_name].init_app(app)
    
    # 初始化扩展
    db.init_app(app)
    login_manager.init_app(app)
    
    # 注册蓝图
    from app.auth import auth as auth_blueprint
    app.register_blueprint(auth_blueprint)
    
    from app.main import main as main_blueprint
    app.register_blueprint(main_blueprint)
    
    from app.admin import admin as admin_blueprint
    app.register_blueprint(admin_blueprint, url_prefix='/admin')
    
    from app.api import api as api_blueprint
    app.register_blueprint(api_blueprint, url_prefix='/api')
    
    # 注册上下文处理器
    @app.context_processor
    def inject_settings():
        from app.models import SystemSetting
        return {
            'app_name': SystemSetting.get('app_name', app.config['APP_NAME']),
            'app_short_name': SystemSetting.get('app_short_name', app.config['APP_SHORT_NAME'])
        }
    
    return app
