"""
政企智能舆情分析报告生成智能体应用系统 - 数据模型
"""
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from app import db, login_manager


class Role(db.Model):
    """角色模型"""
    __tablename__ = 'roles'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True, nullable=False)  # admin, user
    display_name = db.Column(db.String(64), nullable=False)  # 管理员, 普通用户
    description = db.Column(db.String(256))
    permissions = db.Column(db.Text)  # JSON格式的权限列表
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    users = db.relationship('User', backref='role', lazy='dynamic')
    
    def __repr__(self):
        return f'<Role {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'display_name': self.display_name,
            'description': self.description
        }


class User(UserMixin, db.Model):
    """用户模型"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, index=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    real_name = db.Column(db.String(64))  # 真实姓名
    email = db.Column(db.String(120))
    phone = db.Column(db.String(20))
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'))
    is_active = db.Column(db.Boolean, default=True)
    last_login = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def set_password(self, password):
        """设置密码（加密存储）"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """验证密码"""
        return check_password_hash(self.password_hash, password)
    
    def is_admin(self):
        """判断是否为管理员"""
        return self.role and self.role.name == 'admin'
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'real_name': self.real_name,
            'email': self.email,
            'phone': self.phone,
            'role_id': self.role_id,
            'role_name': self.role.display_name if self.role else '',
            'is_active': self.is_active,
            'last_login': self.last_login.strftime('%Y-%m-%d %H:%M:%S') if self.last_login else '',
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else ''
        }
    
    def __repr__(self):
        return f'<User {self.username}>'


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class SystemSetting(db.Model):
    """系统设置模型"""
    __tablename__ = 'system_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(64), unique=True, nullable=False)
    value = db.Column(db.Text)
    description = db.Column(db.String(256))
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @staticmethod
    def get(key, default=None):
        """获取设置值"""
        setting = SystemSetting.query.filter_by(key=key).first()
        return setting.value if setting else default
    
    @staticmethod
    def set(key, value, description=None):
        """设置值"""
        setting = SystemSetting.query.filter_by(key=key).first()
        if setting:
            setting.value = value
            if description:
                setting.description = description
        else:
            setting = SystemSetting(key=key, value=value, description=description)
            db.session.add(setting)
        db.session.commit()
        return setting
    
    def __repr__(self):
        return f'<SystemSetting {self.key}>'


class Report(db.Model):
    """舆情报告模型"""
    __tablename__ = 'reports'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(256), nullable=False)
    content = db.Column(db.Text)
    report_type = db.Column(db.String(64))  # daily, weekly, monthly, special
    status = db.Column(db.String(20), default='draft')  # draft, published
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    author = db.relationship('User', backref='reports')
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'report_type': self.report_type,
            'status': self.status,
            'author': self.author.real_name if self.author else '',
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else ''
        }
    
    def __repr__(self):
        return f'<Report {self.title[:20]}>'


class Article(db.Model):
    """舆情文章模型"""
    __tablename__ = 'articles'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(512), nullable=False)  # 标题
    content = db.Column(db.Text)  # 概要/内容
    url = db.Column(db.String(1024), unique=True)  # 原始URL
    source = db.Column(db.String(128))  # 来源
    cover_image = db.Column(db.String(1024))  # 封面图片URL
    publish_time = db.Column(db.String(64))  # 发布时间（原始格式）
    keyword = db.Column(db.String(128))  # 采集关键词
    sentiment = db.Column(db.String(20))  # 情感: positive, negative, neutral
    category = db.Column(db.String(64))  # 分类
    is_important = db.Column(db.Boolean, default=False)  # 是否重要
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    author = db.relationship('User', backref='articles')
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'url': self.url,
            'source': self.source,
            'cover_image': self.cover_image,
            'publish_time': self.publish_time,
            'keyword': self.keyword,
            'sentiment': self.sentiment,
            'category': self.category,
            'is_important': self.is_important,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else ''
        }
    
    def __repr__(self):
        return f'<Article {self.title[:30]}>'


class Keyword(db.Model):
    """监控关键词模型"""
    __tablename__ = 'keywords'
    
    id = db.Column(db.Integer, primary_key=True)
    word = db.Column(db.String(128), unique=True, nullable=False)  # 关键词
    category = db.Column(db.String(64))  # 分类
    priority = db.Column(db.Integer, default=1)  # 优先级
    is_active = db.Column(db.Boolean, default=True)  # 是否启用
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'word': self.word,
            'category': self.category,
            'priority': self.priority,
            'is_active': self.is_active
        }
    
    def __repr__(self):
        return f'<Keyword {self.word}>'


class Alert(db.Model):
    """预警模型"""
    __tablename__ = 'alerts'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(256), nullable=False)
    content = db.Column(db.Text)
    level = db.Column(db.String(20), default='normal')  # low, normal, high, urgent
    article_id = db.Column(db.Integer, db.ForeignKey('articles.id'))
    is_read = db.Column(db.Boolean, default=False)
    is_handled = db.Column(db.Boolean, default=False)
    handled_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    handled_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    article = db.relationship('Article', backref='alerts')
    handler = db.relationship('User', backref='handled_alerts')
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'level': self.level,
            'is_read': self.is_read,
            'is_handled': self.is_handled,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else ''
        }
    
    def __repr__(self):
        return f'<Alert {self.title[:20]}>'
